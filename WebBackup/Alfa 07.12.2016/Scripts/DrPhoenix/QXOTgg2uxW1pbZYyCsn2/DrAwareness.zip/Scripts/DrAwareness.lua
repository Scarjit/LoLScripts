assert(load(Base64Decode("G0x1YVIAAQQEBAgAGZMNChoKAAAAAAAAAAAAAQQfAAAAAwAAAEQAAACGAEAA5QAAAJ1AAAGGQEAA5UAAAJ1AAAGlgAAACIAAgaXAAAAIgICBhgBBAOUAAQCdQAABhkBBAMGAAQCdQAABhoBBAOVAAQCKwICDhoBBAOWAAQCKwACEhoBBAOXAAQCKwICEhoBBAOUAAgCKwACFHwCAAAsAAAAEEgAAAEFkZFVubG9hZENhbGxiYWNrAAQUAAAAQWRkQnVnc3BsYXRDYWxsYmFjawAEDAAAAFRyYWNrZXJMb2FkAAQNAAAAQm9sVG9vbHNUaW1lAAQQAAAAQWRkVGlja0NhbGxiYWNrAAQGAAAAY2xhc3MABA4AAABTY3JpcHRUcmFja2VyAAQHAAAAX19pbml0AAQSAAAAU2VuZFZhbHVlVG9TZXJ2ZXIABAoAAABzZW5kRGF0YXMABAsAAABHZXRXZWJQYWdlAAkAAAACAAAAAwAAAAAAAwkAAAAFAAAAGABAABcAAIAfAIAABQAAAAxAQACBgAAAHUCAAR8AgAADAAAAAAQSAAAAU2VuZFZhbHVlVG9TZXJ2ZXIABAcAAAB1bmxvYWQAAAAAAAEAAAABAQAAAAAAAAAAAAAAAAAAAAAEAAAABQAAAAAAAwkAAAAFAAAAGABAABcAAIAfAIAABQAAAAxAQACBgAAAHUCAAR8AgAADAAAAAAQSAAAAU2VuZFZhbHVlVG9TZXJ2ZXIABAkAAABidWdzcGxhdAAAAAAAAQAAAAEBAAAAAAAAAAAAAAAAAAAAAAUAAAAHAAAAAQAEDQAAAEYAwACAAAAAXYAAAUkAAABFAAAATEDAAMGAAABdQIABRsDAAKUAAADBAAEAXUCAAR8AgAAFAAAABA4AAABTY3JpcHRUcmFja2VyAAQSAAAAU2VuZFZhbHVlVG9TZXJ2ZXIABAUAAABsb2FkAAQMAAAARGVsYXlBY3Rpb24AAwAAAAAAQHpAAQAAAAYAAAAHAAAAAAADBQAAAAUAAAAMAEAAgUAAAB1AgAEfAIAAAgAAAAQSAAAAU2VuZFZhbHVlVG9TZXJ2ZXIABAgAAAB3b3JraW5nAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAAAEBAAAAAAAAAAAAAAAAAAAAAAAACAAAAA0AAAAAAAYyAAAABgBAAB2AgAAaQEAAF4AAgEGAAABfAAABF0AKgEYAQQBHQMEAgYABAMbAQQDHAMIBEEFCAN0AAAFdgAAACECAgUYAQQBHQMEAgYABAMbAQQDHAMIBEMFCAEbBQABPwcICDkEBAt0AAAFdgAAACEAAhUYAQQBHQMEAgYABAMbAQQDHAMIBBsFAAA9BQgIOAQEARoFCAE/BwgIOQQEC3QAAAV2AAAAIQACGRsBAAIFAAwDGgEIAAUEDAEYBQwBWQIEAXwAAAR8AgAAOAAAABA8AAABHZXRJbkdhbWVUaW1lcgADAAAAAAAAAAAECQAAADAwOjAwOjAwAAQGAAAAaG91cnMABAcAAABzdHJpbmcABAcAAABmb3JtYXQABAYAAAAlMDIuZgAEBQAAAG1hdGgABAYAAABmbG9vcgADAAAAAAAgrEAEBQAAAG1pbnMAAwAAAAAAAE5ABAUAAABzZWNzAAQCAAAAOgAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAA4AAAATAAAAAAAIKAAAAAEAAABGQEAAR4DAAIEAAAAhAAiABkFAAAzBQAKAAYABHYGAAVgAQQIXgAaAR0FBAhiAwQIXwAWAR8FBAhkAwAIXAAWARQGAAFtBAAAXQASARwFCAoZBQgCHAUIDGICBAheAAYBFAQABTIHCAsHBAgBdQYABQwGAAEkBgAAXQAGARQEAAUyBwgLBAQMAXUGAAUMBgABJAYAAIED3fx8AgAANAAAAAwAAAAAAAPA/BAsAAABvYmpNYW5hZ2VyAAQLAAAAbWF4T2JqZWN0cwAECgAAAGdldE9iamVjdAAABAUAAAB0eXBlAAQHAAAAb2JqX0hRAAQHAAAAaGVhbHRoAAQFAAAAdGVhbQAEBwAAAG15SGVybwAEEgAAAFNlbmRWYWx1ZVRvU2VydmVyAAQGAAAAbG9vc2UABAQAAAB3aW4AAAAAAAMAAAAAAAEAAQEAAAAAAAAAAAAAAAAAAAAAFAAAABQAAAACAAICAAAACkAAgB8AgAABAAAABAoAAABzY3JpcHRLZXkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAABUAAAACAAUKAAAAhgBAAMAAgACdgAABGEBAARfAAICFAIAAjIBAAQABgACdQIABHwCAAAMAAAAEBQAAAHR5cGUABAcAAABzdHJpbmcABAoAAABzZW5kRGF0YXMAAAAAAAIAAAAAAAEBAAAAAAAAAAAAAAAAAAAAABYAAAAlAAAAAgATPwAAAApAAICGgEAAnYCAAAqAgICGAEEAxkBBAAaBQQAHwUECQQECAB2BAAFGgUEAR8HBAoFBAgBdgQABhoFBAIfBQQPBgQIAnYEAAcaBQQDHwcEDAcICAN2BAAEGgkEAB8JBBEECAwAdggABFgECAt0AAAGdgAAACoCAgYaAQwCdgIAACoCAhgoAxIeGQEQAmwAAABdAAIAKgMSHFwAAgArAxIeGQEUAh4BFAQqAAIqFAIAAjMBFAQEBBgBBQQYAh4FGAMHBBgAAAoAAQQIHAIcCRQDBQgcAB0NAAEGDBwCHw0AAwcMHAAdEQwBBBAgAh8RDAFaBhAKdQAACHwCAACEAAAAEBwAAAGFjdGlvbgAECQAAAHVzZXJuYW1lAAQIAAAAR2V0VXNlcgAEBQAAAGh3aWQABA0AAABCYXNlNjRFbmNvZGUABAkAAAB0b3N0cmluZwAEAwAAAG9zAAQHAAAAZ2V0ZW52AAQVAAAAUFJPQ0VTU09SX0lERU5USUZJRVIABAkAAABVU0VSTkFNRQAEDQAAAENPTVBVVEVSTkFNRQAEEAAAAFBST0NFU1NPUl9MRVZFTAAEEwAAAFBST0NFU1NPUl9SRVZJU0lPTgAECwAAAGluZ2FtZVRpbWUABA0AAABCb2xUb29sc1RpbWUABAYAAABpc1ZpcAAEAQAAAAAECQAAAFZJUF9VU0VSAAMAAAAAAADwPwMAAAAAAAAAAAQJAAAAY2hhbXBpb24ABAcAAABteUhlcm8ABAkAAABjaGFyTmFtZQAECwAAAEdldFdlYlBhZ2UABA4AAABib2wtdG9vbHMuY29tAAQXAAAAL2FwaS9ldmVudHM/c2NyaXB0S2V5PQAECgAAAHNjcmlwdEtleQAECQAAACZhY3Rpb249AAQLAAAAJmNoYW1waW9uPQAEDgAAACZib2xVc2VybmFtZT0ABAcAAAAmaHdpZD0ABA0AAAAmaW5nYW1lVGltZT0ABAgAAAAmaXNWaXA9AAAAAAACAAAAAAABAQAAAAAAAAAAAAAAAAAAAAAmAAAAKgAAAAMACiEAAADGQEAAAYEAAN2AAAHHwMAB3YCAAArAAIDHAEAAzADBAUABgACBQQEA3UAAAscAQADMgMEBQcEBAIABAAHBAQIAAAKAAEFCAgBWQYIC3UCAAccAQADMgMIBQcECAIEBAwDdQAACxwBAAMyAwgFBQQMAgYEDAN1AAAIKAMSHCgDEiB8AgAASAAAABAcAAABTb2NrZXQABAgAAAByZXF1aXJlAAQHAAAAc29ja2V0AAQEAAAAdGNwAAQIAAAAY29ubmVjdAADAAAAAAAAVEAEBQAAAHNlbmQABAUAAABHRVQgAAQSAAAAIEhUVFAvMS4wDQpIb3N0OiAABAUAAAANCg0KAAQLAAAAc2V0dGltZW91dAADAAAAAAAAAAAEAgAAAGIAAwAAAPyD15dBBAIAAAB0AAQKAAAATGFzdFByaW50AAQBAAAAAAQFAAAARmlsZQAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAABAAAAAAAAAAAAAAAAAAAAAAA="), nil, "bt", _ENV))()
TrackerLoad("")

require "MapPosition"

local WorldToScreen, pairs, GetSprite, MapPosition, ARGB, mfloor, DrawTextA, DrawRectangle, GetInGameTimer, DrawLine, DrawCircle3D, supper, DrawLine3D, DrawText3D, sformat = WorldToScreen, pairs, GetSprite, MapPosition, ARGB, math.floor, DrawTextA, DrawRectangle, GetInGameTimer, DrawLine, DrawCircle3D, string.upper, DrawLine3D, DrawText3D, string.format


local version = "1.01"
	
local ally = GetAllyHeroes()
local enemy = GetEnemyHeroes()

local function GetEnemyJunglers()
	local _enemyJunglers
    if _enemyJunglers then return _enemyJunglers end
    _enemyJunglers = {}
	for i, hero in pairs(enemy) do
		if hero:GetSpellData(SUMMONER_1).name == "SummonerSmite" then
			_enemyJunglers[#_enemyJunglers+1] = hero
		elseif hero:GetSpellData(SUMMONER_2).name == "SummonerSmite" then
			_enemyJunglers[#_enemyJunglers+1] = hero
		end
	end
    return setmetatable(_enemyJunglers,{
        __newindex = function(self, key, value)
            error("Adding to EnemyJunglers is not granted. Use table.copy.")
        end,
    })
end

local junglers = GetEnemyJunglers()

function GetEnemyTowers()
    if _enemyTowers then return _enemyTowers end
    _enemyTowers = {}
	for i=1, objManager.maxObjects do
		local obj = objManager:GetObject(i)
		if obj and obj.valid and obj.team ~= myHero.team and obj.health > 0 and obj.type == "obj_AI_Turret" then
			_enemyTowers[#_enemyTowers+1] = obj
		end
	end
    return setmetatable(_enemyTowers,{
        __newindex = function(self, key, value)
            error("Adding to EnemyTowers is not granted. Use table.copy.")
        end,
    })
end

local towers = GetEnemyTowers()
	
local greenWardTable = {}
local pinkWardTable = {}

local HudFancySprite = nil
local HudClassicSprite = nil
local HeroSprite = {}
local SpellSprite = {}
local HPBarSprite = nil
local NotificationSprite = nil
local BaronSprite = nil
local DragonSprite = nil
local BlueSprite = nil
local GankSprite = nil

local ChampionManaBarColor = {
	['Aatrox'] = function (unit) if unit.mana == 100 then return { R = 200 , G = 40 , B = 0 } else return { R = 85 , G = 85 , B = 85 } end end, 
	['Ahri'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Akali'] = function (unit) return { R = 178 , G = 140 , B = 1 } end, 
	['Alistar'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Amumu'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Anivia'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Annie'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Ashe'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['AurelionSol'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Azir'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Bard'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Blitzcrank'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Brand'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Braum'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Caitlyn'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Cassiopeia'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Chogath'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Corki'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Darius'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Diana'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['DrMundo'] = function (unit) return { R = 0 , G = 0 , B = 0 } end, 
	['Draven'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Ekko'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Elise'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Evelynn'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Ezreal'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['FiddleSticks'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Fiora'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Fizz'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Galio'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Gangplank'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Garen'] = function (unit) return { R = 0 , G = 0 , B = 0 } end, 
	['Gnar'] = function (unit) if unit.range > 240 then return { R = 200 , G = 40 , B = 0 } else return { R = 85 , G = 85 , B = 85 } end end, 
	['Gragas'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Graves'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Hecarim'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Heimerdinger'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Illaoi'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Irelia'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Ivern'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Janna'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['JarvanIV'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Jax'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Jayce'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Jhin'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Jinx'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Kalista'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Karma'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Karthus'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Kassadin'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Katarina'] = function (unit) return { R = 0 , G = 0 , B = 0 } end, 
	['Kayle'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Kennen'] = function (unit) return { R = 178 , G = 140 , B = 1 } end, 
	['Khazix'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Kindred'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Kled'] = function (unit) return { R = 85 , G = 85 , B = 85 } end, 
	['KogMaw'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Leblanc'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['LeeSin'] = function (unit) return { R = 178 , G = 140 , B = 1 } end, 
	['Leona'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Lissandra'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Lucian'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Lulu'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Lux'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Malphite'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Malzahar'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Maokai'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['MasterYi'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['MissFortune'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Mordekaiser'] = function (unit) return { R = 85 , G = 85 , B = 85 } end, 
	['Morgana'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Nami'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Nasus'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Nautilus'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Nidalee'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Nocturne'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Nunu'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Olaf'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Orianna'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Pantheon'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Poppy'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Quinn'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Rammus'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['RekSai'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Renekton'] = function (unit) if unit.mana > 50 then return { R = 200 , G = 40 , B = 0 } else return { R = 85 , G = 85 , B = 85 } end end, 
	['Rengar'] = function (unit) if unit.mana < 5 then return { R = 85 , G = 85 , B = 85 } else return { R = 200 , G = 40 , B = 0 } end end, 
	['Riven'] = function (unit) return { R = 0 , G = 0 , B = 0 } end, 
	['Rumble'] = function (unit) if unit.mana < 50 then return { R = 85 , G = 85 , B = 85 } else return { R = 220 , G = 130 , B = 0 } end end, 
	['Ryze'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Sejuani'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Shaco'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Shen'] = function (unit) return { R = 178 , G = 140 , B = 1 } end, 
	['Shyvana'] = function (unit) if unit.mana == 100 then return { R = 200 , G = 40 , B = 0 } else return { R = 220 , G = 130 , B = 0 } end end, 
	['Singed'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Sion'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Sivir'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Skarner'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Sona'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Soraka'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Swain'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Syndra'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['TahmKench'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Taliyah'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Talon'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Taric'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Teemo'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Thresh'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Tristana'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Trundle'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Tryndamere'] = function (unit) return { R = 200 , G = 40 , B = 0 } end, 
	['TwistedFate'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Twitch'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Udyr'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Urgot'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Varus'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Vayne'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Veigar'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Velkoz'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Vi'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Viktor'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Vladimir'] = function (unit) return { R = 0 , G = 0 , B = 0 } end, 
	['Volibear'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Warwick'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	 --[[ Wukong ]] ['MonkeyKing'] = function (unit) return { R = 1 , G = 130 , B = 181 } end,
	['Xerath'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['XinZhao'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Yasuo'] = function (unit) if unit.mana == unit.maxMana then return { R = 200 , G = 40 , B = 0 } else return { R = 85 , G = 85 , B = 85 } end end, 
	['Yorick'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Zac'] = function (unit) return { R = 0 , G = 0 , B = 0 } end, 
	['Zed'] = function (unit) return { R = 178 , G = 140 , B = 1 } end, 
	['Ziggs'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Zilean'] = function (unit) return { R = 1 , G = 130 , B = 181 } end, 
	['Zyra'] = function (unit) return { R = 1 , G = 130 , B = 181 } end
}

local HUDInfos = { x = 0 , y = 0 , xInit = 0 , yInit = 0 , w = 0 , h = 0 , s = 1 , t = 1 }
local HUDInfosColor = ARGB(150,255,0,0)
local GankAlertInfos = { x = 0 , y = 0 , xInit = 0 , yInit = 0 }
local GankAlertInfosColor = ARGB(150,255,0,0)

local MenuVisible = false

local function PrintMsg(msg)
	PrintChat("<font color=\"#0ba500\"><b>[</b></font><font color=\"#19d800\"><b>Doctor Awareness</b></font><font color=\"#0ba500\"><b>]</b></font> <font color=\"#77e000\">"..msg.."</font>")
end

local function TCPGetRequest(server, path, data, port)
	local start_t = os.clock()
	local port = port or 80
	local data = data or {}
	local lua_socket = require("socket")
	local connection_tcp = lua_socket.connect(server,port)
	local requeststring = "GET "..path
	local first = true
	for i,v in pairs(data)do
		requeststring = requeststring..(first and "?" or "&")..i.."="..v
		first = false
	end
	requeststring = requeststring.. " HTTP/1.0\r\nHost: "..server.."\r\n\r\n"
	connection_tcp:send(requeststring)
	local response = ""
	local status
	while true do
		s,status, partial = connection_tcp:receive('*a')
		response = response..(s or partial)
		if(status == "closed" or status == "timeout")then
			break
		end
	end
	local end_t = os.clock()
	local start_content = response:find("\r\n\r\n")+4
	response = response:sub(start_content)
	return response, status, end_t-start_t
end

local function GetWebFile(server, path, data, localfilename, port, b64)
	local r,s,t = TCPGetRequest(server, path, data, port)
	file = io.open(localfilename,"w+b")
	file:write(r)
	file:close()
end

local function Update()
	if version ~= TCPGetRequest("s1mplescripts.de", "/DrPhoenix/BoL/Scripts/DrAwareness/DrAwareness.version", {}, 80) then
		PrintMsg("Updating don't press F9 !")
		GetWebFile("s1mplescripts.de","/DrPhoenix/BoL/Scripts/DrAwareness/DrAwareness.lua", {}, SCRIPT_PATH..GetCurrentEnv().FILE_NAME, 80, false)
		PrintMsg("Updated ! Press 2xF9 to reload !")
	end
end

local function UpdateMenuValues()
	if HUDInfos.t == 1 then
		if HUDInfos.s == 1 then
			HUDInfos.w = 1352
			HUDInfos.h = 92
		elseif HUDInfos.s == 2 then
			HUDInfos.w = 457
			HUDInfos.h = 97
		elseif HUDInfos.s == 3 then
			HUDInfos.w = 798
			HUDInfos.h = 78
		elseif HUDInfos.s == 4 then
			HUDInfos.w = 1023
			HUDInfos.h = 52
		end
	else
		if HUDInfos.s == 1 then
			HUDInfos.w = 264
			HUDInfos.h = 492
		elseif HUDInfos.s == 2 then
			HUDInfos.w = 85
			HUDInfos.h = 549
		elseif HUDInfos.s == 3 then
			HUDInfos.w = 154
			HUDInfos.h = 478
		elseif HUDInfos.s == 4 then
			HUDInfos.w = 223
			HUDInfos.h = 292
		end
	end
end

local function AddMenu()
	local WindowW = WINDOW_W
	local WindowH = WINDOW_H
	
	Menu = scriptConfig("Doctor Awareness", "Menu")

	Menu:addSubMenu("+ HUD", "HUDSettings")
		Menu.HUDSettings:addParam("HUDON", "Draw HUD", SCRIPT_PARAM_ONOFF, true)
		Menu.HUDSettings:addParam("HUDStyle", "Select Style", SCRIPT_PARAM_LIST, 1, {"Fancy HUD", "Classic HUD", "Lag Friendly 1", "Lag Friendly 2"})
			Menu.HUDSettings:setCallback("HUDStyle",
				function(value)
					HUDInfos.s = value
					UpdateMenuValues()
				end)
		Menu.HUDSettings:addParam("HUDType", "Select Type", SCRIPT_PARAM_LIST, 1, {"Horizontal", "Vertical"})
			Menu.HUDSettings:setCallback("HUDType",
				function(value)
					HUDInfos.t = value
					UpdateMenuValues()
				end)
	
	Menu:addSubMenu("+ HP Bar", "HPBarSettings")
		Menu.HPBarSettings:addParam("HPbarON", "Draw Info Bar", SCRIPT_PARAM_ONOFF, true)
		Menu.HPBarSettings:addParam("HPBarType", "Select Type", SCRIPT_PARAM_LIST, 1, {"Fancy", "FPS Friendly"})
	
	Menu:addSubMenu("+ Enemy Path", "WaypointsSettings")
		Menu.WaypointsSettings:addParam("WaypointsON", "Draw enemy path", SCRIPT_PARAM_ONOFF, true)
	
	Menu:addSubMenu("+ Gank Alert", "GankSettings")
		Menu.GankSettings:addParam("GankAlertON", "Show gank alert", SCRIPT_PARAM_ONOFF, true)
	
	Menu:addSubMenu("+ Wards", "WardsSettings")
		Menu.WardsSettings:addParam("WardTrackerON", "Track ward pos", SCRIPT_PARAM_ONOFF, true)
		Menu.WardsSettings:addParam("WardTrackerQuality", "Circle Quality", SCRIPT_PARAM_SLICE, 50, 10, 100, 0)
	
	Menu:addSubMenu("+ Towers", "TowersSettings")
		Menu.TowersSettings:addParam("TowerRangeON", "Show tower range", SCRIPT_PARAM_ONOFF, true)
		Menu.TowersSettings:addParam("TowerRangeQuality", "Circle Quality", SCRIPT_PARAM_SLICE, 50, 10, 100, 0)
	
	Menu:addSubMenu("+ Others Infos", "InfosSettings")
		Menu.InfosSettings:addParam("DrawInfosON", "Show FPS and ping", SCRIPT_PARAM_ONOFF, true)
		Menu.InfosSettings:addParam("InfosPosX", "Horizontal position", SCRIPT_PARAM_SLICE, 1, 0, WindowW, 0)
		Menu.InfosSettings:addParam("InfosPosY", "Vertical position", SCRIPT_PARAM_SLICE, 1, 0, WindowH, 0)
		Menu.InfosSettings:addParam("InfosSize", "Text Size", SCRIPT_PARAM_SLICE, 15, 5, 25, 0)
		Menu.InfosSettings:addParam("space11", "", 5, "")
		Menu.InfosSettings:addParam("space12", "                              >>    --    <<", 5, "")
		Menu.InfosSettings:addParam("space13", "", 5, "")
		Menu.InfosSettings:addParam("DrawDateON", "Show Date", SCRIPT_PARAM_ONOFF, true)
		Menu.InfosSettings:addParam("DatePosX", "Horizontal position", SCRIPT_PARAM_SLICE, 1, 0, WindowW, 0)
		Menu.InfosSettings:addParam("DatePosY", "Vertical position", SCRIPT_PARAM_SLICE, 1, 0, WindowH, 0)
		Menu.InfosSettings:addParam("DateSize", "Text Size", SCRIPT_PARAM_SLICE, 15, 5, 25, 0)
	
	Menu:addParam("space2", "", 5, "")
	Menu:addParam("signature0", "             Doctor Awareness v"..version, 5, "")
	Menu:addParam("signature1", "                    by DrPhoenix", 5, "")
end

local function LoadSprites()
	if Menu.HUDSettings.HUDON then
		HudFancySprite = GetSprite("\\DrAwareness\\Fancy.png")
		HudClassicSprite = GetSprite("\\DrAwareness\\Classic.png")

		for i, hero in pairs(enemy) do
			HeroSprite[hero.charName] = GetSprite("\\DrAwareness\\Champions\\"..hero.charName..".png")
		end
		
		SpellSprite["SummonerBarrier"] = GetSprite("\\DrAwareness\\Spells\\SummonerBarrier.png")
		SpellSprite["SummonerMana"] = GetSprite("\\DrAwareness\\Spells\\SummonerMana.png")
		SpellSprite["SummonerBoost"] = GetSprite("\\DrAwareness\\Spells\\SummonerBoost.png")
		SpellSprite["SummonerExhaust"] = GetSprite("\\DrAwareness\\Spells\\SummonerExhaust.png")
		SpellSprite["SummonerFlash"] = GetSprite("\\DrAwareness\\Spells\\SummonerFlash.png")
		SpellSprite["SummonerHaste"] = GetSprite("\\DrAwareness\\Spells\\SummonerHaste.png")
		SpellSprite["SummonerHeal"] = GetSprite("\\DrAwareness\\Spells\\SummonerHeal.png")
		SpellSprite["SummonerDot"] = GetSprite("\\DrAwareness\\Spells\\SummonerDot.png")
		SpellSprite["SummonerSnowball"] = GetSprite("\\DrAwareness\\Spells\\SummonerSnowball.png")
		SpellSprite["SummonerSmite"] = GetSprite("\\DrAwareness\\Spells\\SummonerSmite.png")
		SpellSprite["S5_SummonerSmitePlayerGanker"] = GetSprite("\\DrAwareness\\Spells\\S5_SummonerSmitePlayerGanker.png")
		SpellSprite["S5_SummonerSmiteDuel"] = GetSprite("\\DrAwareness\\Spells\\S5_SummonerSmiteDuel.png")
		SpellSprite["SummonerTeleport"] = GetSprite("\\DrAwareness\\Spells\\SummonerTeleport.png")
	end
	
	HPBarSprite = GetSprite("\\DrAwareness\\HPbar.png")
	
	NotificationSprite = GetSprite("\\DrAwareness\\notification.png")
	BaronSprite = GetSprite("\\DrAwareness\\Buffs\\baron.png")
	DragonSprite = GetSprite("\\DrAwareness\\Buffs\\dragon.png")
	RedSprite = GetSprite("\\DrAwareness\\Buffs\\red.png")
	BlueSprite = GetSprite("\\DrAwareness\\Buffs\\blue.png")
	
	GankSprite = GetSprite("\\DrAwareness\\GankAlert.png")
end

function DetectMenu(msg, key)
	if key == GetSave("scriptConfig").Menu.menuKey then
		if msg == 256 then
			MenuVisible = true
		elseif msg == 257 then
			MenuVisible = false
		end
	end

	if key == 5 and msg == 513 then
		if GetCursorPos().x > HUDInfos.x and GetCursorPos().x < HUDInfos.x + HUDInfos.w then
			if GetCursorPos().y > HUDInfos.y and GetCursorPos().y < HUDInfos.y + HUDInfos.h then
				HUDInfos.xInit = GetCursorPos().x - HUDInfos.x
				HUDInfos.yInit = GetCursorPos().y - HUDInfos.y
			elseif GetCursorPos().x > HUDInfos.x and GetCursorPos().x < HUDInfos.x + 120 and GetCursorPos().y > HUDInfos.y - 30 and GetCursorPos().y < HUDInfos.y then
				HUDInfos.xInit = GetCursorPos().x - HUDInfos.x
				HUDInfos.yInit = GetCursorPos().y - HUDInfos.y
			end
		elseif GetCursorPos().x > GankAlertInfos.x and GetCursorPos().x < GankAlertInfos.x + 300 then
			if GetCursorPos().y > GankAlertInfos.y and GetCursorPos().y < GankAlertInfos.y + 100 then
				GankAlertInfos.xInit = GetCursorPos().x - GankAlertInfos.x
				GankAlertInfos.yInit = GetCursorPos().y - GankAlertInfos.y
			elseif GetCursorPos().x > GankAlertInfos.x and GetCursorPos().x < GankAlertInfos.x + 180 and GetCursorPos().y > GankAlertInfos.y - 30 and GetCursorPos().y < GankAlertInfos.y then
				GankAlertInfos.xInit = GetCursorPos().x - GankAlertInfos.x
				GankAlertInfos.yInit = GetCursorPos().y - GankAlertInfos.y
			end
		end
	end

	if key == 5 and msg == 512 then
		if GetCursorPos().x > HUDInfos.x and GetCursorPos().x < HUDInfos.x + HUDInfos.w then
			if GetCursorPos().y > HUDInfos.y and GetCursorPos().y < HUDInfos.y + HUDInfos.h then
				HUDInfosColor = ARGB(150,0,255,0)
				HUDInfos.x = GetCursorPos().x - HUDInfos.xInit
				HUDInfos.y = GetCursorPos().y - HUDInfos.yInit
			elseif GetCursorPos().x > HUDInfos.x and GetCursorPos().x < HUDInfos.x + 120 and GetCursorPos().y > HUDInfos.y - 30 and GetCursorPos().y < HUDInfos.y then
				HUDInfosColor = ARGB(150,0,255,0)
				HUDInfos.x = GetCursorPos().x - HUDInfos.xInit
				HUDInfos.y = GetCursorPos().y - HUDInfos.yInit
			end
		elseif GetCursorPos().x > GankAlertInfos.x and GetCursorPos().x < GankAlertInfos.x + 300 then
			if GetCursorPos().y > GankAlertInfos.y and GetCursorPos().y < GankAlertInfos.y + 100 then
				GankAlertInfosColor = ARGB(150,0,255,0)
				GankAlertInfos.x = GetCursorPos().x - GankAlertInfos.xInit
				GankAlertInfos.y = GetCursorPos().y - GankAlertInfos.yInit
			elseif GetCursorPos().x > GankAlertInfos.x and GetCursorPos().x < GankAlertInfos.x + 180 and GetCursorPos().y > GankAlertInfos.y - 30 and GetCursorPos().y < GankAlertInfos.y then
				GankAlertInfosColor = ARGB(150,0,255,0)
				GankAlertInfos.x = GetCursorPos().x - GankAlertInfos.xInit
				GankAlertInfos.y = GetCursorPos().y - GankAlertInfos.yInit
			end
		end
	end
	
	if ( key == 4 and msg == 514 ) or ( key == 16 and msg == 257 ) then
		HUDInfosColor = ARGB(150,255,0,0)
		GankAlertInfosColor = ARGB(150,255,0,0)
	end
end

local function GetEnemyPos(hero)
	if MapPosition:onTopLane(hero) then
		return ("Top")
	elseif MapPosition:onMidLane(hero) then
		return ("Mid")
	elseif MapPosition:onBotLane(hero) then
		return ("Bot")
	elseif MapPosition:inTopRiver(hero) then
		return ("Top River")
	elseif MapPosition:inBottomRiver(hero) then
		return ("Bot River")
	elseif MapPosition:inLeftBase(hero) then
		return ("Blue Base")
	elseif MapPosition:inRightBase(hero) then
		return ("Red Base")
	elseif MapPosition:inTopLeftJungle(hero) then
		return ("Blue Team Blue")
	elseif MapPosition:inBottomRightJungle(hero) then
		return ("Red Team Blue")
	elseif MapPosition:inBottomLeftJungle(hero) then
		return ("Blue Team Red")
	elseif MapPosition:inTopRightJungle(hero) then
		return ("Red Team Red")
	end
end

local function DrawHUD()
	if not MenuVisible then
		if Menu.HUDSettings.HUDON then
			local x = HUDInfos.x
			local y = HUDInfos.y
			
			if Menu.HUDSettings.HUDStyle == 1 then
				for i, hero in pairs(enemy) do
					local opacity = 255
				
					if Menu.HUDSettings.HUDType == 1 then
						x = HUDInfos.x + ( ( i - 1 ) * 272 )
						y = HUDInfos.y
					elseif Menu.HUDSettings.HUDType == 2 then
						x = HUDInfos.x
						y = HUDInfos.y + ( ( i - 1 ) * 100 )
					end
					
					if hero.visible and not hero.dead then
						opacity = 255
					else
						opacity = 125
					end
					
					HudFancySprite:Draw(x, y, opacity)
					
					HeroSprite[hero.charName]:Draw(x + 29, y + 22, opacity)
					
					SpellSprite[hero:GetSpellData(SUMMONER_1).name]:Draw(x + 203, y + 22, opacity)
					SpellSprite[hero:GetSpellData(SUMMONER_1).name]:SetScale(14/22, 14/22)
					
					if hero:GetSpellData(SUMMONER_1).currentCd > 0 then
						DrawRectangle(x + 203, y + 22, 14, 14, ARGB(150,0,0,0))
						DrawTextA(mfloor(hero:GetSpellData(SUMMONER_1).currentCd), 14, x + 224, y + 22, ARGB(opacity,255,255,255))
					end
					
					SpellSprite[hero:GetSpellData(SUMMONER_2).name]:Draw(x + 203, y + 40, opacity)
					SpellSprite[hero:GetSpellData(SUMMONER_2).name]:SetScale(14/22, 14/22)
					
					if hero:GetSpellData(SUMMONER_2).currentCd > 0 then
						DrawRectangle(x + 203, y + 40, 14, 14, ARGB(150,0,0,0))
						DrawTextA(mfloor(hero:GetSpellData(SUMMONER_1).currentCd), 14, x + 224, y + 41, ARGB(opacity,255,255,255))
					end
					
					DrawRectangle(x + 56, y + 58, 21, 12, ARGB(opacity - 50,0,0,0))
					DrawTextA(hero.level, 11, x + 66, y + 58, ARGB(opacity,255,255,255), "center")
					
					local HP = hero.health / hero.maxHealth * 106
					
					if HP == 0 then
						DrawTextA("DEAD", 35, x + 140, y + 21, ARGB(175,255,0,0), "center")
					else
						DrawRectangle(x + 87, y + 22, HP, 14, ARGB(opacity,13,186,70))
						
						local MP = hero.mana / hero.maxMana * 106
						
						if MP > 0 then
							DrawRectangle(x + 87, y + 40, MP, 14, ARGB(opacity, ChampionManaBarColor[hero.charName](hero).R, ChampionManaBarColor[hero.charName](hero).G, ChampionManaBarColor[hero.charName](hero).B))
						end
					end
					
					local cdQ = 0
					
					if hero:GetSpellData(_Q).level ~= 0 then
						if hero:GetSpellData(_Q).cd == 0 then
							cdQ = 27
						else
							cdQ = ( 100 - ( hero:GetSpellData(_Q).currentCd / hero:GetSpellData(_Q).cd * 100 ) ) / 100 * 27
						end
					else
						cdQ = nil
					end
					
					if cdQ ~= nil then
						if hero:GetSpellData(_Q).currentCd > 0 then
							DrawRectangle(x + 86, y + 63, cdQ, 8, ARGB(opacity,104,0,0))
						else
							DrawRectangle(x + 86, y + 63, cdQ, 8, ARGB(opacity,0,118,6))
						end
					end
					
					local cdW = 0
					
					if hero:GetSpellData(_W).level ~= 0 then
						if hero:GetSpellData(_W).cd == 0 then
							cdW = 27
						else
							cdW = ( 100 - ( hero:GetSpellData(_W).currentCd / hero:GetSpellData(_W).cd * 100 ) ) / 100 * 27
						end
					else
						cdW = nil
					end
					
					if cdW ~= nil then
						if hero:GetSpellData(_W).currentCd > 0 then
							DrawRectangle(x + 121, y + 63, cdW, 8, ARGB(opacity,104,0,0))
						else
							DrawRectangle(x + 121, y + 63, cdW, 8, ARGB(opacity,0,118,6))
						end
					end
					
					local cdE = 0
					
					if hero:GetSpellData(_E).level ~= 0 then
						if hero:GetSpellData(_E).cd == 0 then
							cdE = 27
						else
							cdE = ( 100 - ( hero:GetSpellData(_E).currentCd / hero:GetSpellData(_E).cd * 100 ) ) / 100 * 27
						end
					else
						cdE = nil
					end
					
					if cdE ~= nil then
						if hero:GetSpellData(_E).currentCd > 0 then
							DrawRectangle(x + 156, y + 63, cdE, 8, ARGB(opacity,104,0,0))
						else
							DrawRectangle(x + 156, y + 63, cdE, 8, ARGB(opacity,0,118,6))
						end
					end
					
					local cdR = 0
					
					if hero:GetSpellData(_R).level ~= 0 then
						if hero:GetSpellData(_R).cd == 0 then
							cdR = 27
						else
							cdR = ( 100 - ( hero:GetSpellData(_R).currentCd / hero:GetSpellData(_R).cd * 100 ) ) / 100 * 27
						end
					else
						cdR = nil
					end
					
					if cdR ~= nil then
						if hero:GetSpellData(_R).currentCd > 0 then
							DrawRectangle(x + 191, y + 63, cdR, 8, ARGB(opacity,104,0,0))
						else
							DrawRectangle(x + 191, y + 63, cdR, 8, ARGB(opacity,0,118,6))
						end
					end
				end
			elseif Menu.HUDSettings.HUDStyle == 2 then
				for i, hero in pairs(enemy) do
					if Menu.HUDSettings.HUDType == 1 then
						x = HUDInfos.x + ( ( i - 1 ) * 93 )
						y = HUDInfos.y + 12
					elseif Menu.HUDSettings.HUDType == 2 then
						x = HUDInfos.x
						y = HUDInfos.y + 12 + ( ( i - 1 ) * 113 )
					end
					
					HudClassicSprite:Draw(x, y, 255)
					
					HeroSprite[hero.charName]:Draw(x + 5, y + 5, 255)
					
					SpellSprite[hero:GetSpellData(SUMMONER_1).name]:Draw(x + 58, y + 5, 255)
					SpellSprite[hero:GetSpellData(SUMMONER_1).name]:SetScale(1, 1)
					
					if hero:GetSpellData(SUMMONER_1).currentCd > 0 then
						DrawRectangle(x + 58, y + 5, 22, 22, ARGB(150,0,0,0))
						if hero:GetSpellData(SUMMONER_1).currentCd < 100 then
							if hero:GetSpellData(SUMMONER_1).currentCd < 10 then
								DrawTextA(mfloor(hero:GetSpellData(SUMMONER_1).currentCd), 16, x + 66, y + 8, ARGB(255,255,255,255))
							else
								DrawTextA(mfloor(hero:GetSpellData(SUMMONER_1).currentCd), 16, x + 62, y + 8, ARGB(255,255,255,255))
							end
						else
							DrawTextA(mfloor(hero:GetSpellData(SUMMONER_1).currentCd), 16, x + 58, y + 8, ARGB(255,255,255,255))
						end
					end
					
					SpellSprite[hero:GetSpellData(SUMMONER_2).name]:Draw(x + 58, y + 31, 255)
					SpellSprite[hero:GetSpellData(SUMMONER_2).name]:SetScale(1, 1)
					
					if hero:GetSpellData(SUMMONER_2).currentCd > 0 then
						DrawRectangle(x + 58, y + 31, 22, 22, ARGB(150,0,0,0))
						if hero:GetSpellData(SUMMONER_2).currentCd < 100 then
							if hero:GetSpellData(SUMMONER_2).currentCd < 10 then
								DrawTextA(mfloor(hero:GetSpellData(SUMMONER_2).currentCd), 16, x + 66, y + 34, ARGB(255,255,255,255))
							else
								DrawTextA(mfloor(hero:GetSpellData(SUMMONER_2).currentCd), 16, x + 62, y + 34, ARGB(255,255,255,255))
							end
						else
							DrawTextA(mfloor(hero:GetSpellData(SUMMONER_2).currentCd), 16, x + 58, y + 34, ARGB(255,255,255,255))
						end
					end
					
					DrawRectangle(x + 5, y + 38, 18, 15, ARGB(200,0,0,0))
					DrawTextA(hero.level, 11, x + 8, y + 40, ARGB(255,255,255,255))
					
					local HP = hero.health / hero.maxHealth * 75
					
					if HP == 0 then
						DrawRectangle(x + 5, y + 5, 48, 48, ARGB(200,0,0,0))
						DrawTextA("Dead", 18, x + 11, y + 35, ARGB(255,255,0,0))
					else
						if hero.health / hero.maxHealth * 100 < 25 then
							DrawLine(x + 5, y + 68, x + 5 + HP, y + 68, 6, ARGB(255,255,71,71))
						else
							DrawLine(x + 5, y + 68, x + 5 + HP, y + 68, 6, ARGB(255,26,190,81))
						end
						
						local MP = hero.mana / hero.maxMana * 75
						
						if MP > 0 then
							DrawLine(x + 5, y + 77, x + 5 + MP, y + 77, 6, ARGB(255, ChampionManaBarColor[hero.charName](hero).R, ChampionManaBarColor[hero.charName](hero).G, ChampionManaBarColor[hero.charName](hero).B))
						end
						
						DrawTextA(GetEnemyPos(hero), 14, x + 5, y - 15, ARGB(255,255,255,255))
					end
					
					if not hero.visible and not hero.dead then
						DrawRectangle(x + 5, y + 5, 48, 48, ARGB(200,0,0,0))
						DrawTextA("SS", 30, x + 12, y + 12, ARGB(255,255,210,0))
					end
					
					local cdQ = 0
					
					if hero:GetSpellData(_Q).level ~= 0 then
						if hero:GetSpellData(_Q).cd == 0 then
							cdQ = 14
						else
							cdQ = ( 100 - ( hero:GetSpellData(_Q).currentCd / hero:GetSpellData(_Q).cd * 100 ) ) / 100 * 14
						end
					else
						cdQ = nil
					end
					
					if cdQ ~= nil then
						if hero:GetSpellData(_Q).currentCd > 0 then
							DrawLine(x + 5, y + 59, x + 5 + cdQ, y + 59, 4, ARGB(255,181,0,0))
						else
							DrawLine(x + 5, y + 59, x + 5 + cdQ, y + 59, 4, ARGB(255,17,160,2))
						end
					end
					
					local cdW = 0
					
					if hero:GetSpellData(_W).level ~= 0 then
						if hero:GetSpellData(_W).cd == 0 then
							cdW = 14
						else
							cdW = ( 100 - ( hero:GetSpellData(_W).currentCd / hero:GetSpellData(_W).cd * 100 ) ) / 100 * 14
						end
					else
						cdW = nil
					end
					
					if cdW ~= nil then
						if hero:GetSpellData(_W).currentCd > 0 then
							DrawLine(x + 22, y + 59, x + 22 + cdW, y + 59, 4, ARGB(255,181,0,0))
						else
							DrawLine(x + 22, y + 59, x + 22 + cdW, y + 59, 4, ARGB(255,17,160,2))
						end
					end
					
					local cdE = 0
					
					if hero:GetSpellData(_E).level ~= 0 then
						if hero:GetSpellData(_E).cd == 0 then
							cdE = 14
						else
							cdE = ( 100 - ( hero:GetSpellData(_E).currentCd / hero:GetSpellData(_E).cd * 100 ) ) / 100 * 14
						end
					else
						cdE = nil
					end
					
					if cdE ~= nil then
						if hero:GetSpellData(_E).currentCd > 0 then
							DrawLine(x + 39, y + 59, x + 39 + cdE, y + 59, 4, ARGB(255,181,0,0))
						else
							DrawLine(x + 39, y + 59, x + 39 + cdE, y + 59, 4, ARGB(255,17,160,2))
						end
					end
					
					local cdR = 0
					
					if hero:GetSpellData(_R).level ~= 0 then
						if hero:GetSpellData(_R).cd == 0 then
							cdR = 22
						else
							cdR = ( 100 - ( hero:GetSpellData(_R).currentCd / hero:GetSpellData(_R).cd * 100 ) ) / 100 * 22
						end
					else
						cdR = nil
					end
					
					if cdR ~= nil then
						if hero:GetSpellData(_R).currentCd > 0 then
							DrawLine(x + 58, y + 59, x + 58 + cdR, y + 59, 4, ARGB(255,181,0,0))
						else
							DrawLine(x + 58, y + 59, x + 58 + cdR, y + 59, 4, ARGB(255,17,160,2))
						end
					end
				end
			elseif Menu.HUDSettings.HUDStyle == 3 then
				for i, hero in pairs(enemy) do
					local opacity = 155
				
					if Menu.HUDSettings.HUDType == 1 then
						x = HUDInfos.x + ( ( i - 1 ) * 161 )
						y = HUDInfos.y + 17
					elseif Menu.HUDSettings.HUDType == 2 then
						x = HUDInfos.x
						y = HUDInfos.y + 17  + ( ( i - 1 ) * 100 )
					end
					
					if hero.dead or not hero.visible then
						opacity = 50
					else
						opacity = 155
					end
					
					DrawTextA(hero.charName.." ("..hero.level..")", 16, x, y - 20, ARGB(opacity,255,255,255))
					
					DrawTextA("D", 27, x + 6, y + 2, ARGB(opacity + 100,0,0,0))
					
					if hero:GetSpellData(SUMMONER_1).currentCd > 0 then
						DrawRectangle(x, y, 30, 30, ARGB(opacity,140,28,28))
					else
						DrawRectangle(x, y, 30, 30, ARGB(opacity,75,150,51))
					end
					
					DrawTextA("F", 27, x + 6, y + 33, ARGB(opacity + 100,0,0,0))
					
					if hero:GetSpellData(SUMMONER_2).currentCd > 0 then
						DrawRectangle(x, y + 31, 30, 30, ARGB(opacity,140,28,28))
					else
						DrawRectangle(x, y + 31, 30, 30, ARGB(opacity,75,150,51))
					end
					
					DrawTextA("Q", 27, x + 36, y + 33, ARGB(opacity + 100,0,0,0))
					
					if hero:GetSpellData(_Q).currentCd > 0 then
						DrawRectangle(x + 31, y + 31, 30, 30, ARGB(opacity,140,28,28))
					else
						DrawRectangle(x + 31, y + 31, 30, 30, ARGB(opacity,75,150,51))
					end
					
					DrawTextA("W", 27, x + 67, y + 33, ARGB(opacity + 100,0,0,0))
					
					if hero:GetSpellData(_W).currentCd > 0 then
						DrawRectangle(x + 62, y + 31, 30, 30, ARGB(opacity,140,28,28))
					else
						DrawRectangle(x + 62, y + 31, 30, 30, ARGB(opacity,75,150,51))
					end
					
					DrawTextA("E", 27, x + 100, y + 33, ARGB(opacity + 100,0,0,0))
					
					if hero:GetSpellData(_E).currentCd > 0 then
						DrawRectangle(x + 93, y + 31, 30, 30, ARGB(opacity,140,28,28))
					else
						DrawRectangle(x + 93, y + 31, 30, 30, ARGB(opacity,75,150,51))
					end
					
					DrawTextA("R", 27, x + 130, y + 33, ARGB(opacity + 100,0,0,0))
					
					if hero:GetSpellData(_R).currentCd > 0 then
						DrawRectangle(x + 124, y + 31, 30, 30, ARGB(opacity,140,28,28))
					else
						DrawRectangle(x + 124, y + 31, 30, 30, ARGB(opacity,75,150,51))
					end
					
					local HP = hero.health / hero.maxHealth * 123
					
					if HP == 0 then
						DrawRectangle(x + 31, y, 123, 30, ARGB(opacity,0,0,0))
						DrawTextA("Dead", 25, x + 36, y + 5, ARGB(150,255,0,0))
					else
						if hero.health / hero.maxHealth * 100 < 25 then
							DrawRectangle(x + 31, y, HP, 19, ARGB(opacity,255,71,71))
							DrawRectangle(x + 31 + HP, y, 123 - HP, 19, ARGB(opacity,215,244,218))
						else
							DrawRectangle(x + 31, y, HP, 19, ARGB(opacity,26,190,81))
							DrawRectangle(x + 31 + HP, y, 123 - HP, 19, ARGB(opacity,215,244,218))
						end
						
						local MP = hero.mana / hero.maxMana * 75
						
						if MP > 0 then
							DrawRectangle(x + 31, y + 20, MP, 10, ARGB(opacity, ChampionManaBarColor[hero.charName](hero).R, ChampionManaBarColor[hero.charName](hero).G, ChampionManaBarColor[hero.charName](hero).B))
							DrawRectangle(x + 31 + MP, y + 20, 123 - MP, 10, ARGB(opacity,214,214,214))
						end
					end
				end
			elseif Menu.HUDSettings.HUDStyle == 4 then
				for i, hero in pairs(enemy) do
					if Menu.HUDSettings.HUDType == 1 then
						x = HUDInfos.x + 29 + ( ( i - 1 ) * 200 )
						y = HUDInfos.y + 17
					elseif Menu.HUDSettings.HUDType == 2 then
						x = HUDInfos.x + 29
						y = HUDInfos.y + 17 + ( ( i - 1 ) * 60 )
					end
					
					local HP = hero.health / hero.maxHealth * 140
					
					if HP == 0 then
						DrawTextA(hero.charName, 16, x + 150, y - 20, ARGB(150,255,0,0), "right")
						
						DrawRectangle(x, y + 5, 5, 25, ARGB(100,255,0,0))
						DrawRectangle(x, y, 150, 5, ARGB(100,255,0,0))
						DrawRectangle(x, y + 30, 150, 5, ARGB(100,255,0,0))
						DrawRectangle(x + 145, y + 5, 5, 25, ARGB(100,255,0,0))
					else
						if hero.visible then
							DrawTextA(hero.charName.." ("..hero.level..")", 16, x + 150, y - 20, ARGB(150,255,255,255), "right")
							
							DrawRectangle(x, y + 5, 5, 25, ARGB(100,255,255,255))
							DrawRectangle(x, y, 150, 5, ARGB(100,255,255,255))
							DrawRectangle(x, y + 30, 150, 5, ARGB(100,255,255,255))
							DrawRectangle(x + 145, y + 5, 5, 25, ARGB(100,255,255,255))
							DrawRectangle(x + 5, y + 15, 140, 5, ARGB(100,255,255,255))
						else
							DrawTextA(hero.charName.." ("..hero.level..")", 16, x + 150, y - 20, ARGB(150,255,200,0), "right")
							
							DrawTextA("SS", 20, x - 30, y + 8, ARGB(150,255,200,0))
							
							DrawRectangle(x, y + 5, 5, 25, ARGB(100,255,200,0))
							DrawRectangle(x, y, 150, 5, ARGB(100,255,200,0))
							DrawRectangle(x, y + 30, 150, 5, ARGB(100,255,200,0))
							DrawRectangle(x + 145, y + 5, 5, 25, ARGB(100,255,200,0))
							DrawRectangle(x + 5, y + 15, 140, 5, ARGB(100,255,200,0))
						end
						
						if hero.health / hero.maxHealth * 100 < 25 then
							DrawLine(x + 5, y + 10, x + 5 + HP, y + 10, 10, ARGB(100,255,71,71))
						else
							DrawLine(x + 5, y + 10, x + 5 + HP, y + 10, 10, ARGB(100,26,190,81))
						end
						
						local MP = hero.mana / hero.maxMana * 140
						
						if MP > 0 then
							DrawLine(x + 5, y + 25, x + 5 + MP, y + 25, 10, ARGB(100, ChampionManaBarColor[hero.charName](hero).R, ChampionManaBarColor[hero.charName](hero).G, ChampionManaBarColor[hero.charName](hero).B))
						end
					end
					
					if hero:GetSpellData(SUMMONER_1).currentCd > 0 then
						DrawTextA(mfloor(hero:GetSpellData(SUMMONER_1).currentCd).."s", 14, x + 155, y + 10, ARGB(150,255,0,0))
					else
						DrawTextA("D", 16, x + 155, y + 1, ARGB(150,0,255,0))
					end
					
					if hero:GetSpellData(SUMMONER_2).currentCd > 0 then
						DrawTextA(mfloor(hero:GetSpellData(SUMMONER_2).currentCd).."s", 14, x + 155, y + 20, ARGB(150,255,0,0))
					else
						DrawTextA("F", 16, x + 155, y + 18, ARGB(150,0,255,0))
					end
					
					local cdR = 0
					
					if hero:GetSpellData(_R).level ~= 0 then
						if hero:GetSpellData(_R).cd == 0 then
							cdR = 22
						else
							cdR = ( 100 - ( hero:GetSpellData(_R).currentCd / hero:GetSpellData(_R).cd * 100 ) ) / 100 * 22
						end
					else
						cdR = nil
					end
					
					if cdR ~= nil then
						if hero:GetSpellData(_R).currentCd > 0 then
							DrawTextA("R:"..mfloor(hero:GetSpellData(_R).currentCd).."s", 16, x + 10, y - 20, ARGB(150,255,0,0))
						else
							DrawTextA("R", 16, x + 10, y - 20, ARGB(150,0,255,0))
						end
					else
						DrawTextA("R", 16, x + 10, y - 20, ARGB(150,227,48,255))
					end
				end
			end
		end
	end
end

local function DrawHUDBackground()
	if MenuVisible and Menu.HUDSettings.HUDON then
		DrawRectangle(HUDInfos.x, HUDInfos.y - 30, 120, 30, HUDInfosColor)
		DrawTextA("Move HUD", 26, HUDInfos.x + 60, HUDInfos.y - 15, ARGB(255,255,255,255), "center", "center")
		DrawRectangle(HUDInfos.x, HUDInfos.y, HUDInfos.w, HUDInfos.h, HUDInfosColor)
		DrawRectangle(HUDInfos.x - 3, HUDInfos.y - 33, 123, 3, ARGB(255,255,255,255))
		DrawRectangle(HUDInfos.x - 3, HUDInfos.y - 30, 3, HUDInfos.h + 33, ARGB(255,255,255,255))
		DrawRectangle(HUDInfos.x, HUDInfos.y + HUDInfos.h, HUDInfos.w + 3, 3, ARGB(255,255,255,255))
		DrawRectangle(HUDInfos.x + 120, HUDInfos.y - 33, 3, 33, ARGB(255,255,255,255))
		DrawRectangle(HUDInfos.x + 123, HUDInfos.y - 3, HUDInfos.w - 120, 3, ARGB(255,255,255,255))
		DrawRectangle(HUDInfos.x + HUDInfos.w, HUDInfos.y, 3, HUDInfos.h, ARGB(255,255,255,255))
	end
end

local function DrawHPBarFPSFriendly(hero)
	local barPos = GetUnitHPBarPos(hero)
	local off = GetUnitHPBarOffset(hero)
	local yOff = ({['Annie'] = -12})[hero.charName]
	local y = barPos.y + (yOff or 0) + (off.y * 53) - 13
	local xOff = ({['AniviaEgg'] = -14,['Annie'] = -10,['Darius'] = -7,['Renekton'] = -7,['Sion'] = -7,['Thresh'] = -4,})[hero.charName]
	local x = barPos.x + (xOff or 0) - 50
		
	if OnScreen(barPos.x, barPos.y) and not hero.dead and hero.visible then
		if hero:GetSpellData(_Q).level ~= 0 then
			if hero:GetSpellData(_Q).currentCd == 0 then
				DrawTextA("Q", 14, x, y, ARGB(255, 0, 255, 0), "center", "center")
			else
				DrawTextA(mfloor(hero:GetSpellData(_Q).currentCd).."s", 14, x, y, ARGB(255, 255, 0, 0), "center", "center")
			end
		else
			DrawTextA("Q", 14, x, y, ARGB(255, 0, 216, 255), "center", "center")
		end

		if hero:GetSpellData(_W).level ~= 0 then
			if hero:GetSpellData(_W).currentCd == 0 then
				DrawTextA("W", 14, x + 30, y, ARGB(255, 0, 255, 0), "center", "center")
			else
				DrawTextA(mfloor(hero:GetSpellData(_W).currentCd).."s", 14, x + 30, y, ARGB(255, 255, 0, 0), "center", "center")
			end
		else
			DrawTextA("W", 14, x + 30, y, ARGB(255, 0, 216, 255), "center", "center")
		end

		if hero:GetSpellData(_E).level ~= 0 then
			if hero:GetSpellData(_E).currentCd == 0 then
				DrawTextA("E", 14, x + 60, y, ARGB(255, 0, 255, 0), "center", "center")
			else
				DrawTextA(mfloor(hero:GetSpellData(_E).currentCd).."s", 14, x + 60, y, ARGB(255, 255, 0, 0), "center", "center")
			end
		else
			DrawTextA("E", 14, x + 60, y, ARGB(255, 0, 216, 255), "center", "center")
		end

		if hero:GetSpellData(_R).level ~= 0 then
			if hero:GetSpellData(_R).currentCd == 0 then
				DrawTextA("R", 14, x + 90, y, ARGB(255, 0, 255, 0), "center", "center")
			else
				DrawTextA(mfloor(hero:GetSpellData(_R).currentCd).."s", 14, x + 90, y, ARGB(255, 255, 0, 0), "center", "center")
			end
		else
			DrawTextA("R", 14, x + 90, y, ARGB(255, 0, 216, 255), "center", "center")
		end

		if hero:GetSpellData(SUMMONER_1).currentCd == 0 then
			DrawTextA("D", 14, x - 23, y + 14, ARGB(255, 0, 255, 0), "right", "center")
		else
			DrawTextA("D:"..mfloor(hero:GetSpellData(SUMMONER_1).currentCd).."s", 14, x - 23, y + 14, ARGB(255, 255, 0, 0), "right", "center")
		end

		if hero:GetSpellData(SUMMONER_2).currentCd == 0 then
			DrawTextA("F", 14, x - 23, y + 25, ARGB(255, 0, 255, 0), "right", "center")
		else
			DrawTextA("F:"..mfloor(hero:GetSpellData(SUMMONER_2).currentCd).."s", 14, x - 23, y + 25, ARGB(255, 255, 0, 0), "right", "center")
		end
	end
end

local function DrawHPBar()
	if Menu.HPBarSettings.HPbarON then
		if Menu.HPBarSettings.HPBarType == 1 then
			for i, hero in pairs(ally) do
				local barPos = GetUnitHPBarPos(hero)
				local off = GetUnitHPBarOffset(hero)
				local yOff = ({['Annie'] = -12})[hero.charName]
				local y = barPos.y + (yOff or 0) + (off.y * 53) + 2
				local xOff = ({['AniviaEgg'] = -14,['Annie'] = -10,['Darius'] = -7,['Renekton'] = -7,['Sion'] = -7,['Thresh'] = -4,})[hero.charName]
				local x = barPos.x + (xOff or 0) - 25
				
				local cdQ, cdW, cdE, cdR = 0
				
				if hero:GetSpellData(_Q).level ~= 0 then
					if hero:GetSpellData(_Q).cd == 0 then
						cdQ = 23
					else
						cdQ = ( 100 - ( hero:GetSpellData(_Q).currentCd / hero:GetSpellData(_Q).cd * 100 ) ) / 100 * 23
					end
				else
					cdQ = 0
				end
				
				if hero:GetSpellData(_W).level ~= 0 then
					if hero:GetSpellData(_W).cd == 0 then
						cdW = 23
					else
						cdW = ( 100 - ( hero:GetSpellData(_W).currentCd / hero:GetSpellData(_W).cd * 100 ) ) / 100 * 23
					end
				else
					cdW = 0
				end
				
				if hero:GetSpellData(_E).level ~= 0 then
					if hero:GetSpellData(_E).cd == 0 then
						cdE = 23
					else
						cdE = ( 100 - ( hero:GetSpellData(_E).currentCd / hero:GetSpellData(_E).cd * 100 ) ) / 100 * 23
					end
				else
					cdE = 0
				end
				
				if hero:GetSpellData(_R).level ~= 0 then
					if hero:GetSpellData(_R).cd == 0 then
						cdR = 23
					else
						cdR = ( 100 - ( hero:GetSpellData(_R).currentCd / hero:GetSpellData(_R).cd * 100 ) ) / 100 * 23
					end
				else
					cdR = 0
				end
				
				if OnScreen(barPos.x, barPos.y) and not hero.dead and hero.visible then
					HPBarSprite:Draw(x-44, y-8, 255)
					if cdQ ~= nil then
						DrawLine(x-41, y+12, x-41+cdQ, y+12, 3, ARGB(255,0,191,9))
					end
					if cdE ~= nil then
						DrawLine(x-14, y+12, x-14+cdW, y+12, 3, ARGB(255,0,191,9))
					end
					if cdW ~= nil then
						DrawLine(x+13, y+12, x+13+cdE, y+12, 3, ARGB(255,0,191,9))
					end
					if cdR ~= nil then
						DrawLine(x+40, y+12, x+40+cdR, y+12, 3, ARGB(255,0,191,9))
					end
				end
			end
			
			for i, hero in pairs(enemy) do
				local barPos = GetUnitHPBarPos(hero)
				local off = GetUnitHPBarOffset(hero)
				local yOff = ({['Annie'] = -12})[hero.charName]
				local y = barPos.y + (yOff or 0) + (off.y * 53) + 2
				local xOff = ({['AniviaEgg'] = -14,['Annie'] = -10,['Darius'] = -7,['Renekton'] = -7,['Sion'] = -7,['Thresh'] = -4,})[hero.charName]
				local x = barPos.x + (xOff or 0) - 25
				
				local cdQ, cdW, cdE, cdR = 0
				
				if hero:GetSpellData(_Q).level ~= 0 then
					if hero:GetSpellData(_Q).cd == 0 then
						cdQ = 23
					else
						cdQ = ( 100 - ( hero:GetSpellData(_Q).currentCd / hero:GetSpellData(_Q).cd * 100 ) ) / 100 * 23
					end
				else
					cdQ = 0
				end
				
				if hero:GetSpellData(_W).level ~= 0 then
					if hero:GetSpellData(_W).cd == 0 then
						cdW = 23
					else
						cdW = ( 100 - ( hero:GetSpellData(_W).currentCd / hero:GetSpellData(_W).cd * 100 ) ) / 100 * 23
					end
				else
					cdW = 0
				end
				
				if hero:GetSpellData(_E).level ~= 0 then
					if hero:GetSpellData(_E).cd == 0 then
						cdE = 23
					else
						cdE = ( 100 - ( hero:GetSpellData(_E).currentCd / hero:GetSpellData(_E).cd * 100 ) ) / 100 * 23
					end
				else
					cdE = 0
				end
				
				if hero:GetSpellData(_R).level ~= 0 then
					if hero:GetSpellData(_R).cd == 0 then
						cdR = 23
					else
						cdR = ( 100 - ( hero:GetSpellData(_R).currentCd / hero:GetSpellData(_R).cd * 100 ) ) / 100 * 23
					end
				else
					cdR = 0
				end
				
				if OnScreen(barPos.x, barPos.y) and not hero.dead and hero.visible then
					HPBarSprite:Draw(x-44, y-6, 255)
					if cdQ ~= nil then
						DrawLine(x-41, y+14, x-41+cdQ, y+14, 3, ARGB(255,0,191,9))
					end
					if cdE ~= nil then
						DrawLine(x-14, y+14, x-14+cdW, y+14, 3, ARGB(255,0,191,9))
					end
					if cdW ~= nil then
						DrawLine(x+13, y+14, x+13+cdE, y+14, 3, ARGB(255,0,191,9))
					end
					if cdR ~= nil then
						DrawLine(x+40, y+14, x+40+cdR, y+14, 3, ARGB(255,0,191,9))
					end
				end
			end
		elseif Menu.HPBarSettings.HPBarType == 2 then
			for i, hero in pairs(ally) do
				DrawHPBarFPSFriendly(hero)
			end
			
			for i, hero in pairs(enemy) do
				DrawHPBarFPSFriendly(hero)
			end
		end
	end
end

local function DrawEnemyPath()
	if Menu.WaypointsSettings.WaypointsON then
		for i, hero in pairs(enemy) do
			if hero.hasMovePath then
				if hero.path:Path(2) == nil then
					DrawLine3D(hero.x, hero.y, hero.z, hero.path:Path(1).x, hero.path:Path(1).y, hero.path:Path(1).z, 2, ARGB(255,255,255,255))
				else
					local a=2
					while(hero.path:Path(a) ~= nil) do
						DrawLine3D(hero.path:Path(a-1).x, hero.path:Path(a-1).y, hero.path:Path(a-1).z, hero.path:Path(a).x, hero.path:Path(a).y, hero.path:Path(a).z, 2, ARGB(255,255,255,255))
						a = a+1
					end
					DrawCircle3D(hero.path:Path(a-1).x, hero.path:Path(a-1).y, hero.path:Path(a-1).z, 30, 2, ARGB(255,255,255,255), 400)
					DrawLine3D(hero.path:Path(a-1).x-30, hero.path:Path(a-1).y, hero.path:Path(a-1).z, hero.path:Path(a-1).x+30, hero.path:Path(a-1).y, hero.path:Path(a-1).z, 2, ARGB(255,255,255,255))
					DrawLine3D(hero.path:Path(a-1).x, hero.path:Path(a-1).y, hero.path:Path(a-1).z-30, hero.path:Path(a-1).x, hero.path:Path(a-1).y, hero.path:Path(a-1).z+30, 2, ARGB(255,255,255,255))
					DrawText3D(hero.charName, hero.path:Path(a-1).x-50, hero.path:Path(a-1).y-50, hero.path:Path(a-1).z, 15, ARGB(255,255,255,255))
				end
			end
		end
	end
end

local function DrawTowers()
	for _, t in pairs(towers) do
		local tf = WorldToScreen(D3DXVECTOR3(t.x, t.y, t.z))
		if OnScreen(tf.x, tf.y) then
			DrawCircle3D(t.x, t.y, t.z, 775 + t.boundingRadius, 1, RGB(255,50,50), Menu.TowersSettings.TowerRangeQuality)
		end
	end
end

local function DrawInfos()
	if Menu.InfosSettings.DrawInfosON then
		DrawTextA("FPS : "..GetFPS().."   "..GetLatency().." ms", Menu.InfosSettings.InfosSize, Menu.InfosSettings.InfosPosX, Menu.InfosSettings.InfosPosY, ARGB(255,255,255,255))
	end
	
	if Menu.InfosSettings.DrawDateON then
		DrawTextA(os.date(), Menu.InfosSettings.DateSize, Menu.InfosSettings.DatePosX, Menu.InfosSettings.DatePosY, ARGB(255,255,255,255))
	end
end

local function CreateObj(obj)
	if obj.name == "SRU_Dragon_Death.troy" then
		DTimer = 1000 * ( GetInGameTimer() + 360 )
	end
	
	if obj.name == "SRU_Baron_Death.troy" then
		BTimer = 1000 * ( GetInGameTimer() + 420 )
	end
end

local function Animation(unit, animation)
	-- Blue Buff / Blue Team
	if unit.name == "SRU_Blue1.1.1" and animation == "Death" then
		if BTBB == nil then
			BTBB = 1
		elseif BTBB == 2 then
			BTBBTimer = 1000 * ( GetInGameTimer() + 300 )
			BTBB = 0
		else
			BTBB = BTBB + 1
		end
	end
	if unit.name == "SRU_BlueMini1.1.2" and animation == "Death" then
		if BTBB == nil then
			BTBB = 1
		elseif BTBB == 2 then
			BTBBTimer = 1000 * ( GetInGameTimer() + 300 )
			BTBB = 0
		else
			BTBB = BTBB + 1
		end
	end
	if unit.name == "SRU_BlueMini21.1.3" and animation == "Death" then
		if BTBB == nil then
			BTBB = 1
		elseif BTBB == 2 then
			BTBBTimer = 1000 * ( GetInGameTimer() + 300 )
			BTBB = 0
		else
			BTBB = BTBB + 1
		end
	end
	
	-- Blue Buff / Red Team
	if unit.name == "SRU_Blue7.1.1" and animation == "Death" then
		if RTBB == nil then
			RTBB = 1
		elseif RTBB == 2 then
			RTBBTimer = 1000 * ( GetInGameTimer() + 300 )
			RTBB = 0
		else
			RTBB = RTBB + 1
		end
	end
	if unit.name == "SRU_BlueMini7.1.2" and animation == "Death" then
		if RTBB == nil then
			RTBB = 1
		elseif RTBB == 2 then
			RTBBTimer = 1000 * ( GetInGameTimer() + 300 )
			RTBB = 0
		else
			RTBB = RTBB + 1
		end
	end
	if unit.name == "SRU_BlueMini27.1.3" and animation == "Death" then
		if RTBB == nil then
			RTBB = 1
		elseif RTBB == 2 then
			RTBBTimer = 1000 * ( GetInGameTimer() + 300 )
			RTBB = 0
		else
			RTBB = RTBB + 1
		end
	end
	
	-- Red Buff / Blue Team
	if unit.name == "SRU_Red4.1.1" and animation == "Death" then
		if BTRB == nil then
			BTRB = 1
		elseif BTRB == 2 then
			BTRBTimer = 1000 * ( GetInGameTimer() + 300 )
			BTRB = 0
		else
			BTRB = BTRB + 1
		end
	end
	if unit.name == "SRU_RedMini4.1.2" and animation == "Death" then
		if BTRB == nil then
			BTRB = 1
		elseif BTRB == 2 then
			BTRBTimer = 1000 * ( GetInGameTimer() + 300 )
			BTRB = 0
		else
			BTRB = BTRB + 1
		end
	end
	if unit.name == "SRU_RedMini4.1.3" and animation == "Death" then
		if BTRB == nil then
			BTRB = 1
		elseif BTRB == 2 then
			BTRBTimer = 1000 * ( GetInGameTimer() + 300 )
			BTRB = 0
		else
			BTRB = BTRB + 1
		end
	end
	
	-- Red Buff / Red Team
	if unit.name == "SRU_Red10.1.1" and animation == "Death" then
		if RTRB == nil then
			RTRB = 1
		elseif RTRB == 2 then
			RTRBTimer = 1000 * ( GetInGameTimer() + 300 )
			RTRB = 0
		else
			RTRB = RTRB + 1
		end
	end
	if unit.name == "SRU_RedMini10.1.2" and animation == "Death" then
		if RTRB == nil then
			RTRB = 1
		elseif RTRB == 2 then
			RTRBTimer = 1000 * ( GetInGameTimer() + 300 )
			RTRB = 0
		else
			RTRB = RTRB + 1
		end
	end
	if unit.name == "SRU_RedMini10.1.3" and animation == "Death" then
		if RTRB == nil then
			RTRB = 1
		elseif RTRB == 2 then
			RTRBTimer = 1000 * ( GetInGameTimer() + 300 )
			RTRB = 0
		else
			RTRB = RTRB + 1
		end
	end
end

local function Timers()
	-- Baron
	if BTimer ~= nil then
		if BTimer == 0 then
			
		else
			BTimer = BTimer - 1
			BRespawnS = (BTimer - ( GetInGameTimer() * 1000))/1000
			nMins = sformat("%02.f", mfloor(BRespawnS/60))
			nSecs = sformat("%02.f", mfloor(BRespawnS - nMins *60))
			BRespawn = nMins..":" ..nSecs
		end
	end
	
	-- Dragon
	if DTimer ~= nil then
		if DTimer == 0 then
			
		else
			DTimer = DTimer - 1
			DRespawnS = (DTimer - ( GetInGameTimer() * 1000))/1000
			nMins = sformat("%02.f", mfloor(DRespawnS/60))
			nSecs = sformat("%02.f", mfloor(DRespawnS - nMins *60))
			DRespawn = nMins..":" ..nSecs
		end
	end
	
	-- Blue Buff / Blue Team
	if BTBBTimer ~= nil then
		if BTBBTimer == 0 then
			
		else
			BTBBTimer = BTBBTimer - 1
			BTBBRespawnS = (BTBBTimer - ( GetInGameTimer() * 1000))/1000
			nMins = sformat("%02.f", mfloor(BTBBRespawnS/60))
			nSecs = sformat("%02.f", mfloor(BTBBRespawnS - nMins *60))
			BTBBRespawn = nMins..":" ..nSecs
		end
	end
	
	-- Blue Buff / Red Team
	if RTBBTimer ~= nil then
		if RTBBTimer == 0 then
			
		else
			RTBBTimer = RTBBTimer - 1
			RTBBRespawnS = (RTBBTimer - ( GetInGameTimer() * 1000))/1000
			nMins = sformat("%02.f", mfloor(RTBBRespawnS/60))
			nSecs = sformat("%02.f", mfloor(RTBBRespawnS - nMins *60))
			RTBBRespawn = nMins..":" ..nSecs
		end
	end
	
	-- Red Buff / Blue Team
	if BTRBTimer ~= nil then
		if BTRBTimer == 0 then
			
		else
			BTRBTimer = BTRBTimer - 1
			BTRBRespawnS = (BTRBTimer - ( GetInGameTimer() * 1000))/1000
			nMins = sformat("%02.f", mfloor(BTRBRespawnS/60))
			nSecs = sformat("%02.f", mfloor(BTRBRespawnS - nMins *60))
			BTRBRespawn = nMins..":" ..nSecs
		end
	end
	
	-- Red Buff / Red Team
	if RTRBTimer ~= nil then
		if RTRBTimer == 0 then
			
		else
			RTRBTimer = RTRBTimer - 1
			RTRBRespawnS = (RTRBTimer - ( GetInGameTimer() * 1000))/1000
			nMins = sformat("%02.f", mfloor(RTRBRespawnS/60))
			nSecs = sformat("%02.f", mfloor(RTRBRespawnS - nMins *60))
			RTRBRespawn = nMins..":" ..nSecs
		end
	end
end

local function DrawTimers()
	local x = WINDOW_W - 200
	
	-- Exemple of notification for Baron
	if BRespawnS < 60 and BRespawnS ~= nil then
		local y = WINDOW_H - 450
		NotificationSprite:Draw(x, y, 255)
		BaronSprite:Draw(x + 8, y + 8, 255)
		DrawTextA("Baron", 23, x + 120, y + 11, ARGB(255,25,148,115))
		DrawTextA(BRespawn, 35, x + 108, y + 43, ARGB(255,25,148,115))
	end
	
	-- Second notif
	-- local y = WINDOW_H - 575
	
	-- Third notif
	-- local y = WINDOW_H - 700
	
	-- Last notif
	-- local y = WINDOW_H - 825
	
	-- Coords for text
	-- DrawTextA("Baron", 23, x + 120, y + 11, ARGB(255,25,148,115))
	-- DrawTextA("Dragon", 23, x + 115, y + 11, ARGB(255,25,148,115))
	-- DrawTextA("Red Team", 23, x + 101, y + 11, ARGB(255,25,148,115))
	-- DrawTextA("Blue Team", 23, x + 97, y + 11, ARGB(255,25,148,115))
end

local function GetJunglerPos(hero)
	if MapPosition:onTopLane(hero) then
		return ("is ganking top lane !")
	elseif MapPosition:onMidLane(hero) then
		return ("is ganking mid lane !")
	elseif MapPosition:onBotLane(hero) then
		return ("is ganking bot lane !")
	elseif MapPosition:inTopRiver(hero) then
		return ("is in top river !")
	elseif MapPosition:inBottomRiver(hero) then
		return ("is in bottom river !")
	elseif MapPosition:inTopLeftJungle(hero) then
		return ("is in top left jungle !")
	elseif MapPosition:inBottomRightJungle(hero) then
		return ("is in bottom right jungle !")
	elseif MapPosition:inBottomLeftJungle(hero) then
		return ("is in bottom left jungle !")
	elseif MapPosition:inTopRightJungle(hero) then
		return ("is in top right jungle !")
	end
end

local function DrawEnemyJungler()
	if Menu.GankSettings.GankAlertON then
		for i, hero in pairs(junglers) do
			if hero and hero.visible and not hero.dead and GetJunglerPos(hero) then
				GankSprite:Draw(GankAlertInfos.x, GankAlertInfos.y, 255)
				
				DrawTextA(supper(hero.charName or ""), 32, GankAlertInfos.x + 64, GankAlertInfos.y + 24, ARGB(255,0,96,43))
				DrawTextA(supper(GetJunglerPos(myHero) or ""), 18, GankAlertInfos.x + 64, GankAlertInfos.y + 50, ARGB(255,0,96,43))
			end
		end
	end
end

local function DrawGankAlertBackground()
	if MenuVisible and Menu.GankSettings.GankAlertON then
		DrawRectangle(GankAlertInfos.x, GankAlertInfos.y - 30, 180, 30, GankAlertInfosColor)
		DrawTextA("Move Gank Alert", 26, GankAlertInfos.x + 90, GankAlertInfos.y - 15, ARGB(255,255,255,255), "center", "center")
		DrawRectangle(GankAlertInfos.x, GankAlertInfos.y, 300, 100, GankAlertInfosColor)
		DrawRectangle(GankAlertInfos.x - 3, GankAlertInfos.y - 33, 183, 3, ARGB(255,255,255,255))
		DrawRectangle(GankAlertInfos.x - 3, GankAlertInfos.y - 30, 3, 100 + 33, ARGB(255,255,255,255))
		DrawRectangle(GankAlertInfos.x, GankAlertInfos.y + 100, 300 + 3, 3, ARGB(255,255,255,255))
		DrawRectangle(GankAlertInfos.x + 180, GankAlertInfos.y - 33, 3, 33, ARGB(255,255,255,255))
		DrawRectangle(GankAlertInfos.x + 183, GankAlertInfos.y - 3, 300 - 180, 3, ARGB(255,255,255,255))
		DrawRectangle(GankAlertInfos.x + 300, GankAlertInfos.y, 3, 100, ARGB(255,255,255,255))
	end
end

local function CreateWard(object)
    local function GetCorrectTimer(object)
         DelayAction( function()
            if object and object.valid and object.name then
                greenWardTable[#greenWardTable+1] = { position = object.pos, endTime = mfloor(object.mana + GetInGameTimer() - 1), object = object }
            end
        end, 5.00)
    end

    if object and object.valid and object.type and object.name then
        if object.team == TEAM_ENEMY then
            if object.mana and object.maxMana then
                if object.name == "VisionWard" and object.maxMana == 0 then
                    pinkWardTable[#pinkWardTable+1] = object
                elseif object.name ~= "WardCorpse" and object.name:lower():find("ward") and not object.name:lower():find("warddeath") then
                    GetCorrectTimer(object)
                end
            end
        end
    end
end

local function DeleteWard(object)
    if object and object ~= nil and object.valid and object.type == "obj_AI_Minion" and object.team ~= myHero.team then
        local name = object.name and object.name:lower() or nil
        if not name then return end
        if not name:find("corpse") and (name:find("ward") or name:find("trinket")) and not name:find("idle") and object.maxMana > 0 then
            for i = 1, #greenWardTable do
                local ward = greenWardTable[i]
                if ward and ward.object and ward.object.valid and object.networkID == ward.object.networkID then
                    if greenWardTable[i] ~= nil then
                        greenWardTable[i] = nil
                    end
                end
            end
        elseif name:find("vision") then
            for i = 1, #pinkWardTable do
                local ward = pinkWardTable[i]
                if ward and ward.valid and object.networkID == ward.networkID then
                    if pinkWardTable[i] ~= nil then
                        pinkWardTable[i] = nil
                    end
                end
            end
        end
    end
end

local function DrawWards()
    local function DrawPinkWard(ward)
        if ward ~= nil and ward.object == nil and ward.health > 0 then
            if ward.maxMana == 0 then
                local screenPos = WorldToScreen(ward.pos)
                if OnScreen(screenPos, screenPos) then
                    DrawCircle3D(ward.pos.x, ward.pos.y, ward.pos.z, 75, 2, ARGB(255,255,0,255), Menu.WardsSettings.WardTrackerQuality)
                    DrawTextA("Pink ward", 16, screenPos.x, screenPos.y, ARGB(255,255,0,255), "center", "center")
                end
            end
        end
    end

    local function DrawGreenWard(ward)
         if ward ~= nil and ward.object.health > 0 and ward.endTime >= GetInGameTimer() then
            local screenPos = WorldToScreen(ward.position)
            if OnScreen(screenPos, screenPos) then
                DrawCircle3D(ward.position.x, ward.position.y, ward.position.z, 75, 2, ARGB(255,0,190,0), Menu.WardsSettings.WardTrackerQuality)
                DrawTextA("Ward", 16, screenPos.x, screenPos.y - 10, ARGB(255,0,190,0), "center", "center")
                DrawTextA(mfloor(ward.endTime - GetInGameTimer()), 16, screenPos.x, screenPos.y + 10, ARGB(255,0,190,0), "center", "center")
            end
        end
    end

    for i = 1, #pinkWardTable do
        DrawPinkWard(pinkWardTable[i])
    end

    for i = 1, #greenWardTable do
        DrawGreenWard(greenWardTable[i])
    end
end

AddLoadCallback(function ()
	local specialUsers = {
		['S1mple'] = 'Hey Senpai :$ !',
		['Nebelwolfi'] = 'Yo wolfi !',
		['Xivia'] = 'Go use your own awareness noob !',
		['GNAAAAR'] = 'Hey Gnob !',
		['Totally Legit'] = 'Go away gay Maik !',
		['Aroc'] = 'Welcome Salt King !',
		['JaiKor'] = 'Hello JaiKing :)',
		['QQQ'] = 'Hello kitty QCat :)',
		['Identity'] = 'Identito is in da place :o'
	}

	if GetUser() == "DrPhoenix" then
		PrintMsg('Hello master Phoenix !')
		Update()
	else
		if specialUsers[GetUser()] then
			PrintMsg(specialUsers[GetUser()])
		else
			PrintMsg('Hello '..GetUser()..'!')
		end
		Update()
	end
	
	AddMenu()
	
	GetEnemyTowers()
	
	LoadSprites()
	
	if GetSave("DrAwareness").HUDInfos == nil then
		HUDInfos = { x = 100 , y = 100 , xInit = 0 , yInit = 0 , w = 264 , h = 492 , s = 1 , t = 2 }
	else
		HUDInfos = GetSave("DrAwareness").HUDInfos
	end
	
	if GetSave("DrAwareness").GankAlertInfos == nil then
		GankAlertInfos = { x = ( WINDOW_W / 2 ) - 150 , y = 200 , xInit = 0 , yInit = 0 }
	else
		GankAlertInfos = GetSave("DrAwareness").GankAlertInfos
	end
	
	UpdateMenuValues()
	
	AddDrawCallback(function ()
		DrawHUD()
		DrawHUDBackground()
		DrawHPBar()
		DrawEnemyPath()
		DrawTowers()
		DrawInfos()
		DrawEnemyJungler()
		DrawGankAlertBackground()
		-- DrawTimers()
		DrawWards()
	end)
	
	AddCreateObjCallback(function (object)
		CreateWard(object)
		CreateObj(object)
	end)
	
	AddDeleteObjCallback(function (object)
		DeleteWard(object)
	end)
	
	AddTickCallback(function ()
		Timers()
	end)
	
	AddAnimationCallback(function (unit, animation)
		Animation(unit, animation)
	end)
	
	AddMsgCallback(function(msg, key)
		DetectMenu(msg, key)
	end)
	
	PrintMsg("Doctor Awareness (v"..version..") successfully loaded !")
end)

AddUnloadCallback(function ()
	GetSave("DrAwareness").HUDInfos = HUDInfos
	GetSave("DrAwareness").GankAlertInfos = GankAlertInfos
	
	PrintMsg("Unloading")
	HudFancySprite:Release()
	HudClassicSprite:Release()
	for _,v in pairs(HeroSprite) do
		v:Release()
	end
	for _,v in pairs(SpellSprite) do
		v:Release()
	end
	HPBarSprite:Release()
	NotificationSprite:Release()
	BaronSprite:Release()
	DragonSprite:Release()
	RedSprite:Release()
	BlueSprite:Release()
	GankSprite:Release()
end)

AddBugsplatCallback(function ()
	GetSave("DrAwareness").HUDInfos = HUDInfos
	GetSave("DrAwareness").GankAlertInfos = GankAlertInfos
	
	local file = io.open(SCRIPT_PATH.."DrPhoenix_Awareness.bugsplat", "a")
	file:write("\n"..tostring(debug.traceback()))
	file:close()
end)