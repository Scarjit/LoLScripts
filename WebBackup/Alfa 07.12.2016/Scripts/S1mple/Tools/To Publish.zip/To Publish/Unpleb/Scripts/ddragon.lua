function print_r ( t )  --This function allows me to print a table formated
    local print_r_cache={}
    local function sub_print_r(t,indent)
        if (print_r_cache[tostring(t)]) then
            print(indent.."*"..tostring(t))
        else
            print_r_cache[tostring(t)]=true
            if (type(t)=="table") then
                for pos,val in pairs(t) do
                    if (type(val)=="table") then
                        print(indent.."["..pos.."] => "..tostring(t).." {")
                        sub_print_r(val,indent..string.rep(" ",string.len(pos)+8))
                        print(indent..string.rep(" ",string.len(pos)+6).."}")
                    elseif (type(val)=="string") then
                        print(indent.."["..pos..'] => "'..val..'"')
                    else
                        print(indent.."["..pos.."] => "..tostring(val))
                    end
                end
            else
                print(indent..tostring(t))
            end
        end
    end
    if (type(t)=="table") then
        print(tostring(t).." {")
        sub_print_r(t,"  ")
        print("}")
    else
        sub_print_r(t,"  ")
    end
    print()
end


--Just a socket downloader
local function TCPGetRequest(server, path, data, port) --Reads a file from the Internet
	local start_t = os.clock()
	local port = port or 80
	local data = data or {}
	local lua_socket = require("socket")
	local connection_tcp = lua_socket.connect(server,port)
	local requeststring = "GET "..path
	local first = true

	for i,v in pairs(data) do
		requeststring = requeststring..(first and "?" or "&")..i.."="..v
		first = false
	end
	
	requeststring = requeststring.. " HTTP/1.0\r\nHost: "..server.."\r\n\r\n"
	connection_tcp:send(requeststring)
	local response = ""
	local status
	while true do
		s,status, partial = connection_tcp:receive('*a')
		response = response..(s or partial)
		if(status == "closed" or status == "timeout")then
			break
		end
	end
	local end_t = os.clock()
	local start_content = response:find("\r\n\r\n")+4
	response = response:sub(start_content)
	return response, status, end_t-start_t
end
--END Just a socket downloader

--DEBUG --This is just to be able to use it in the normal 5.2 Console
function FileExist()
	return true
end
function GetGameVersion()
	return "6.17.1"
end
function InFountain()
	return true
end
myHero = {
	gold = 500
}
function getInventory()
	return {}
end
function BuyItem(id)
	print("Bought "..id)
end
--END DEBUG

--[[
function getInventory()
	local ret = {}
	for _, j in pairs({ ITEM_1, ITEM_2, ITEM_3, ITEM_4, ITEM_5, ITEM_6, ITEM_7 }) do
        ret[#ret+1] = myHero:getInventorySlot(j)
    end
	return ret
end
]]--

function readAll(file) --Reads all lines from a file
    local f = io.open(file, "rb")
    local content = f:read("*all")
    f:close()
    return content
end

local item_table
function GetItemData(id) --Returns an array with the itemdata of an id
	if item_table then return item_table[id] end
	
	local function DownloadItemTable()
		local m = TCPGetRequest("s1mplescripts.de", "/S1mple/Scripts/DDragonParser/getItems.php");
		file = io.open("item.lua", "w");
		file:write(m);
		file:close();
		item_table = load(m)();
	end

	if(FileExist("item.lua"))then
		local m = readAll("item.lua");
		if(m:len()==0)then
			DownloadItemTable()
		else
			item_table = load(m)();
			local version = item_table.Version
			if(version ~= GetGameVersion():sub(0,6))then
				DownloadItemTable()
			end
		end
	else
		DownloadItemTable()
	end
	return item_table[id]
end

function getreqforitem(id, skip) --Returns an array with all required items and there prices
	local item_data = GetItemData(id)
	local ret = {}
	if not skip then
		ret[#ret+1] = {id = id, cost = item_data.cost, cost_total = item_data.cost_total}
	end
	for _,v in pairs(item_data.from)do
		local id2 = GetItemData(v)
		if(#id2.from  > 0)then
			ret[#ret+1] = {childs = getreqforitem(v, true), cost = id2.cost, id = v, cost_total = id2.cost_total}
		else
			ret[#ret+1] = {id = v, cost = id2.cost, cost_total = id2.cost_total}
		end
	end
	return ret
end

function delete_already_in_inv(items, inv) --Checks if a items is already in inventory
	for i,v in pairs(items)do
		local found = false
		for i2,v2 in pairs(inv)do
			if(not found and v2 == v.id)then
				found = true
				inv[i2] = null
				items[i] = null
			end
		end
		
		if(v.childs and not found)then
			tmp_childs, inv = delete_already_in_inv(v.childs, inv)
			
		end
	end
	
	return items, inv
end

function what_can_i_afford(items) --Returns the highest price item you can buy
	local id = nil
	local price = 0
	for _,v in pairs(items)do
		if v.childs then
			if v.cost_total <= myHero.gold and (not id or(v.cost_total > price)) then
				id = v.id
				price = v.cost_total
			end
		else
			if (v.cost_total <= myHero.gold) and (not id or (v.cost_total > price)) then
				id = v.id
				price = v.cost_total
			end
		end
	end
	
	return id, price
end

function BuyStuff(id) --Buys the item by id
	local requirements = getreqforitem(id)
	local buy_list, inv = delete_already_in_inv(requirements,getInventory())
	local item, price = what_can_i_afford(buy_list)
	if item and InFountain(myHero) then
		BuyItem(item)
		local item_dat = GetItemData(item)
		print("Bought: "..item_dat.item_name.." for "..item_dat.cost_total.. " of "..myHero.gold)
	end
end


local i_want = 3046 --Phantom Dancer
BuyStuff(i_want)