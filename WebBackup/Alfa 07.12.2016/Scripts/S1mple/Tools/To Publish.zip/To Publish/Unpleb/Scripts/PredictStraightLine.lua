local Q = {
	range       = 1500,
	speed       = 3200,
	width       = 80,
	delay       = 0.6,
}
--[[
AddDrawCallback(function()
	for i=1, objManager.maxObjects do
		local o = objManager:getObject(i)
		if o and o.valid and o.visible and o.name and o.name:find("Sru_Crab") then

			if o.hasMovePath and o.path.valid and o.path.count > 1 then
				local prev_waypoint = nil
				local max_hit_time = Q.width/o.ms
				for i=0, o.path.count do
					local waypoint = o.path:Path(i)
					if waypoint then

						if i == o.path.curPath then
							if prev_waypoint then
								
								local dst_o_wp = GetDistance(o, waypoint)
								local traveltime_o = dst_o_wp/o.ms
								DrawText3D("Arraving in: "..traveltime_o, waypoint.x, waypoint.y, waypoint.z)
						
								local missle_dst = GetDistance(myHero, waypoint)
								local traveltime_m = missle_dst/Q.speed
								DrawText3D("Missle Time in: "..traveltime_m, waypoint.x, waypoint.y+50, waypoint.z)
								
								DrawCircle3D(waypoint.x, waypoint.y, waypoint.z,60,1, ARGB(255,0,255,0))
								DrawCircle3D(prev_waypoint.x, prev_waypoint.y, prev_waypoint.z,60,1, ARGB(255,255,0,0))
								DrawLine3D(waypoint.x, waypoint.y, waypoint.z, prev_waypoint.x, prev_waypoint.y, prev_waypoint.z)
								
								local a,b = VectorMovementCollision(o, waypoint, o.ms, myHero, Q.speed, Q.delay)
								local castPos = Vector(b.x, o.y, b.y)
								DrawCircle3D(castPos.x, castPos.y, castPos.z, 60,1)
								
								local mt_VMC = GetDistance(myHero, castPos)/Q.speed
								local ot_VMC = GetDistance(o, castPos)/o.ms
								
								DrawText3D("Missle Time in: "..mt_VMC, castPos.x, castPos.y+50, castPos.z)
								DrawText3D("Arraving in: "..ot_VMC, castPos.x, castPos.y, castPos.z)
								
								DrawLine3D(myHero.x,myHero.y,myHero.z, castPos.x, castPos.y, castPos.z)
								
								if GetDistance(castPos) < Q.range + Q.width then
									CastSpell(_W, castPos.x, castPos.z)
									DrawTextA(1-math.max(GetDistance(castPos)/Q.range,0))
								else
									DrawTextA(0)
								end
							end
						else
							prev_waypoint = waypoint
						end
					end
				end
			end
		end
	end
end)
--]]

local function predictPosition(o, spelldata)
	if not o or not spelldata then
		return Vector(0,0,0), -1
	end
	
	if o.hasMovePath and o.path.valid and o.path.count > 1 then
		local prev_waypoint = nil
		local max_hit_time = spelldata.width/o.ms
		for i=0, o.path.count do
			local waypoint = o.path:Path(i)
			if waypoint then

				if i == o.path.curPath then
					if prev_waypoint then
						
						local dst_o_wp = GetDistance(o, waypoint)
						local traveltime_o = dst_o_wp/o.ms
						local missle_dst = GetDistance(myHero, waypoint)
						local traveltime_m = missle_dst/spelldata.speed						
						local a,b = VectorMovementCollision(o, waypoint, o.ms, myHero, spelldata.speed, spelldata.delay)
						local castPos = Vector(b.x, o.y, b.y)						
						local mt_VMC = GetDistance(myHero, castPos)/spelldata.speed
						local ot_VMC = GetDistance(o, castPos)/o.ms						
						if GetDistance(castPos) < spelldata.range + spelldata.width then
							return castPos, 1-math.max(GetDistance(castPos)/spelldata.range,0)
						else
							return Vector(0,0,0), -1							
						end
					end
				else
					prev_waypoint = waypoint
				end
			end
		end
	end
	return Vector(0,0,0), -1
end

AddTickCallback(function()
	local crab = nil
	for i=1, objManager.maxObjects do
		local o = objManager:getObject(i)
		if o and o.valid and o.visible and o.name and o.name:find("Sru_Crab") then
			crab = o
		end
	end
	
	local predPos, hitchance = predictPosition(crab,Q)
	
	if hitchance > 0 then
		CastSpell(_W, predPos.x, predPos.z)
	end
end)