--[[
   _____ __ ______      _                        _ _____                     
  / ____/_ |  ____|    | |                      | |  __ \                    
 | (___  | | |__  __  _| |_ ___ _ __ _ __   __ _| | |  | |_ __ __ ___      __
  \___ \ | |  __| \ \/ / __/ _ \ '__| '_ \ / _` | | |  | | '__/ _` \ \ /\ / /
  ____) || | |____ >  <| ||  __/ |  | | | | (_| | | |__| | | | (_| |\ V  V / 
 |_____/ |_|______/_/\_\\__\___|_|  |_| |_|\__,_|_|_____/|_|  \__,_| \_/\_/  
                                                                             
                                                                             
																			 
Usage:
	Do not rename this Script, since it has to be loaded before all other Scripts
	
	The Programm has to be in your BoL Folder to be able to render Sprites.
	Make sure to have Aero enabled, otherwise my Programm might crash or do other weird things.
		--> My Programm will only work on Windows Vista or newer.
		
	Do not change anything in here, if you don't know what you are doing !!!
	
	Streaming:
		Before streaming, go into a custom Game and check if this Script and all Scripts
		that you want to use while Streaming are working without any errors.
			--> This is important, cause i can't hide error Messages.
		
		Make sure, that you don't select your Screen as input, only the League of Legends Window
		while Streaming.

]]--
local sub, pairs, len, clock = string.sub, pairs, string.len, os.clock
--LUA SOCKET
local lua_socket = require("socket")
local udp_socket = lua_socket.udp()

local function SendData(data)
	udp_socket:sendto(data, "127.0.0.1", 3001)
end

local function CreateData(_type, datatbl)
	local data = "_type=".._type..","
	for k,v in pairs(datatbl)do
		data = data..k.."="..v..","
	end
	SendData(data:sub(0,data:len()-1).."\n")
end

--MATH ROUND
--[[
local function round(num, idp)
  local mult = 10^(idp or 0)
  return math.floor(num * mult + 0.5) / mult
end
]]--

--OVERWRITE DRAWS
_G.ARGB = function(alpha,red,green,blue)
	return {a = alpha, r = red, g = green, b = blue}
end

_G.RGBA = function(red,green,blue,alpha)
	return {a = alpha, r = red, g = green, b = blue}
end

_G.RGB = function(red,green,blue)
	return {a = 255, r = red, g = green, b = blue}
end

_G.DrawLine = function(start_x, start_y, end_x, end_y, width, color)
	
end

_G.DrawText = function (text, size, start_x, start_y, color)
	local data = {_TextStr=text,_TextSize=size,_TextColor_alpha=color.a,_TextColor_red=color.r,_TextColor_green=color.g,_TextColor_blue=color.b,_TextPosition_x=start_x,_TextPosition_y=start_y,_FRAMEID=clock()*1000}
	CreateData(1,data)
end

--TEST && DEBUG
function OnDraw()
	DrawText("TESTText", 10, 10, 10, ARGB(255,255,0,0))
end

local n = 10000
local s_t = clock()
for i=0, n do
	OnDraw()
end
local e_t = clock()
print((e_t-s_t)/n*100)

--local data = {_TextStr="TEST",_TextSize=12,_TextColor_alpha=255,_TextColor_red=255,_TextColor_green=0,_TextColor_blue=0,_TextPosition_x=200,_TextPosition_y=200,_FRAMEID=round(os.clock()*1000,0)}
--CreateData(1, data)