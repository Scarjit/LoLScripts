local function CalcZeroVector(source,target)
	local V = Vector(source.x, source.y, source.z)
	local V2 = Vector(target.x, target.y, target.z)
	local vec = (V2-V):normalized()
	return vec
end

local spellrange = 1800
local from = myHero
local current_check_target = mousePos

AddDrawCallback(function()
	for i=1, objManager.maxObjects do
		local o = objManager:getObject(i)
		if o and o.valid and o.visible and o.name and o.name:find("Sru_Crab") then
			local vec_o_mh = CalcZeroVector(o, from)
			local vec_o_mh_2 = vec_o_mh*-spellrange

			DrawLine3D(from.x+vec_o_mh.x, from.y+vec_o_mh.y, from.z+vec_o_mh.z, from.x+vec_o_mh_2.x, from.y+vec_o_mh_2.y, from.z+vec_o_mh_2.z)
			DrawCircle3D(current_check_target.x, current_check_target.y, current_check_target.z, 80)
			DrawLine3D(from.x,from.y,from.z, current_check_target.x, current_check_target.y, current_check_target.z)

			local dst_target = GetDistance(from, current_check_target)

			local intersect_vector = vec_o_mh*-dst_target
			DrawLine3D(from.x+vec_o_mh.x, from.y+vec_o_mh.y, from.z+vec_o_mh.z, from.x+intersect_vector.x, from.y+intersect_vector.y, from.z+intersect_vector.z, 1, ARGB(255,255,255,0))

			local dst_to_intersect = GetDistance(from+intersect_vector, current_check_target)
			DrawText3D(tostring(dst_to_intersect), from.x+intersect_vector.x, from.y+intersect_vector.y, from.z+intersect_vector.z)
		end
	end
end)


print("Loaded")