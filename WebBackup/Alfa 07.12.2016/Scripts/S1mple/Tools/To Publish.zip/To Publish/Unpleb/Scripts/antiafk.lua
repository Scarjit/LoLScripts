local lastaction = os.clock()
local last_afk_move = 0

AddTickCallback(function ()
	if lastaction + 120 < os.clock() then
		if last_afk_move + 10 < os.clock() then
			myHero:MoveTo(myHero.x + math.random(-100,100), myHero.z + math.random(-100,100))
			last_afk_move = os.clock()
		end
	end
end)

function OnWndMsg(a)
	if a ~= 512 then
		lastaction = os.clock()
	end
end

AddLoadCallback(function ()
	print("S1mple Anti-AFK Loaded")
end)

AddDrawCallback(function ()
	if lastaction + 120 < os.clock() then
		DrawTextA("Anti-AFK engaged")
	else
		DrawTextA("Time till Anti-AFK: "..lastaction+120-os.clock())
	end
end)