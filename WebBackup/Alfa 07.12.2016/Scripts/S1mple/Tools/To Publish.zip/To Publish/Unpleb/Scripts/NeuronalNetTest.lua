local luann = require("S1mpleBotResources\\luann")
math.randomseed(os.time())

--[[
learningRate = 50 -- set between 1, 100
attempts = 10000 -- number of times to do backpropagation
threshold = 1 -- steepness of the sigmoid curve

--create a network with 2 inputs, 3 hidden cells, and 1 output
myNetwork = luann:new({2,3, 1}, learningRate, threshold)

--run backpropagation (bp)
for i = 1,attempts do
	myNetwork:bp({0,0},{0})
	myNetwork:bp({1,0},{1})
	myNetwork:bp({0,1},{1})
	myNetwork:bp({1,1},{0})
end

--print the signal of the single output cell when :activated with different inputs
print("Results:")
myNetwork:activate({0,0})
print("0 0 | " .. myNetwork[3].cells[1].signal)
myNetwork:activate({0,1})
print("0 0 | " .. myNetwork[3].cells[1].signal)
myNetwork:activate({1,0})
print("0 0 | " .. myNetwork[3].cells[1].signal)
myNetwork:activate({1,1})
print("0 0 | " .. myNetwork[3].cells[1].signal)

--Save the network to a file
luann:saveNetwork(myNetwork, "myTestNetwork.network")

--Load the network from a file
newNetwork = luann:loadNetwork("myTestNetwork.network")

--run the loaded network
print("Results:")
newNetwork:activate({0,0})
print("Output of 0,0: " .. newNetwork[3].cells[1].signal)
newNetwork:activate({0,1})
print("Output of 0,1: " .. newNetwork[3].cells[1].signal)
newNetwork:activate({1,0})
print("Output of 1,0: " .. newNetwork[3].cells[1].signal)
newNetwork:activate({1,1})
print("Output of 1,1: " .. newNetwork[3].cells[1].signal)
--]]



allyheroes = {
	[1] = {
		kills = 10,
		deaths = 0,
		assists = 0,
	},
	[2] = {
		kills = 0,
		deaths = 0,
		assists = 5,		
	},
	[3] = {
		kills = 0,
		deaths = 10,
		assists = 5,		
	},
	[4] = {
		kills = 0,
		deaths = 0,
		assists = 10,		
	},
	[5] = {
		kills = 0,
		deaths = 0,
		assists = 9,
	}
}

enemyheroes = {
	[1] = {
		kills = 10,
		deaths = 5,
		assists = 0,		
	},
	[2] = {
		kills = 0,
		deaths = 2,
		assists = 0,		
	},
	[3] = {
		kills = 0,
		deaths = 2,
		assists = 0,		
	},
	[4] = {
		kills = 0,
		deaths = 1,
		assists = 0,		
	},
	[5] = {
		kills = 0,
		deaths = 0,
		assists = 0,		
	},
}

local function GenerateKDA(tbl)
	local kda = 0
	local tmp_k = 0
	local tmp_d = 0
	local tmp_a = 0
	local i = 0
	for _,v in pairs(tbl)do
		tmp_k = tmp_k +v.kills
		tmp_d = tmp_d +v.deaths
		tmp_a = tmp_a +v.assists
		i = i + 1
		if i == 5 then
			kda = (tmp_k+tmp_a*0.25)/tmp_k
			if tostring(kda) == "-1.#IND" or tostring(kda) == "1.#IND" then
				kda = 0
			end
		end
	end
	return kda
end


local allykda = GenerateKDA(allyheroes)
local enemykda = GenerateKDA(enemyheroes)

print(allykda)
print(enemykda)
local won_teamfight = 1

learningRate = 50
attempts = 10000
threshold = 1


local myNetwork
if io.open("NNT.network") then
	myNetwork = luann:loadNetwork("NNT.network")
else
	myNetwork = luann:new({2,3, 1}, learningRate, threshold)
end

for i = 1,attempts do
	myNetwork:bp({allykda,enemykda},{won_teamfight})
	myNetwork:bp({enemykda,allykda},{1-won_teamfight})
end

luann:saveNetwork(myNetwork, "NNT.network")
myNetwork = luann:loadNetwork("NNT.network")

myNetwork:activate({0,2})
print("0 2 | " .. myNetwork[3].cells[1].signal)

myNetwork:activate({2,0})
print("2 0 | " .. myNetwork[3].cells[1].signal)



