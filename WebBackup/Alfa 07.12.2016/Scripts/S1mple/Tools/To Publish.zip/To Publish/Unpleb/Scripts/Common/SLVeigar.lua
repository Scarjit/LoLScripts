--Author: S1mple
--[[
   _____ _        _____           _        _      _____               
  / ____| |      |  __ \         | |      | |    / ____|              
 | (___ | |      | |__) |_ _  ___| | _____| |_  | |     ___  _ __ ___ 
  \___ \| |      |  ___/ _` |/ __| |/ / _ \ __| | |    / _ \| '__/ _ \
  ____) | |____  | |  | (_| | (__|   <  __/ |_  | |___| (_) | | |  __/
 |_____/|______| |_|   \__,_|\___|_|\_\___|\__|  \_____\___/|_|  \___|
                                                                      
                                                                      
--]]
require("FHPrediction")
local ts_instance = TargetSelector(TARGET_PRIORITY, 4000)
local mm_instance = minionManager(MINION_ENEMY, 1500, player, MINION_SORT_HEALTH_ASC)
local jm_instance = minionManager(MINION_JUNGLE, 1500, player, MINION_SORT_HEALTH_ASC)

local enemy_heroes = GetEnemyHeroes()
local script_version = 0.7
local min_log_level = 2
local menu
local oldprint = print
local print = function(arg,loglevel)

	if(loglevel and loglevel < min_log_level) then
		return
	elseif not loglevel then
		loglevel = 2
	end
	
	local ll = {
		"/DEBUG",
		"/Information",
		"/Warning",
		"/Error",
	}
	oldprint('<font color=\"#808080\">S1mple_Loader </font><font color=\"#10FFFF\">['..myHero.charName..(ll[loglevel] and ll[loglevel] or "")..']</font><font color=\"#515151\"> - </font><font color=\"#FFFFFF\">'..tostring(arg)..'</font>')
end

local function TCPGetRequest(server, path, data, port)
	local start_t = os.clock()
	local port = port or 80
	local data = data or {}
	local lua_socket = require("socket")
	local connection_tcp = lua_socket.connect(server,port)
	local requeststring = "GET "..path
	local first = true

	for i,v in pairs(data) do
		requeststring = requeststring..(first and "?" or "&")..i.."="..v
		first = false
	end
	
	requeststring = requeststring.. " HTTP/1.0\r\nHost: "..server.."\r\n\r\n"
	connection_tcp:send(requeststring)
	local response = ""
	local status
	while true do
		s,status, partial = connection_tcp:receive('*a')
		response = response..(s or partial)
		if(status == "closed" or status == "timeout")then
			break
		end
	end
	local end_t = os.clock()
	local start_content = response:find("\r\n\r\n")+4
	response = response:sub(start_content)
	return response, status, end_t-start_t
end

local function GetWebFile(server, path, data, localfilename, port)
	local r,s,t = TCPGetRequest(server, path, data, port)
	local a,b = Base64Decode(r)
	if (a ~= "No_new_version" and a ~= "Invalid Request" and a ~= "MYSQL Error" and a ~= "") then
		local file = io.open(localfilename,"w+b")
		file:write(a)
		file:close()
		print("Download Finished")
		return true
	else
		if a ~= "No_new_version" then
			print(a, 4)
		end
		return false
	end
end

local function Update()
	if(menu.autoupdate)then
		if(GetWebFile("s1mplescripts.de","/S1mple/Scripts/BolStudio/RandomBundle/index.php", {fn = myHero.charName, v = script_version}, LIB_PATH.."SL"..myHero.charName..".lua"))then
			print("Updated, please reload",2)
		else
			print("No update found",2)
		end
	else
		print("Updates disabled", 3)
	end
end

--[[
                                                                                                                        |___/           
--]]

local function Menu()
	menu = scriptConfig("Simple Loader ["..myHero.charName.."]", "SL"..myHero.charName)
	menu:addSubMenu("Advanced Settings", "adv") --DONE
		menu.adv:addParam("debuglvl", "Debug Level", SCRIPT_PARAM_LIST, 2, {"DEBUG", "Information", "Warning", "Error"}) --DONE
		menu.adv:setCallback("debuglvl", function(value) --DONE
			min_log_level = value
		end)
		min_log_level = menu.adv.debuglvl
		
	--Champ Specific
	menu:addSubMenu("Spell Settings", "spells")
		menu.spells:addSubMenu("Q", "q")
		
			menu.spells.q:addParam("Blank", "    General", SCRIPT_PARAM_INFO, "")
			menu.spells.q:addParam("onc", "Use on Combo", SCRIPT_PARAM_ONOFF, true)
			menu.spells.q:addParam("manaonc", "If My Mana Percent > %X", SCRIPT_PARAM_SLICE, 0, 0, 100, 0)

			menu.spells.q:addParam("Blank", "", SCRIPT_PARAM_INFO, "")
			menu.spells.q:addParam("onf", "Use on LaneClear", SCRIPT_PARAM_ONOFF, true)
			menu.spells.q:addParam("manaonf", "If My Mana Percent > %X", SCRIPT_PARAM_SLICE, 20, 0, 100, 0)

			menu.spells.q:addParam("Blank", "", SCRIPT_PARAM_INFO, "")
			menu.spells.q:addParam("onh", "Use on Harras", SCRIPT_PARAM_ONOFF, true)
			menu.spells.q:addParam("manaonh", "If My Mana Percent > %X", SCRIPT_PARAM_SLICE, 20, 0, 100, 0)
			menu.spells.q:addParam("prefminionh", "Prefer Minions", SCRIPT_PARAM_ONOFF, true)
	
		menu.spells:addSubMenu("W", "w")

			menu.spells.w:addParam("Blank", "    General", SCRIPT_PARAM_INFO, "")
			menu.spells.w:addParam("onc", "Use on Combo", SCRIPT_PARAM_ONOFF, true)
			menu.spells.w:addParam("manaonc", "If My Mana Percent > %X", SCRIPT_PARAM_SLICE, 0, 0, 100, 0)
			menu.spells.w:addParam("usemecc", "Use MEC", SCRIPT_PARAM_ONOFF, true)
			menu.spells.w:addParam("onlystunnedc", "Only if Stunned (Disables MEC)", SCRIPT_PARAM_ONOFF, false)
		
			menu.spells.w:addParam("Blank", "", SCRIPT_PARAM_INFO, "")
			menu.spells.w:addParam("onf", "Use on LaneClear", SCRIPT_PARAM_ONOFF, true)
			menu.spells.w:addParam("manaonf", "If My Mana Percent > %X", SCRIPT_PARAM_SLICE, 20, 0, 100, 0)
			menu.spells.w:addParam("usemecf", "Use MEC", SCRIPT_PARAM_ONOFF, true)

			menu.spells.w:addParam("Blank", "", SCRIPT_PARAM_INFO, "")
			menu.spells.w:addParam("onh", "Use on Harras", SCRIPT_PARAM_ONOFF, true)
			menu.spells.w:addParam("manaonh", "If My Mana Percent > %X", SCRIPT_PARAM_SLICE, 20, 0, 100, 0)
			menu.spells.w:addParam("usemech", "Use MEC", SCRIPT_PARAM_ONOFF, true)
			menu.spells.w:addParam("againstminions", "Use against Minions (Harras)", SCRIPT_PARAM_ONOFF, true)
			menu.spells.w:addParam("onlystunnedh", "Only if Stunned (Disables MEC)", SCRIPT_PARAM_ONOFF, false)

		menu.spells:addSubMenu("E", "e")

			menu.spells.e:addParam("Blank", "    General", SCRIPT_PARAM_INFO, "")
			menu.spells.e:addParam("onc", "Use on Combo", SCRIPT_PARAM_ONOFF, true)
			menu.spells.e:addParam("manaonc", "If My Mana Percent > %X", SCRIPT_PARAM_SLICE, 0, 0, 100, 0)
			menu.spells.e:addParam("usemecc", "Use MEC", SCRIPT_PARAM_ONOFF, true)
			
			menu.spells.e:addParam("Blank", "", SCRIPT_PARAM_INFO, "")
			menu.spells.e:addParam("onh", "Use on Harras", SCRIPT_PARAM_ONOFF, true)
			menu.spells.e:addParam("manaonh", "If My Mana Percent > %X", SCRIPT_PARAM_SLICE, 20, 0, 100, 0)
			menu.spells.e:addParam("usemech", "Use MEC", SCRIPT_PARAM_ONOFF, true)
			
		menu.spells:addSubMenu("R", "r")

			menu.spells.r:addParam("Blank", "    General", SCRIPT_PARAM_INFO, "")
			menu.spells.r:addParam("onc", "Use on Combo", SCRIPT_PARAM_ONOFF, true)
			menu.spells.r:addParam("manaonc", "If My Mana Percent > %X", SCRIPT_PARAM_SLICE, 0, 0, 100, 0)

			menu.spells.r:addParam("Blank", "", SCRIPT_PARAM_INFO, "")
			menu.spells.r:addParam("onh", "Use on Harras", SCRIPT_PARAM_ONOFF, true)
			menu.spells.r:addParam("manaonh", "If My Mana Percent > %X", SCRIPT_PARAM_SLICE, 20, 0, 100, 0)
		
	menu:addSubMenu("Kill Steal", "ks")
		menu.ks:addParam("useR", "Use R", SCRIPT_PARAM_ONOFF, true)
	
	menu:addSubMenu("Draws", "draws")
		menu.draws:addParam("drawqdmg", "Draw Q Damage", SCRIPT_PARAM_ONOFF, true)
		menu.draws:addParam("qcolor", "Q Damage Color", SCRIPT_PARAM_COLOR, {255,0,0,255})
		menu.draws:addParam("drawrdmg", "Draw R Damage", SCRIPT_PARAM_ONOFF, true)
		menu.draws:addParam("rcolor", "Q Damage Color", SCRIPT_PARAM_COLOR, {255,255,0,255})
		
	menu:addSubMenu("Keys", "keys")
		menu.keys:addParam("info", "Your Normal Keys are connected to your OrbWalker", SCRIPT_PARAM_INFO, "")
		menu.keys:addParam("stunkey", "Stun Enemy", SCRIPT_PARAM_ONKEYDOWN, false, string.byte('T'))
		menu.keys:addParam("stunkeymove", "Move to Hero, while trying to Stun", SCRIPT_PARAM_ONOFF, true)
		menu.keys:addParam("stunkeyhs", "Stun Key HitChance", SCRIPT_PARAM_SLICE, 1,1,1.4,2)
		menu.keys:addParam("stunkeyvecrange", "Stun Key Vector Multiplier", SCRIPT_PARAM_SLICE, 375,200,375,1)
	--End Champ Specific
	
	menu:addParam("autoupdate","Autoupdate", SCRIPT_PARAM_ONOFF, true) --DONE
	menu:addParam("version", "Version: ", SCRIPT_PARAM_INFO, script_version) --DONE
end

--Some nice var's
local LoadedWalker
local function GetOrbWalker()
	if _G.S1OrbLoading or _G.S1mpleOrbLoaded then LoadedWalker = "S1Orb" end
	if _G.Reborn_Loaded or _G.AutoCarry then LoadedWalker = "SAC:R" end
	if SAC then LoadedWalker = "SAC:P" end
	if _Pewalk then LoadedWalker = "PEW" end
	if _G.NebelwolfisOrbWalkerInit then LoadedWalker = "NOW" end
	if not LoadedWalker then print("You need to load an OrbWalker to load this Script",4) return false end
	return true
end


local function GetOrbMode()
	if LoadedWalker == "S1Orb" then
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "none" then return 0 end
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "harass" then return 1 end
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "laneclear" then return 2 end
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "lasthit" then return 3 end
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "sbtw" then return 4 end
	elseif LoadedWalker == "SAC:R" then
		if not _G.AutoCarry or not _G.AutoCarry.Keys then return 0 end
		if _G.AutoCarry.Keys.MixedMode then return 1 end
		if _G.AutoCarry.Keys.LaneClear then return 2 end
		if _G.AutoCarry.Keys.LastHit then return 3 end
		if _G.AutoCarry.Keys.AutoCarry then return 4 end
	elseif LoadedWalker == "SAC:P" then
		if SAC:GetActiveMode() == "MixedMode" then return 1 end
		if SAC:GetActiveMode() == "Laneclear" then return 2 end
		if SAC:GetActiveMode() == "LastHit" then return 3 end
		if SAC:GetActiveMode() == "AutoCarry" then return 4 end		
	elseif LoadedWalker == "PEW" then
		if not _Pewalk then return 0 end
		if _Pewalk.GetActiveMode().Mixed then return 1 end
		if _Pewalk.GetActiveMode().LaneClear then return 2 end
		if _Pewalk.GetActiveMode().Farm then return 3 end
		if _Pewalk.GetActiveMode().Carry then return 4 end
	elseif LoadedWalker == "NOW" then
		if not _G.NebelwolfisOrbWalkerInit then return 0 end
		if _G.NebelwolfisOrbWalker.mode == "Mixed" then return 1 end
		if _G.NebelwolfisOrbWalker.mode == "LaneClear" then return 2 end		
		if _G.NebelwolfisOrbWalker.mode == "LastHit" then return 3 end	
		if _G.NebelwolfisOrbWalker.mode == "Combo" then return 4 end
	end

	return 0
end

local function GetOrbTarget()
	if LoadedWalker == "S1Orb" then
		return (_G.S1mpleOrbLoaded and _G.S1:GetTarget() or nil)
	elseif LoadedWalker == "SAC:R" and _G.AutoCarry and _G.AutoCarry.SkillsCrosshair then
		return _G.AutoCarry.SkillsCrosshair.target
	elseif LoadedWalker == "SAC:P" then
		return SAC:GetTarget()
	elseif LoadedWalker == "PEW" then
		return _Pewalk.GetTarget()
	elseif LoadedWalker == "NOW" then
		return _G.NebelwolfisOrbWalker:GetTarget()
	end
end

local function GetCTarget(range)
	if not range then range = myHero.range end
	local target = GetOrbTarget()
	if not target or GetDistance(target) > range then
		local mode = GetOrbMode()
		if mode == 1 then -- Mixed Mode (Harras)
			ts_instance.range = range
			target = ts_instance.target
			ts_instance.range = 4000
			if not target then
				mm_instance.range = range
				target = mm_instance.objects[1]
				mm_instance.range = 1500
			end
			if not target then
				jm_instance.range = range
				target = jm_instance.objects[1]
				jm_instance.range = 1500
			end
		elseif mode == 2 then -- LaneClear
			mm_instance.range = range
			target = mm_instance.objects[1]
			mm_instance.range = 4000
			if not target then
				jm_instance.range = range
				target = jm_instance.objects[1]
				jm_instance.range = 1500
			end
		elseif mode == 3 then -- LastHit
			mm_instance.range = range
			target = mm_instance.objects[1]
			mm_instance.range = 1500		
			if not target then
				jm_instance.range = range
				target = jm_instance.objects[1]
				jm_instance.range = 1500
			end
		elseif mode == 4 then --SBTW
			ts_instance.range = range
			target = ts_instance.target
			ts_instance.range = 400
		end			
	end
	return target
end

--MATH
local sqrt = math.sqrt
local function CalcVector(source,target)
	local V = Vector(source.x, source.y, source.z)
	local V2 = Vector(target.x, target.y, target.z)
	local vec = V-V2
	local vec2 = vec:normalized()
	return vec2
end

local function GetDistance(p1, p2)
	if not p1 then oldprint(debug.getinfo(2)) end 
	p2 = p2 or player
    local s = (p1.x - p2.x) ^ 2 + ((p1.z or p1.y) - (p2.z or p2.y)) ^ 2
	return sqrt(s)
end
--END MATH
local function GetMana()
	return myHero.mana/myHero.maxMana*100	
end

local function _CalcSpellPosForGroup(radius, range, points)
    if #points == 0 then
        return nil
    elseif #points == 1 then
        return {center = Vector(points[1]), radius = nil}
    end
    local mec = MEC()
    local combos = {}
    for j = #points, 2, -1 do
        local spellPos
        combos[j] = {}
        _CalcCombos(j, points, combos[j])
        for _, v in ipairs(combos[j]) do
            mec:SetPoints(v)
            local c = mec:Compute()
            if c ~= nil and c.radius <= radius and c.center:dist(player) <= range and (spellPos == nil or c.radius < spellPos.radius) then
                spellPos = {center = c.center, radius = c.radius}
            end
        end
        if spellPos ~= nil then return spellPos end
    end
end


local function GetDmg(spell, unit)
	if unit and unit.visible and not unit.dead and unit.bTargetable then

		local ADDmg = 0
		local APDmg = 0

		local Level = myHero.level
		local TotalDmg = myHero.totalDamage
		local AddDmg = myHero.addDamage
		local AP = myHero.ap
		local ArmorPen = myHero.armorPen
		local ArmorPenPercent = myHero.armorPenPercent
		local MagicPen = myHero.magicPen
		local MagicPenPercent = myHero.magicPenPercent

		local Armor = math.max(0, unit.armor*ArmorPenPercent-ArmorPen)
		local ArmorPercent = Armor/(100+Armor)
		local MagicArmor = math.max(0, unit.magicArmor*MagicPenPercent-MagicPen)
		local MagicArmorPercent = MagicArmor/(100+MagicArmor)

		if spell == "AA" then
			ADDmg = TotalDmg
		elseif spell == "Q" then
			if myHero:CanUseSpell(_Q) == READY then
				APDmg = 40*myHero:GetSpellData(_Q).level+30+0.6*AP
			end
		elseif spell == "W" then
			if myHero:CanUseSpell(_W) == READY then
				APDmg = 50*myHero:GetSpellData(_W).level+50+AP
			end
		elseif spell == "E" then
			if myHero:CanUseSpell(_E) == READY then
				APDmg = 0
			end
		elseif spell == "R" then
			if myHero:CanUseSpell(_R) == READY then
				APDmg = 75*myHero:GetSpellData(_R).level+100+0.75*AP
				local missinghealtperc = 100-(unit.health/unit.maxHealth*100)
				local mhdmginc = missinghealtperc*1.5
				if(missinghealtperc >= 67)then
					mhdmginc = mhdmginc*2
				end
				if mhdmginc ~= 0 then
					APDmg = APDmg * mhdmginc
				end
			end
		end

		local TrueDmg = ADDmg*(1-ArmorPercent)+APDmg*(1-MagicArmorPercent)

		return TrueDmg
	end
	return 0
end

local function GetQTargets()
	local targets = {}
	for i=1, #mm_instance.objects do
		local minion = mm_instance.objects[i]
		if minion and not minion.dead and GetDistance(minion) < 950 and GetDmg("Q", minion) >= minion.health then
			targets[#targets+1] = minion
		end
	end
	for i=1, #jm_instance.objects do
		local minion = jm_instance.objects[i]
		
		if minion and not minion.dead and GetDistance(minion) < 950 and GetDmg("Q", minion) >= minion.health then
			targets[#targets+1] = minion
		end
	end
	return targets
end

local function GetAllTarget(range)
	local targets = table.copy(enemy_heroes)
	for i=1, #mm_instance.objects do
		local minion = mm_instance.objects[i]
		if minion and not minion.dead and GetDistance(minion) < range then
			targets[#targets+1] = minion
		end
	end
	for i=1, #jm_instance.objects do
		local minion = jm_instance.objects[i]
		
		if minion and not minion.dead and GetDistance(minion) < range then
			targets[#targets+1] = minion
		end
	end
	return targets
end

local function GetMinionTargets(range)
	local targets = {}
	for i=1, #mm_instance.objects do
		local minion = mm_instance.objects[i]
		if minion and not minion.dead and GetDistance(minion) < range then
			targets[#targets+1] = minion
		end
	end
	for i=1, #jm_instance.objects do
		local minion = jm_instance.objects[i]
		
		if minion and not minion.dead and GetDistance(minion) < range then
			targets[#targets+1] = minion
		end
	end
	return targets
end

local function CastQAgainstMinions()
	local qtargets = GetQTargets()
	local cspfg = _CalcSpellPosForGroup(50, 950, qtargets)
	if cspfg ~= nil then
		local center = cspfg.center
		CastSpell(_Q, center.x, center.z)
	end
end

local function CastQ(target)
	if target and target.valid and not target.dead then
		local CastPos, HitChance, _ = FHPrediction.GetPrediction("Q", target)
		if CastPos and HitChance > 1 then
			CastSpell(_Q, CastPos.x, CastPos.z)
		end
	end
end

local w_data = {
	range = 900,
	speed = math.huge,
	delay = 1.35,
	radius = 112.5,
}

local e_data = {
	range = 700,
	speed = math.huge,
	delay = 0.5,
	radius = 375,
}

local function CastW(target)
	if target and target.valid and not target.dead then
		local CastPos, HitChance, _ = FHPrediction.GetPrediction(w_data, target)
		if CastPos and HitChance > 1 then
			CastSpell(_W, CastPos.x, CastPos.z)
		end
	end
end

local function CastWMEC(targets)
	local t = {}
	
	for _,v in pairs(targets) do
		if v and v.valid and not v.dead and v.visible and GetDistance(v) < 1012.5 then
			local CastPos, HitChance, _ = FHPrediction.GetPrediction(w_data, v)
			if CastPos and HitChance > 1 then
				t[#t+1] = CastPos
			end
		end
	end
	
	if #t == 0 then return end
	
	local cspfg = _CalcSpellPosForGroup(112.5, 900, t)
	if cspfg ~= nil then
		local center = cspfg.center
		local radius = cspfg.radius
		CastSpell(_W, center.x, center.z)
	end
end

local function CastE(target)
	if target and target.valid and not target.dead and target.visible then
		local CastPos, HitChance, _ = FHPrediction.GetPrediction(e_data, target)
		if CastPos and HitChance > 1 then
			CastSpell(_E, CastPos.x, CastPos.z)
		end
	end
end

local function CastEMEC(targets)
	local t = {}
	
	for _,v in pairs(targets) do
		if v and v.valid and not v.dead and v.visible and GetDistance(v) < 1075 then
			local CastPos, HitChance, _ = FHPrediction.GetPrediction(e_data, v)
			if CastPos and HitChance > 1 then
				t[#t+1] = CastPos
			end
		end
	end
	
	if #t == 0 then return end
	
	local cspfg = _CalcSpellPosForGroup(375, 700, t)
	if cspfg ~= nil then
		local center = cspfg.center
		local radius = cspfg.radius
		CastSpell(_E, center.x, center.z)
	end
end

local function CastR(target)
	if target and target.valid and target.visible and not target.dead then
		if GetDmg("R", target) > target.health then
			CastSpell(_R, target)
		end
	end
end



-- NORMAL MODES

local function Combo()
	local target = GetCTarget(1012.5)
	if not target then return end
	
	if menu.spells.q.onc and GetMana() >= menu.spells.q.manaonc  then
		CastQ(target)
	end
	
	if menu.spells.w.onc and GetMana() >= menu.spells.q.manaonc then
		if(menu.spells.w.usemecc and not menu.spells.w.onlystunnedc) then
			CastWMEC(enemy_heroes)
		else
			if menu.spells.w.onlystunnedc then
				local isstunned = false
				for i = 1, target.buffCount do
					local tBuff = target:getBuff(i)
					if BuffIsValid(tBuff) and tBuff.type == 5 then
						isstunned = true
						break
					end
				end
				if isstunned then
					CastW(target)
				end
			else
				CastW(target)
			end
		end
	end
	
	if menu.spells.e.onc and GetMana() >= menu.spells.q.manaonc then
		if(menu.spells.e.usemecc) then
			CastEMEC(enemy_heroes)
		else
			CastE(target)
		end
	end
	
	if menu.spells.r.onc and GetMana() >= menu.spells.q.manaonc then
		CastR(target)
	end
end

local function Harras()
	local target = GetCTarget(1012.5)
	if menu.spells.q.onh and GetMana() >= menu.spells.q.manaonh then
		if(menu.spells.q.prefminionh)then
			CastQAgainstMinions()
		else
			if target then
				CastQ(target)
			else
				CastQAgainstMinions()			
			end
		end
	end
	
	if menu.spells.w.onh and GetMana() >= menu.spells.w.manaonh then
		if menu.spells.w.usemech and not menu.spells.w.onlystunnedh then
			if menu.spells.w.againstminions then
				CastWMEC(GetAllTarget(1012.5))
			else
				CastWMEC(enemy_heroes)
			end
		else
			if menu.spells.w.onlystunnedh then
				if target then
					local isstunned = false
					for i = 1, target.buffCount do
						local tBuff = target:getBuff(i)
						if BuffIsValid(tBuff) and tBuff.type == 5 then
							isstunned = true
							break
						end
					end
					if isstunned then
						CastW(target)
					end
				end
			else
				CastW(target)
			end
		end
	end
	
	if menu.spells.e.onh and GetMana() >= menu.spells.e.manaonh then
		if menu.spells.e.usemech then
			CastEMEC(enemy_heroes)
		else
			CastE(target)
		end
	end
	
	if menu.spells.r.onh and GetMana() >= menu.spells.q.manaonh then
		CastR(target)
	end
end

local function Laneclear()
	local target = GetCTarget(1012.5)
	if not target then return end
	
	if menu.spells.q.onf and GetMana() >= menu.spells.q.manaonf then
		CastQAgainstMinions()
	end
	
	if menu.spells.w.onf and GetMana() >= menu.spells.w.manaonf then
		if menu.spells.w.usemech then
			CastWMEC(GetMinionTargets(1012.5))
		else
			CastW(target)
		end
	end
end

local function Modes()
	local mode = GetOrbMode()
	if mode == 4 then
		Combo()
	elseif mode == 1 then
		Harras()
	elseif mode == 2 then
		Laneclear()
	end
end

--END NORMAL MODES

local function Killsteal()
	if menu.ks.useR then
		for _,v in pairs(enemy_heroes) do
			if v and v.valid and not v.dead and GetDistance(v) < 650 and GetDmg("R", v) > v.health then
				CastSpell(_R, v)
			end
		end
	end
end

local function AutoStun()
	if not menu.keys.stunkey then return end
	if myHero:CanUseSpell(_E) then
		local range = 700
		local target = GetCTarget(range)
		if not target or target.type ~= myHero.type then
			for _,v in pairs(enemy_heroes) do
				if v and v.valid and v.visible and not v.dead and GetDistance(v) <= range then
					if not target then
						target = v
					elseif GetDistance(v) < GetDistance(target) then
						target = v
					end
				end
			end
		end
		
		if target then
			local CastPos, HitChance, _ = FHPrediction.GetPrediction(e_data, target)
			DrawText3D(tostring(HitChance), target.x, target.y, target.z)
			if CastPos and HitChance >= menu.keys.stunkeyhs then
				local myPos = Vector(myHero.x, myHero.y, myHero.z)
				local tPos = Vector(CastPos.x, CastPos.y, CastPos.z)
				
				local bvec = CalcVector(tPos, myPos)*-menu.keys.stunkeyvecrange
				local xvec = {x = bvec.x + tPos.x, y = target.y, z = bvec.z + tPos.z}
									
				CastSpell(_E, xvec.x, xvec.z)
			end
		end
	end
	
	if menu.keys.stunkeymove then
		myHero:MoveTo(mousePos.x, mousePos.z)
	end
end

--BEGIN DRAWS
local function drawDebugStuff()
	if min_log_level > 1 then return end

end
local function drawdmg()
	for _,v in pairs(enemy_heroes) do
		if v and v.valid and not v.dead and v.visible and GetDistance(v) < 1300 then --R*2
			local q_dmg = 0
			local r_dmg = 0
			
			if menu.draws.drawqdmg then
				q_dmg = GetDmg("Q", v)
			end
			if menu.draws.drawrdmg then
				r_dmg = GetDmg("R", v)
			end
			
			local barPos = GetUnitHPBarPos(v) --THANKS Jori
			local barOffset = GetUnitHPBarOffset(v)
			do -- For some reason the x offset never exists
				local t = {
					["Darius"] = -0.05,
					["Renekton"] = -0.05,
					["Sion"] = -0.05,
					["Thresh"] = 0.03,
					["Jhin"] = -0.06,
					["Annie"] = -0.06
				}
				barOffset.x = t[v.charName] or 0
			end
			local baseX = barPos.x - 69 + barOffset.x * 150
			local baseY = barPos.y + barOffset.y * 50 + 2.5

			if v.charName == "Jhin" then 
				baseY = baseY - 12
			end
			if v.charName == "Annie" then
				baseY = baseY - 12
			end
			
		
			local r_dmg_perc = r_dmg/v.health*100
			local q_dmg_perc = q_dmg/v.health*100
			
			local q_color = ARGB(menu.draws.qcolor[1],menu.draws.qcolor[2],menu.draws.qcolor[3],menu.draws.qcolor[4])
			local r_color = ARGB(menu.draws.rcolor[1],menu.draws.rcolor[2],menu.draws.rcolor[3],menu.draws.rcolor[4])
			
			
			if r_dmg_perc < 100 then
				if q_dmg_perc+r_dmg_perc < 100 then
					DrawLine(baseX, baseY, baseX+r_dmg_perc*1.05, baseY, 12, r_color)
				else
					DrawLine(baseX, baseY, baseX+r_dmg_perc*1.05, baseY, 3, r_color)
				end
			else
				DrawLine(baseX, baseY, baseX+105, baseY, 3, r_color)
			end
			
			local q_start = baseX+r_dmg_perc*1.05
			
			if q_dmg_perc < 100 then
				if r_dmg_perc+q_dmg_perc < 100 then
					DrawLine(q_start, baseY, q_start+q_dmg_perc*1.05, baseY, 12, q_color)
				else
					DrawLine(baseX, baseY-4, baseX+q_dmg_perc*1.05, baseY-4, 3, q_color)
				end
			else
				DrawLine(baseX, baseY-4, baseX+105, baseY-4, 3, q_color)
			end
			
			if q_dmg_perc+r_dmg_perc >= 100 then
				local text = "Killable"
				DrawText(text, 16, baseX+35, baseY-9, ARGB(255,255,255,255))
			end
		end
	end
end
--END DRAWS

AddLoadCallback(function()
	if not GetOrbWalker() then return end
	Menu()
	Update()
end)

AddDrawCallback(function()
	if not LoadedWalker then return end
	drawDebugStuff()
	drawdmg()
end)

AddTickCallback(function()
	if not LoadedWalker then return end
	AutoStun()
	Killsteal()
	Modes()
	jm_instance:update()
	mm_instance:update()
	ts_instance:update()
end)