local function addition(str, n)
	local n_str = tostring(n)
	local r_str = ""
	local overhead = 0
	
	for i=#n_str,1,-1 do
		local n_int = tonumber(n_str:sub(i,i))
		local str_int = tonumber(str:sub(i,i))
		if str_int == nil then str_int = 0 end
		local e = n_int+str_int+overhead
		if(overhead > 0) then
			overhead = overhead-1
		end
		local writeval = e%10
		if(e >= 10) then
			r_str = r_str..writeval
			overhead = overhead+1
		else
			r_str = r_str..writeval		
		end
	end
	return(r_str:reverse())
end

local function product(astr,bstr)
	if(astr == 0 or bstr == 0) then return "0" end
	local a = {}
	local b = {}
	for i=1, #tostring(astr) do
		a[#a+1] = tostring(astr):sub(i,i)
	end
	for i=1, #tostring(bstr) do
		b[#b+1] = tostring(bstr):sub(i,i)
	end
	
	local result = {}
	for i=0,#a+#b do
		result[#result+1] = 0
	end
	
	for i=#a,1,-1 do
		for j=#b,1,-1 do
			result[i+j+1] = result[i+j+1]+(b[j]*a[i])
		end
	end
	for i=#a+#b+1,1,-1 do
		if(result[i] >= 10) then
			result[i-1] = result[i-1] + (math.floor(result[i]/10) > 1 and math.floor(result[i]/10) or 1)
			result[i] = result[i]%10
		end
	end
	local numisentered = false
	local resstr = ""
	for i=1,#a+#b+1 do
		if(result[i] ~= 0 and not numisentered)then numisentered = true end
		if(numisentered)then
			resstr = resstr..result[i]
		end
	end
	
	return resstr
end

local function power(base, exponent)
	local n = base
	for i=1,exponent-1 do
		n = product(n,base)
	end
	return n
end