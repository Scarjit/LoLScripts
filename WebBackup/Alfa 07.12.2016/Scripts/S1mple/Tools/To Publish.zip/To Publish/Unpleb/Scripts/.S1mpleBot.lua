--STATICS
local WINDOW_W = WINDOW_W
local WINDOW_H = WINDOW_H
local WINDOW_H_MID = WINDOW_H/2
local WINDOW_W_MID = WINDOW_W/2



local ally_minions = minionManager(MINION_ALLY, 1500, player, MINION_SORT_HEALTH_ASC)
local enemy_minions = minionManager(MINION_ENEMY, 1500, player, MINION_SORT_HEALTH_ASC)
local ally_heroes = GetAllyHeroes()
local enemy_heroes = GetEnemyHeroes()

function CalculateInputMatrix()
	local inputmatrix = {}
	local myHerowts = WorldToScreen(D3DXVECTOR3(myHero.x, myHero.y,myHero.z))

	local r_pos_x = math.round(myHero.x/100)*100
	local r_pos_z = math.round(myHero.z/100)*100


	for i=0,14 do
		for i2=0,14 do
			local x_pos_x = r_pos_x+(i-7)*100
			local x_pos_z = r_pos_z-(i2-7)*100

			local vec_d3d = D3DXVECTOR3(x_pos_x, 0, x_pos_z)
			if IsWall(vec_d3d) then
				--DrawTextA("[[]]",15,WINDOW_W_MID-148+i*20,WINDOW_H_MID-149+i2*20,ARGB(255,0,255,255))
				inputmatrix[#inputmatrix+1] = {x = WINDOW_W_MID-150+i*20, y = WINDOW_H_MID-150+i2*20, value = -1}
			end
			if i == 7 and i2 == 7 then
				--DrawTextA("X",15,WINDOW_W_MID-143+i*20,WINDOW_H_MID-147+i2*20,ARGB(255,0,255,0))
			end
		end
	end


end

AddTickCallback(function ()
	ally_minions:update()
	enemy_minions:update()
end)


AddDrawCallback(function ()
	--[[
	local myHerowts = WorldToScreen(D3DXVECTOR3(myHero.x, myHero.y,myHero.z))
	DrawRectangleOutline(WINDOW_W_MID-150, WINDOW_H_MID-150, 300,300, ARGB(255,255,255,255),1)

	local r_pos_x = math.round(myHero.x/100)*100
	local r_pos_z = math.round(myHero.z/100)*100

	for i=0,14 do
		DrawLine(WINDOW_W_MID-150+i*20,WINDOW_H_MID+150,WINDOW_W_MID-150+i*20,WINDOW_H_MID-150,1,4294967295)
		DrawLine(WINDOW_W_MID-150,WINDOW_H_MID-150+i*20,WINDOW_W_MID+150,WINDOW_H_MID-150+i*20,1,4294967295)
		for i2=0,14 do
			local x_pos_x = r_pos_x+(i-7)*100
			local x_pos_z = r_pos_z-(i2-7)*100

			local vec_d3d = D3DXVECTOR3(x_pos_x, 0, x_pos_z)
			if IsWall(vec_d3d) then
				DrawTextA("W",15,WINDOW_W_MID-148+i*20,WINDOW_H_MID-149+i2*20,ARGB(255,0,255,255))
			end
			if i == 7 and i2 == 7 then
				DrawTextA("X",15,WINDOW_W_MID-143+i*20,WINDOW_H_MID-147+i2*20,ARGB(255,0,255,0))
			end
		end
	end
	--]]

	local m = 7
	local m2 = 7

	for i=1,#enemy_heroes do
		local current = enemy_heroes[i]
		if current and current.valid and not current.dead and current.bTargetable and current.visible then
			local n = Vector(math.round(current.x/100)*100,0,math.round(current.z/100)*100)

			DrawTextA(n,12,180,20)

			local x_dst = (r_pos_x-n.x)/100
			local z_dst = (r_pos_z-n.z)/100
			DrawTextA(x_dst,12,180,40)
			DrawTextA(z_dst,12,180,60)

			local mx1 = m - x_dst
			local mx2 = m2 + z_dst

			if not (mx1 > 14 or mx1 < 0 or mx2 > 14 or mx2 < 0) then

				DrawTextA(mx1,12,180,80)
				DrawTextA(mx2,12,180,100)

				DrawTextA("E",15,WINDOW_W_MID-143+mx1*20,WINDOW_H_MID-147+mx2*20,ARGB(255,255,0,0))
			end
		end
	end

	for i=1,#ally_heroes do
		local current = ally_heroes[i]
		if current and current.valid and not current.dead and current.bTargetable and current.visible then
			local n = Vector(math.round(current.x/100)*100,0,math.round(current.z/100)*100)

			DrawTextA(n,12,180,20)

			local x_dst = (r_pos_x-n.x)/100
			local z_dst = (r_pos_z-n.z)/100
			DrawTextA(x_dst,12,180,40)
			DrawTextA(z_dst,12,180,60)

			local mx1 = m - x_dst
			local mx2 = m2 + z_dst

			if not (mx1 > 14 or mx1 < 0 or mx2 > 14 or mx2 < 0) then

				DrawTextA(mx1,12,180,80)
				DrawTextA(mx2,12,180,100)

				DrawTextA("A",15,WINDOW_W_MID-143+mx1*20,WINDOW_H_MID-147+mx2*20,ARGB(255,0,255,0))
			end
		end
	end

	for i=1,#ally_minions.objects do
		local current = ally_minions.objects[i]
		if current and current.valid and not current.dead and current.bTargetable and current.visible then
			local n = Vector(math.round(current.x/100)*100,0,math.round(current.z/100)*100)

			DrawTextA(n,12,180,20)

			local x_dst = (r_pos_x-n.x)/100
			local z_dst = (r_pos_z-n.z)/100
			DrawTextA(x_dst,12,180,40)
			DrawTextA(z_dst,12,180,60)

			local mx1 = m - x_dst
			local mx2 = m2 + z_dst

			if not (mx1 > 14 or mx1 < 0 or mx2 > 14 or mx2 < 0) then

				DrawTextA(mx1,12,180,80)
				DrawTextA(mx2,12,180,100)

				DrawTextA("M",15,WINDOW_W_MID-143+mx1*20,WINDOW_H_MID-147+mx2*20,ARGB(255,0,255,0))
			end
		end
	end

	for i=1,#enemy_minions.objects do
		local current = enemy_minions.objects[i]
		if current and current.valid and not current.dead and current.bTargetable and current.visible then
			local n = Vector(math.round(current.x/100)*100,0,math.round(current.z/100)*100)

			DrawTextA(n,12,180,20)

			local x_dst = (r_pos_x-n.x)/100
			local z_dst = (r_pos_z-n.z)/100
			DrawTextA(x_dst,12,180,40)
			DrawTextA(z_dst,12,180,60)

			local mx1 = m - x_dst
			local mx2 = m2 + z_dst

			if not (mx1 > 14 or mx1 < 0 or mx2 > 14 or mx2 < 0) then

				DrawTextA(mx1,12,180,80)
				DrawTextA(mx2,12,180,100)

				DrawTextA("M",15,WINDOW_W_MID-143+mx1*20,WINDOW_H_MID-147+mx2*20,ARGB(255,255,0,0))
			end
		end
	end



	DrawTextA(r_pos_x,12,20,20)
	DrawTextA(r_pos_z,12,20,40)
	local mousePoswts = WorldToScreen(D3DXVECTOR3(mousePos.x,mousePos.y,mousePos.z))
	DrawTextA(math.round(mousePoswts.x).." : "..math.round(mousePoswts.y),12,20,80)
	DrawTextA(GetDistance(Vector(0,0,0))-1500, 12,20,100)
end)

local function DamageToFitness(target, damage)
	local fitness = damage
	if target.type == "obj_AI_Turret" then
		fitness = fitness*1.2
	elseif target.type == myHero.type then
		fitness = fitness*1.5
	end

	print("Health: "..target.health)
	return fitness
end

AddDamageCallback(function(source,target,damage)
	if not source or not source.isMe then return end
	local dtf = DamageToFitness(target, damage)
	print("Fitness Gain: "..dtf)
end)
