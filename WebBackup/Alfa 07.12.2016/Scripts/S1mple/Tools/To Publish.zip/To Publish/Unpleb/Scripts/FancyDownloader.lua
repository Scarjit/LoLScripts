
-- COPY THIS FROM HERE


local function class(base, init)
    local c = {}
    if not init and type(base) == 'function' then
        init = base
        base = nil
    elseif type(base) == 'table' then
        for i,v in pairs(base) do
            c[i] = v
        end
        c._base = base
    end
    c.__index = c

    local mt = {}
    mt.__call = function(class_tbl, ...)
        local obj = {}
        setmetatable(obj,c)
        if init then
            init(obj,...)
        else
            if base and base.init then
                base.init(obj, ...)
            end
        end
        return obj
    end
    c.init = init
    c.is_a = function(self, klass)
        local m = getmetatable(self)
        while m do
            if m == klass then return true end
            m = m._base
        end
        return false
    end
    setmetatable(c, mt)
    return c
end

local downloads = {}
function AddDownload(server, server_path, localpath, port, data, options)
	local function sprite_file_exists()
		local file = io.open(SPRITE_PATH.."\\S1mple\\Downloader\\Sprite.png")
		if file then file:close() return true else return false end
	end
	if sprite_file_exists() then
		local dlsize = #downloads
		local pos_y = 20+dlsize*30
		downloads[#downloads+1] = FancyDownload(server, server_path, localpath, port, data, 20, pos_y, false, options, dlsize)
	else
		--Main Download
		local dlsize = #downloads
		local pos_y = 20+dlsize*30
		downloads[#downloads+1] = FancyDownload(server, server_path, localpath, port, data, 20, pos_y, true, options, dlsize)

		--Download sprite for next time
		local dlsize = #downloads
		local pos_y = 20+dlsize*30
		downloads[#downloads+1] = FancyDownload("s1mplescripts.de", "/S1mple/Scripts/BolStudio/FancyDownloader/Sprite.png", SPRITE_PATH.."\\S1mple\\Downloader\\Sprite.png", 80, {}, 20, pos_y, true)
	end
end

FancyDownload = class(function(fd,server, server_path, localpath, port, data, pos_x, pos_y, ncp, options, i)
    assert(type(server) == "string" or type(server_path) == "string", "FancyDownload: wrong argument types (<string><string> expected for server, server_path)")
    if not data then data = {} end
    if not port then port = 80 end
    if not options then options = {} end
    if not ncp then ncp = false end
    fd.server = server
    fd.server_path = server_path
    fd.localpath = localpath
    fd.port = port
    fd.data = data
    fd.progress = 0
    fd.ncp = ncp
    fd.pos_x = pos_x
    fd.pos_y = pos_y
    fd.file_size = math.huge
    fd.lua_socket = require("socket")
    fd.download_tcp = nil
    fd.response = ""
    fd.status = ""
    fd.cutheader = false
    fd.bytesperchunk = 8096
    fd.nicename = ""
    fd.i = i
    fd.c_time = 0
    fd.passed_time = 0
    fd.after_download_text = nil

    fd:parseoptions(options)
    fd:ncp_special_checks()
    fd:LoadSprite()
    fd:StartDownload()
    AddDrawCallback(function ()
    	fd:DrawProgress()
    end)
    AddUnloadCallback(function ()
    	fd:Cleanup()
    end)
end)

function FancyDownload:ncp_special_checks()
	CreateDirectory(SPRITE_PATH.."\\S1mple")
	CreateDirectory(SPRITE_PATH.."\\S1mple\\Downloader")
end

function FancyDownload:parseoptions(options)
	for _,v in pairs(options) do
		if v.key == "bps" then
			self.bytesperchunk = v.value
		elseif v.key == "nicename" then
			self.nicename = v.value
		elseif v.key == "afterdltext" then
			self.after_download_text = v.value
		end
	end
end

function FancyDownload:StartDownload()
	self:GetFileSize()
	self.download_tcp = self.lua_socket.connect(self.server,self.port)
	local requeststring = "GET "..self.server_path
	local first = true
	for i,v in pairs(self.data)do
		requeststring = requeststring..(first and "?" or "&")..i.."="..v
		first = false
	end
	requeststring = requeststring.. " HTTP/1.0\r\nHost: "..self.server.."\r\n\r\n"
	self.download_tcp:send(requeststring)
	AddTickCallback(function ()
		self:Tick()
	end)
end

function FancyDownload:Tick()
	if self.status == "timeout" or self.status == "closed" then
		self:WriteToFile(self.response)
		self.status = "end"
		self:Cleanup()
	elseif self.status ~= "end" then
		s,status, partial = self.download_tcp:receive(self.bytesperchunk)
		self.status = status
		self.response = self.response..(s or partial)

		local headerend = string.find(self.response, "\r\n\r\n")
		if (headerend and not self.cutheader) then
			self.response = self.response:sub(headerend+4)
			self.cutheader = true
		end
		self.progress = self.response:len()/self.file_size*100
		if(math.floor(os.clock()) > self.c_time)then
			self.passed_time = self.passed_time + 1
		end
	end
end

function FancyDownload:GetFileSize()
	local connection_tcp = self.lua_socket.connect(self.server,self.port)
	local requeststring = "HEAD "..self.server_path
	local first = true
	for i,v in pairs(self.data)do
		requeststring = requeststring..(first and "?" or "&")..i.."="..v
		first = false
	end
	requeststring = requeststring.. " HTTP/1.0\r\nHost: "..self.server.."\r\n\r\n"
	connection_tcp:send(requeststring)
	local response = ""
	local status
	while true do
		s,status, partial = connection_tcp:receive('*a')
		response = response..(s or partial)
		if(status == "closed" or status == "timeout")then
			break
		end
	end
	local snip_1 = string.find(response, "Length:")+8
	response = response:sub(snip_1)
	local snip_2 = string.find(response, "\n")-2
	response = response:sub(0,snip_2)
	self.file_size = tonumber(response)
end

function FancyDownload:DrawProgress()
	if self.ncp then return end

	--Background
	self.sprite:DrawEx(Rect(0,10,417,25), D3DXVECTOR3(0,0,0), D3DXVECTOR3(self.pos_x,self.pos_y,0), 255)
	--Foreground
	self.sprite:DrawEx(Rect(0,0,self.progress*4.17,10), D3DXVECTOR3(0,0,0), D3DXVECTOR3(self.pos_x+3,self.pos_y+2,0), 255)
	if self.status == "end" then
		if self.after_download_text then
			DrawTextA(self.after_download_text,12, self.pos_x+3,self.pos_y-12)
		else
			DrawTextA((self.nicename or self.localpath).. " downloaded",12, self.pos_x+3,self.pos_y-12)
		end
	else
		DrawTextA((self.nicename or self.localpath).." Speed: "..math.floor(self.response:len()/self.passed_time).." bytes/sec",12, self.pos_x+3,self.pos_y-12)
	end
end

function FancyDownload:LoadSprite()
	if self.ncp then return end
	self.sprite = GetSprite("S1mple\\Downloader\\Sprite.png")
end

function FancyDownload:Cleanup()
	if not self.ncp and self.sprite then
		self.sprite:Release()
	end
end

function FancyDownload:WriteToFile(text)
	local file = io.open(self.localpath, "wb")
	file:write(tostring(text))
	file:close()
end

function TCPGetRequest(server, path, data, port)
	local start_t = os.clock()
	local port = port or 80
	local data = data or {}
	local lua_socket = require("socket")
	local connection_tcp = lua_socket.connect(server,port)
	local requeststring = "GET "..path
	local first = true

	for i,v in pairs(data) do
		requeststring = requeststring..(first and "?" or "&")..i.."="..v
		first = false
	end
	
	requeststring = requeststring.. " HTTP/1.0\r\nHost: "..server.."\r\n\r\n"
	connection_tcp:send(requeststring)
	local response = ""
	local status
	while true do
		s,status, partial = connection_tcp:receive('*a')
		response = response..(s or partial)
		if(status == "closed" or status == "timeout")then
			break
		end
	end
	local end_t = os.clock()
	local start_content = response:find("\r\n\r\n")+4
	response = response:sub(start_content)
	return response, status, end_t-start_t
end

function UpdateMe(base_url, version_uri, local_version, file_uri, save_path, port, version_data, file_data, options)
	--Check if update exists
	local r = TCPGetRequest(base_url, version_uri, version_data, port)
	if not r or not tonumber(r) then
		print("[FancyDownloader] There was an error checking the version file")
		return
	end

	if tonumber(r) > local_version then
		AddDownload(base_url, file_uri, save_path, port, file_data, options)
	else
		print("[FancyDownloader] No update found")
	end
end

--COPY THIS TILL HERE
