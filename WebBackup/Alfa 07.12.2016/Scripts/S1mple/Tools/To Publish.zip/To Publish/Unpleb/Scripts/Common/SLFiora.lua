--Author: S1mple
--[[
   _____ _        _____           _        _      _____               
  / ____| |      |  __ \         | |      | |    / ____|              
 | (___ | |      | |__) |_ _  ___| | _____| |_  | |     ___  _ __ ___ 
  \___ \| |      |  ___/ _` |/ __| |/ / _ \ __| | |    / _ \| '__/ _ \
  ____) | |____  | |  | (_| | (__|   <  __/ |_  | |___| (_) | | |  __/
 |_____/|______| |_|   \__,_|\___|_|\_\___|\__|  \_____\___/|_|  \___|
                                                                      
                                                                      
--]]
require("FHPrediction")
local ts_instance = TargetSelector(TARGET_PRIORITY, 4000)
local mm_instance = minionManager(MINION_ENEMY, 1500, player, MINION_SORT_HEALTH_ASC)
local jm_instance = minionManager(MINION_JUNGLE, 1500, player, MINION_SORT_HEALTH_ASC)

local enemy_heroes = GetEnemyHeroes()
local script_version = 1.5
local min_log_level = 2
local menu
local oldprint = print
local print = function(arg,loglevel)

	if(loglevel and loglevel < min_log_level) then
		return
	elseif not loglevel then
		loglevel = 2
	end
	
	local ll = {
		"/DEBUG",
		"/Information",
		"/Warning",
		"/Error",
	}
	oldprint('<font color=\"#808080\">S1mple_Loader </font><font color=\"#10FFFF\">['..myHero.charName..(ll[loglevel] and ll[loglevel] or "")..']</font><font color=\"#515151\"> - </font><font color=\"#FFFFFF\">'..tostring(arg)..'</font>')
end

local function TCPGetRequest(server, path, data, port)
	local start_t = os.clock()
	local port = port or 80
	local data = data or {}
	local lua_socket = require("socket")
	local connection_tcp = lua_socket.connect(server,port)
	local requeststring = "GET "..path
	local first = true

	for i,v in pairs(data) do
		requeststring = requeststring..(first and "?" or "&")..i.."="..v
		first = false
	end
	
	requeststring = requeststring.. " HTTP/1.0\r\nHost: "..server.."\r\n\r\n"
	connection_tcp:send(requeststring)
	local response = ""
	local status
	while true do
		s,status, partial = connection_tcp:receive('*a')
		response = response..(s or partial)
		if(status == "closed" or status == "timeout")then
			break
		end
	end
	local end_t = os.clock()
	local start_content = response:find("\r\n\r\n")+4
	response = response:sub(start_content)
	return response, status, end_t-start_t
end

local function GetWebFile(server, path, data, localfilename, port)
	local r,s,t = TCPGetRequest(server, path, data, port)
	local a,b = Base64Decode(r)
	if (a ~= "No_new_version" and a ~= "Invalid Request" and a ~= "MYSQL Error" and a ~= "") then
		local file = io.open(localfilename,"w+b")
		file:write(a)
		file:close()
		print("Download Finished")
		return true
	else
		if a ~= "No_new_version" then
			print(a, 4)
		end
		return false
	end
end

local function Update()
	if(menu.autoupdate)then
		if(GetWebFile("s1mplescripts.de","/S1mple/Scripts/BolStudio/RandomBundle/index.php", {fn = myHero.charName, v = script_version}, LIB_PATH.."SL"..myHero.charName..".lua"))then
			print("Updated, please reload",2)
		else
			print("No update found",2)
		end
	else
		print("Updates disabled", 3)
	end
end

--[[
                         _ _                _____       _          _   _             _____ _               ______                        
     /\                 | (_)              / ____|     | |        | | | |           / ____| |             |  ____|                       
    /  \  _   _ _ __ ___| |_  ___  _ __   | (___   ___ | |   __   | |_| |__   ___  | (___ | |_ __ _ _ __  | |__ ___  _ __ __ _  ___ _ __ 
   / /\ \| | | | '__/ _ \ | |/ _ \| '_ \   \___ \ / _ \| |  |__|  | __| '_ \ / _ \  \___ \| __/ _` | '__| |  __/ _ \| '__/ _` |/ _ \ '__|
  / ____ \ |_| | | |  __/ | | (_) | | | |  ____) | (_) | |        | |_| | | |  __/  ____) | || (_| | |    | | | (_) | | | (_| |  __/ |   
 /_/    \_\__,_|_|  \___|_|_|\___/|_| |_| |_____/ \___/|_|         \__|_| |_|\___| |_____/ \__\__,_|_|    |_|  \___/|_|  \__, |\___|_|   
                                                                                                                          __/ |          
                                                                                                                         |___/           
--]]

local function Menu()
	menu = scriptConfig("Simple Loader ["..myHero.charName.."]", "SL"..myHero.charName)
	menu:addSubMenu("Advanced Settings", "adv") --DONE
		menu.adv:addParam("debuglvl", "Debug Level", SCRIPT_PARAM_LIST, 2, {"DEBUG", "Information", "Warning", "Error"}) --DONE
		menu.adv:setCallback("debuglvl", function(value) --DONE
			min_log_level = value
		end)
		min_log_level = menu.adv.debuglvl
		
	

	--End Champ Specific
	
	menu:addParam("autoupdate","Autoupdate", SCRIPT_PARAM_ONOFF, true) --DONE
	menu:addParam("version", "Version: ", SCRIPT_PARAM_INFO, script_version) --DONE
end

--Some nice var's
local LoadedWalker
local function GetOrbWalker()
	if _G.S1OrbLoading or _G.S1mpleOrbLoaded then LoadedWalker = "S1Orb" end
	if _G.Reborn_Loaded or _G.AutoCarry then LoadedWalker = "SAC:R" end
	if SAC then LoadedWalker = "SAC:P" end
	if _Pewalk then LoadedWalker = "PEW" end
	if not LoadedWalker then print("You need to load an OrbWalker to load this Script",4) return false end
	return true
end

function GetOrbMode()
	if LoadedWalker == "S1Orb" then
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "none" then return 0 end
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "harass" then return 1 end
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "laneclear" then return 2 end
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "lasthit" then return 3 end
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "sbtw" then return 4 end
	elseif LoadedWalker == "SAC:R" then
		if not _G.AutoCarry or not _G.AutoCarry.Keys then return 0 end
		if _G.AutoCarry.Keys.MixedMode then return 1 end
		if _G.AutoCarry.Keys.LaneClear then return 2 end
		if _G.AutoCarry.Keys.LastHit then return 3 end
		if _G.AutoCarry.Keys.AutoCarry then return 4 end
	elseif LoadedWalker == "SAC:P" then
		if SAC:GetActiveMode() == "MixedMode" then return 1 end
		if SAC:GetActiveMode() == "Laneclear" then return 2 end
		if SAC:GetActiveMode() == "LastHit" then return 3 end
		if SAC:GetActiveMode() == "AutoCarry" then return 4 end		
	elseif LoadedWalker == "PEW" then
		if not _Pewalk then return 0 end
		if _Pewalk.GetActiveMode().Mixed then return 1 end
		if _Pewalk.GetActiveMode().LaneClear then return 2 end
		if _Pewalk.GetActiveMode().Farm then return 3 end
		if _Pewalk.GetActiveMode().Carry then return 4 end
	elseif LoadedWalker == "NOW" then
		if not _G.NebelwolfisOrbWalkerInit then return 0 end
		if _G.NebelwolfisOrbWalker.mode == "Mixed" then return 1 end
		if _G.NebelwolfisOrbWalker.mode == "LaneClear" then return 2 end		
		if _G.NebelwolfisOrbWalker.mode == "LastHit" then return 3 end	
		if _G.NebelwolfisOrbWalker.mode == "Combo" then return 4 end
	end

	return 0
end

function GetOrbTarget()
	if LoadedWalker == "S1Orb" then
		return (_G.S1mpleOrbLoaded and _G.S1:GetTarget() or nil)
	elseif LoadedWalker == "SAC:R" and _G.AutoCarry and _G.AutoCarry.SkillsCrosshair then
		return _G.AutoCarry.SkillsCrosshair.target
	elseif LoadedWalker == "SAC:P" then
		return SAC:GetTarget()
	elseif LoadedWalker == "PEW" then
		return _Pewalk.GetTarget()
	elseif LoadedWalker == "NOW" then
		return _G.NebelwolfisOrbWalker:GetTarget()
	end
end
local function GetCTarget(range)
	if not range then range = myHero.range end
	local target = GetOrbTarget()
	if not target or GetDistance(target) > range then
		local mode = GetOrbMode()
		if mode == 1 then -- Mixed Mode (Harras)
			ts_instance.range = range
			target = ts_instance.target
			ts_instance.range = 4000
			if not target then
				mm_instance.range = range
				target = mm_instance.objects[1]
				mm_instance.range = 1500
			end
			if not target then
				jm_instance.range = range
				target = jm_instance.objects[1]
				jm_instance.range = 1500
			end
		elseif mode == 2 then -- LaneClear
			mm_instance.range = range
			target = mm_instance.objects[1]
			mm_instance.range = 4000
			if not target then
				jm_instance.range = range
				target = jm_instance.objects[1]
				jm_instance.range = 1500
			end
		elseif mode == 3 then -- LastHit
			mm_instance.range = range
			target = mm_instance.objects[1]
			mm_instance.range = 1500		
			if not target then
				jm_instance.range = range
				target = jm_instance.objects[1]
				jm_instance.range = 1500
			end
		elseif mode == 4 then --SBTW
			ts_instance.range = range
			target = ts_instance.target
			ts_instance.range = 400
		end			
	end
	return target
end

--MATH
local sqrt = math.sqrt
local function CalcVector(source,target)
	local V = Vector(source.x, source.y, source.z)
	local V2 = Vector(target.x, target.y, target.z)
	local vec = V-V2
	local vec2 = vec:normalized()
	return vec2
end

local function GetDistance(p1, p2)
	if not p1 then oldprint(debug.getinfo(2)) end 
	p2 = p2 or player
    local s = (p1.x - p2.x) ^ 2 + ((p1.z or p1.y) - (p2.z or p2.y)) ^ 2
	return sqrt(s)
end
--END MATH

-- NORMAL MODES

local function Combo()
end

local function Harras()
end

local function Laneclear()
end

local function Modes()
	local mode = GetOrbMode()
	if mode == 4 then
		Combo()
	elseif mode == 1 then
		Harras()
	elseif mode == 2 then
		Laneclear()
	end
end

--END NORMAL MODES


function GetEnemyHeroesInRange(range)
	local ret = {}
	for k,v in pairs(GetEnemyHeroes()) do
		if v and GetDistance(v) then
			ret[#ret+1] = v
		end
	end
	return ret
end

local function drawDebugStuff()
	if min_log_level > 1 then return end
	
end
--END DRAWS

AddLoadCallback(function()
	if not GetOrbWalker() then return end
	Menu()
	Update()
end)

AddDrawCallback(function()
	if not LoadedWalker then return end
	drawDebugStuff()
end)

AddTickCallback(function()
	if not LoadedWalker then return end
	Modes()
	jm_instance:update()
	mm_instance:update()
	ts_instance:update()
end)

AddProcessSpellCallback(function(unit, spell)
	if not LoadedWalker then return end
end)

AddCreateObjCallback(function(object)
	if not LoadedWalker then return end
end)