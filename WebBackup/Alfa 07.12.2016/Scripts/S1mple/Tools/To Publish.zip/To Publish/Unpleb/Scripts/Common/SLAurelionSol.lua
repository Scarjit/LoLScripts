--Author: S1mple
--[[
   _____ _        _____           _        _      _____               
  / ____| |      |  __ \         | |      | |    / ____|              
 | (___ | |      | |__) |_ _  ___| | _____| |_  | |     ___  _ __ ___ 
  \___ \| |      |  ___/ _` |/ __| |/ / _ \ __| | |    / _ \| '__/ _ \
  ____) | |____  | |  | (_| | (__|   <  __/ |_  | |___| (_) | | |  __/
 |_____/|______| |_|   \__,_|\___|_|\_\___|\__|  \_____\___/|_|  \___|
                                                                      
                                                                      
--]]
require("FHPrediction")
local ts_instance = TargetSelector(TARGET_PRIORITY, 4000)
local mm_instance = minionManager(MINION_ENEMY, 1500, player, MINION_SORT_HEALTH_ASC)
local jm_instance = minionManager(MINION_JUNGLE, 1500, player, MINION_SORT_HEALTH_ASC)

local enemy_heroes = GetEnemyHeroes()
local script_version = 2.0
local min_log_level = 2
local menu
local oldprint = print

local DrawCircle3D = _G.DrawCircle3D
local clock = os.clock
local ARGB = _G.ARGB
local IsGrass = _G.IsGrass


local print = function(arg,loglevel)

	if(loglevel and loglevel < min_log_level) then
		return
	elseif not loglevel then
		loglevel = 2
	end
	
	local ll = {
		"/DEBUG",
		"/Information",
		"/Warning",
		"/Error",
	}
	oldprint('<font color=\"#808080\">S1mple_Loader </font><font color=\"#10FFFF\">['..myHero.charName..(ll[loglevel] and ll[loglevel] or "")..']</font><font color=\"#515151\"> - </font><font color=\"#FFFFFF\">'..tostring(arg)..'</font>')
end

local function TCPGetRequest(server, path, data, port)
	local start_t = clock()
	local port = port or 80
	local data = data or {}
	local lua_socket = require("socket")
	local connection_tcp = lua_socket.connect(server,port)
	local requeststring = "GET "..path
	local first = true

	for i,v in pairs(data) do
		requeststring = requeststring..(first and "?" or "&")..i.."="..v
		first = false
	end
	
	requeststring = requeststring.. " HTTP/1.0\r\nHost: "..server.."\r\n\r\n"
	connection_tcp:send(requeststring)
	local response = ""
	local status
	while true do
		s,status, partial = connection_tcp:receive('*a')
		response = response..(s or partial)
		if(status == "closed" or status == "timeout")then
			break
		end
	end
	local end_t = clock()
	local start_content = response:find("\r\n\r\n")+4
	response = response:sub(start_content)
	return response, status, end_t-start_t
end

local function GetWebFile(server, path, data, localfilename, port)
	local r,s,t = TCPGetRequest(server, path, data, port)
	local a,b = Base64Decode(r)
	if (a ~= "No_new_version" and a ~= "Invalid Request" and a ~= "MYSQL Error" and a ~= "") then
		local file = io.open(localfilename,"w+b")
		file:write(a)
		file:close()
		print("Download Finished")
		return true
	else
		if a ~= "No_new_version" then
			print(a, 4)
		end
		return false
	end
end

local function Update()
	if(menu.autoupdate)then
		if(GetWebFile("s1mplescripts.de","/S1mple/Scripts/BolStudio/RandomBundle/index.php", {fn = myHero.charName, v = script_version}, LIB_PATH.."SL"..myHero.charName..".lua"))then
			print("Updated, please reload",2)
		else
			print("No update found",2)
		end
	else
		print("Updates disabled", 3)
	end
end

--[[
                         _ _                _____       _          _   _             _____ _               ______                        
     /\                 | (_)              / ____|     | |        | | | |           / ____| |             |  ____|                       
    /  \  _   _ _ __ ___| |_  ___  _ __   | (___   ___ | |   __   | |_| |__   ___  | (___ | |_ __ _ _ __  | |__ ___  _ __ __ _  ___ _ __ 
   / /\ \| | | | '__/ _ \ | |/ _ \| '_ \   \___ \ / _ \| |  |__|  | __| '_ \ / _ \  \___ \| __/ _` | '__| |  __/ _ \| '__/ _` |/ _ \ '__|
  / ____ \ |_| | | |  __/ | | (_) | | | |  ____) | (_) | |        | |_| | | |  __/  ____) | || (_| | |    | | | (_) | | | (_| |  __/ |   
 /_/    \_\__,_|_|  \___|_|_|\___/|_| |_| |_____/ \___/|_|         \__|_| |_|\___| |_____/ \__\__,_|_|    |_|  \___/|_|  \__, |\___|_|   
                                                                                                                          __/ |          
                                                                                                                         |___/           
--]]

local function Menu()
	menu = scriptConfig("Simple Loader ["..myHero.charName.."]", "SL"..myHero.charName)
	menu:addSubMenu("Advanced Settings", "adv") --DONE
		menu.adv:addParam("debuglvl", "Debug Level", SCRIPT_PARAM_LIST, 2, {"DEBUG", "Information", "Warning", "Error"}) --DONE
		menu.adv:setCallback("debuglvl", function(value) --DONE
			min_log_level = value
		end)
		min_log_level = menu.adv.debuglvl
		
	--Champ Specific
	menu:addSubMenu("Spell Settings", "spells") --DONE
		menu.spells:addSubMenu("Q", "q") --DONE
			menu.spells.q:addParam("autoqone", "Auto Q on E Cast", SCRIPT_PARAM_ONOFF, true) --DONE
			menu.spells.q:addParam("autoExplode", "Auto 2nd Cast against Champions", SCRIPT_PARAM_ONOFF, true) --DONE
			menu.spells.q:addParam("minautoExplode", "Min Enemy's for Auto 2nd Cast", SCRIPT_PARAM_SLICE, 1,1,5,0) --DONE

		menu.spells:addSubMenu("W", "w") --DONE
			menu.spells.w:addParam("autoscale", "Auto Scale", SCRIPT_PARAM_ONOFF, true) --DONE
			spell_w_ts_list = {"Most", "Lowlife"} --DONE
			menu.spells.w:addParam("ts", "Focus:", SCRIPT_PARAM_LIST,1,spell_w_ts_list) --DONE
			menu.spells.w:addParam("autosmallon", "Auto Shrink if no Enemy", SCRIPT_PARAM_ONOFF, true) --DONE
			menu.spells.w:addParam("autosmallLaneclear", "Auto Shrink only in Laneclear", SCRIPT_PARAM_ONOFF, false) --DONE
	
	menu:addSubMenu("Laneclear Settings", "ls") --DONE
		menu.ls:addParam("q", "Use Q", SCRIPT_PARAM_ONOFF, true) --DONE
		menu.ls:addParam("mec", "Use MEC", SCRIPT_PARAM_ONOFF, true)
		menu.ls:addParam("mecmin", "Min Minions to attempt MEC Calc", SCRIPT_PARAM_SLICE, 2, 1, 5,1)

	menu:addSubMenu("Harras Settings", "hs") --DONE
		menu.hs:addParam("q", "Use Q", SCRIPT_PARAM_ONOFF, true) --DONE
		menu.hs:addParam("mec", "Use MEC", SCRIPT_PARAM_ONOFF, true)

	menu:addSubMenu("Combo Mode", "c") --DONE
		menu.c:addParam("q", "Use Q", SCRIPT_PARAM_ONOFF, true) --DONE
		menu.c:addParam("mec", "Use MEC", SCRIPT_PARAM_ONOFF, true)
	
	menu:addSubMenu("Keys", "keys") --DONE
		menu.keys:addParam("EKey", "Cast E/Q in Mouse Direction", SCRIPT_PARAM_ONKEYDOWN, false, string.byte("N")) --DONE
		menu.keys:addParam("info", "Your Harras/Combo/Laneclear Keys are connected to your OrbWalker", SCRIPT_PARAM_INFO, "")

	menu:addSubMenu("Drawings", "draw") --DONE
		menu.draw:addParam("missles", "Draw Missile HitBox", SCRIPT_PARAM_ONOFF, true) --DONE
		menu.draw:addParam("passive", "Draw Passive Circle", SCRIPT_PARAM_ONOFF, true) --DONE
		menu.draw:addParam("qaoe", "Draw Q AOE", SCRIPT_PARAM_ONOFF, false) --DONE
		menu.draw:addParam("inf", "  => Will drastically lower FPS", SCRIPT_PARAM_INFO, "")
		menu.draw:addParam("marker", "Mark Target in Grass if hit by Passive", SCRIPT_PARAM_ONOFF, true) --DONE
		menu.draw:addParam("res", "Circle Resolution", SCRIPT_PARAM_SLICE, 6, 4, 60, 0)

	--End Champ Specific
	
	menu:addParam("autoupdate","Autoupdate", SCRIPT_PARAM_ONOFF, true) --DONE
	menu:addParam("version", "Version: ", SCRIPT_PARAM_INFO, script_version) --DONE
end

--Some nice var's
local LoadedWalker
local lastq = 0

local function GetQPredictionTable(target)
	local AurelionSolQ = {range = 650, speed = 600, delay = 0.25, radius = 0}
	if not target or lastq == 0 then return AurelionSolQ end
	AurelionSolQ.radius = 130+(clock()-lastq)*50
	return AurelionSolQ
end

local function setlastq(unit, spell)
	if unit and unit.isMe and spell and spell.name == "AurelionSolQ" then
		lastq = clock()
	end
end

local function GetOrbWalker()
	if _G.S1OrbLoading or _G.S1mpleOrbLoaded then LoadedWalker = "S1Orb" end
	if _G.Reborn_Loaded or _G.AutoCarry then LoadedWalker = "SAC:R" end
	if SAC then LoadedWalker = "SAC:P" end
	if _Pewalk then LoadedWalker = "PEW" end
	if _G.NebelwolfisOrbWalkerInit then LoadedWalker = "NOW" end
	if not LoadedWalker then print("You need to load an OrbWalker to load this Script",4) return false end
	return true
end

local function GetOrbMode()
	if LoadedWalker == "S1Orb" then
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "none" then return 0 end
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "harass" then return 1 end
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "laneclear" then return 2 end
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "lasthit" then return 3 end
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "sbtw" then return 4 end
	elseif LoadedWalker == "SAC:R" then
		if not _G.AutoCarry or not _G.AutoCarry.Keys then return 0 end
		if _G.AutoCarry.Keys.MixedMode then return 1 end
		if _G.AutoCarry.Keys.LaneClear then return 2 end
		if _G.AutoCarry.Keys.LastHit then return 3 end
		if _G.AutoCarry.Keys.AutoCarry then return 4 end
	elseif LoadedWalker == "SAC:P" then
		if SAC:GetActiveMode() == "MixedMode" then return 1 end
		if SAC:GetActiveMode() == "Laneclear" then return 2 end
		if SAC:GetActiveMode() == "LastHit" then return 3 end
		if SAC:GetActiveMode() == "AutoCarry" then return 4 end		
	elseif LoadedWalker == "PEW" then
		if not _Pewalk then return 0 end
		if _Pewalk.GetActiveMode().Mixed then return 1 end
		if _Pewalk.GetActiveMode().LaneClear then return 2 end
		if _Pewalk.GetActiveMode().Farm then return 3 end
		if _Pewalk.GetActiveMode().Carry then return 4 end
	elseif LoadedWalker == "NOW" then
		if not _G.NebelwolfisOrbWalkerInit then return 0 end
		if _G.NebelwolfisOrbWalker.mode == "Mixed" then return 1 end
		if _G.NebelwolfisOrbWalker.mode == "LaneClear" then return 2 end		
		if _G.NebelwolfisOrbWalker.mode == "LastHit" then return 3 end	
		if _G.NebelwolfisOrbWalker.mode == "Combo" then return 4 end
	end

	return 0
end

local function GetOrbTarget()
	if LoadedWalker == "S1Orb" then
		return (_G.S1mpleOrbLoaded and _G.S1:GetTarget() or nil)
	elseif LoadedWalker == "SAC:R" and _G.AutoCarry and _G.AutoCarry.SkillsCrosshair then
		return _G.AutoCarry.SkillsCrosshair.target
	elseif LoadedWalker == "SAC:P" then
		return SAC:GetTarget()
	elseif LoadedWalker == "PEW" then
		return _Pewalk.GetTarget()
	elseif LoadedWalker == "NOW" then
		return _G.NebelwolfisOrbWalker:GetTarget()
	end
end

local function GetCTarget(range)
	if not range then range = myHero.range end
	local target = GetOrbTarget()
	if not target or GetDistance(target) > range then
		local mode = GetOrbMode()
		if mode == 1 then -- Mixed Mode (Harras)
			ts_instance.range = range
			target = ts_instance.target
			ts_instance.range = 4000
			if not target then
				mm_instance.range = range
				target = mm_instance.objects[1]
				mm_instance.range = 1500
			end
			if not target then
				jm_instance.range = range
				target = jm_instance.objects[1]
				jm_instance.range = 1500
			end
		elseif mode == 2 then -- LaneClear
			mm_instance.range = range
			target = mm_instance.objects[1]
			mm_instance.range = 4000
			if not target then
				jm_instance.range = range
				target = jm_instance.objects[1]
				jm_instance.range = 1500
			end
		elseif mode == 3 then -- LastHit
			mm_instance.range = range
			target = mm_instance.objects[1]
			mm_instance.range = 1500		
			if not target then
				jm_instance.range = range
				target = jm_instance.objects[1]
				jm_instance.range = 1500
			end
		elseif mode == 4 then --SBTW
			ts_instance.range = range
			target = ts_instance.target
			ts_instance.range = 400
		end			
	end
	return target
end

--MATH
local sqrt = math.sqrt
local function CalcVector(source,target)
	local V = Vector(source.x, source.y, source.z)
	local V2 = Vector(target.x, target.y, target.z)
	local vec = V-V2
	local vec2 = vec:normalized()
	return vec2
end

local function GetDistance(p1, p2)
	if not p1 then oldprint(debug.getinfo(2)) end 
	p2 = p2 or player
    local s = (p1.x - p2.x) ^ 2 + ((p1.z or p1.y) - (p2.z or p2.y)) ^ 2
	return sqrt(s)
end
--END MATH

--GETTER
local qobj
local function SearchQObj()
	if qobj and qobj.valid and not qobj.dead then
		return qobj
	end -- Hopefully speeds up the lookup

	for i=1, objManager.maxObjects do
		local object = objManager:GetObject(i)
		if object and object.valid and object.name and object.name == "AurelionSol_Base_Q_Mis.troy" then
			qobj = object
			return qobj
		end
	end
end

local function GetQObj()
	if qobj and qobj.valid and not qobj.dead then
		return qobj
	end -- Hopefully speeds up the lookup
end

local missles = {}
local function GetMissles() --I should be able to cache it
	
	for i=1,#missles do
		local v = missles[i]
		if not v or not v.valid then
			missles[i] = nil
		end
	end
	
	if #missles > 3 then missles = {} end
	if #missles == 3 then return missles end
	
	local table_iterator = #missles
	for i=1, objManager.maxObjects do
		local object = objManager:GetObject(i)
		if object and object.name then
			if object.name == "AurelionSol_Base_P_MissileSmall.troy" or  object.name == "AurelionSol_Base_P_MissileLarge.troy" or object.name == "AurelionSol_Base_P_MissileSmall_toLarge.troy" or object.name == "AurelionSol_Base_P_MissileLarge_toSmall.troy" then
				table_iterator = table_iterator+1
				missles[table_iterator] = object
			end
		end
	end
	return missles
end
--END GETTER
local function _CalcSpellPosForGroup(radius, range, points)
    if #points == 0 then
        return nil
    elseif #points == 1 then
        return {center = Vector(points[1]), radius = nil}
    end
    local mec = MEC()
    local combos = {}
    for j = #points, 2, -1 do
        local spellPos
        combos[j] = {}
        _CalcCombos(j, points, combos[j])
        for _, v in ipairs(combos[j]) do
            mec:SetPoints(v)
            local c = mec:Compute()
            if c ~= nil and c.radius <= radius and c.center:dist(player) <= range and (spellPos == nil or c.radius < spellPos.radius) then
                spellPos = {center = c.center, radius = c.radius}
            end
        end
        if spellPos ~= nil then return spellPos end
    end
end

local function CastQPos(mode)
	local x = {}
	local objs = {}
	if mode == 1 then
		objs = mm_instance.objects
	elseif mode == 2 then
		objs = GetEnemyHeroes()
	end
	if mode == 1 and menu.ls.mecmin < #objs then return end
	
	for k,v in pairs(objs) do
		if v and v.valid and not v.dead and v.visible and GetDistance(v) <=780 then
			x[#x+1] = v
			if #x > 7 then break end
		end
	end
	if #x > 1 then
		local a = _CalcSpellPosForGroup(110,650,x)
		if a ~= nil then
			local center = a.center
			local radius = a.radius
			CastSpell(_Q, center.x, center.z)
		end
	elseif #x == 1 then
		local pos, hc, info = FHPrediction.GetPrediction(GetQPredictionTable(), x[1])
		if hc > 0 then
			CastSpell(_Q, pos.x, pos.z)
		end
	end
end

-- NORMAL MODES

local function Combo()
	if menu.c.q then
		if menu.c.mec then
			CastQPos(2)
		else
			local target = GetCTarget(780) --Outer limit + Radius
			if target and target.visible and not target.dead and target.bTargetable and target.type == myHero.type then
				local pos, hc, info = FHPrediction.GetPrediction(GetQPredictionTable(), target)
				if hc > 0 then
					CastSpell(_Q, pos.x, pos.z)
				end
			end
		end
	end
end

local function Harras()
	if menu.hs.q then
		if menu.hs.mec then
			CastQPos(2)
		else
			local target = GetCTarget(780) --Outer limit + Radius
			if target and target.visible and not target.dead and target.bTargetable then
				local pos, hc, info = FHPrediction.GetPrediction(GetQPredictionTable(), target)
				if hc > 0 then
					CastSpell(_Q, pos.x, pos.z)
				end
			end
		end
	end
end

local function Laneclear()
	if menu.ls.q then
		if menu.ls.mec then
			CastQPos(1)
		else
			local target = GetCTarget(780) --Outer limit + Radius
			if target and target.visible and not target.dead and target.bTargetable and target.type ~= myHero.type then
				local pos, hc, info = FHPrediction.GetPrediction(GetQPredictionTable(), target)
				if hc > 0 then
					CastSpell(_Q, pos.x, pos.z)
				end
			end
		end
	end
end

local function Modes()
	local mode = GetOrbMode()
	if mode == 4 then
		Combo()
	elseif mode == 1 then
		Harras()
	elseif mode == 2 then
		Laneclear()
	end
end

--END NORMAL MODES

--AUTO EXPLODE Q
local function autoExplodeQ()
	if not menu.spells.q.autoExplode then return end
	local q_obj = GetQObj()
	if(q_obj)then
		local size = 130+(clock()-lastq)*50
		local inrange = 0
		
		for i=1, #enemy_heroes do
			local v = enemy_heroes[i]
			if(v and v.valid and not v.dead and v.bTargetable and GetDistance(q_obj,v) < size) then
				inrange = inrange+1
			end
		end
		if inrange >= menu.spells.q.minautoExplode then
			CastSpell(_Q)
		end
	end
end
--END AUTO EXPLODE Q

--AUTO SCALE PASSIVE
local function autoscalePassive()
	if not myHero:CanUseSpell(_W) == 0 or not menu.spells.w.autoscale or #enemy_heroes == 0 then return end
	local missles = GetMissles()
	if not missles or not #missles or #missles == 0 or not missles[#missles] or not myHero then return end
	local missle_dst = GetDistance(missles[#missles])
	local ininner = 0
	local inouter = 0
	
	local lowlife_obj = nil
	local lowlife_isinner = false

	for i=1, #enemy_heroes do
		local v = enemy_heroes[i]
		if v and v.visible and not v.dead and v.bTargetable then
			local dst = GetDistance(v)
			if dst < 690 then --Is in outer
				if dst < 350 and dst > 310 then --In inner
					if not lowlife_obj or v.health < lowlife_obj.health then
						lowlife_obj = v
						lowlife_isinner = true
					end
					ininner = ininner + 1
				elseif dst > 490 then --In outer
					inouter = inouter + 1
					if not lowlife_obj or v.health < lowlife_obj.health then
						if not lowlife_obj or v.health < lowlife_obj.health then
							lowlife_obj = v
							lowlife_isinner = false
						end
					end
				end
			end
		end
	end

	if ininner + inouter > 0 then
		if menu.spells.w.ts == 1 then
			if ininner > inouter then
				if missle_dst > 400 then
					CastSpell(_W)
				end
			else
				if missle_dst < 400 then
					CastSpell(_W)
				end
			end
		else
			if lowlife_isinner and missle_dst > 400 then
				CastSpell(_W)
			elseif not lowlife_isinner and missle_dst < 400 then
				CastSpell(_W)
			end
		end		
	end
end
--END AUTO SCALE PASSIVE

function GetEnemyHeroesInRange(range)
	local ret = {}
	for k,v in pairs(GetEnemyHeroes()) do
		if v and GetDistance(v) then
			ret[#ret+1] = v
		end
	end
	return ret
end

--AUTO SHRINK PASSIVE
local function autoshrinkpassive()
	local missles = GetMissles()
	if not missles or not #missles or #missles == 0 or not missles[#missles] or not myHero then return end
	local missle_dst = GetDistance(missles[#missles])
	if missle_dst < 400 or missle_dst > 1000 then return end
	
	
	if menu.spells.w.autosmallon and myHero:CanUseSpell(_W) == 0 and #GetEnemyHeroesInRange(690) == 0 then
		if ((menu.spells.w.autosmallLaneclear and GetOrbMode() == 2) or not menu.spells.w.autosmallLaneclear) then
			CastSpell(_W)
		end
	end
end
--END AUTO SHRINK PASSIVE

--AUTO Q ON E
local function autoQonE(unit, spell)
	if unit and spell and spell.name and unit.isMe and spell.name == "AurelionSolE" and menu.spells.q.autoqone and myHero:CanUseSpell(_Q) == 0 then
		local bvec = CalcVector(spell.startPos, spell.endPos)*-500
		CastSpell(_Q, myHero.x+bvec.x, myHero.y+bvec.y, myHero.z+bvec.z)
	end
end
--END AUTO Q ON E

--AUTO Q/E COMBO
local function autoQE()
	if menu.keys.EKey and myHero:CanUseSpell(_E) == 0 then
		local bvec = CalcVector(myHero, mousePos)*-(2000+myHero:GetSpellData(_E).level*1000)
		CastSpell(_E, myHero.x+bvec.x,myHero.y+bvec.y,myHero.z+bvec.z)
		if not menu.spells.q.autoqone and myHero:CanUseSpell(_Q) == 0 then
			CastSpell(_Q, myHero.x+bvec.x,myHero.y+bvec.y,myHero.z+bvec.z)
		end
	end
end
--END AUTO Q/E COMBO

--CREATE OBJ CALLBACKS
local passive_hits = {}
local IsGrass = IsGrass
local function detectpassivehits(obj)
	if menu.draw.marker and obj and obj.name and (obj.name == "AurelionSol_Base_P_Audio_StarsIn_HitLarge.troy" or obj.name == "AurelionSol_Base_P_Audio_StarsIn_HitSmall.troy" or obj.name == "AurelionSol_Base_P_Audio_StarsOut_HitSmall.troy" or obj.name == "AurelionSol_Base_P_Audio_StarsIn_HitSmall.troy") and IsGrass(obj.pos) then
		local o = obj.pos
		passive_hits[#passive_hits+1] = {pos = o, t = clock()}
	end
end
--END CREATE OBJ CALLBACKS

--DRAWS
local function drawMissleHitBox()
	if not menu.draw.missles then return end
	local missles = GetMissles()
	for i = 1, #missles do
		local v = missles[i]
		if v and v.name ~= "AurelionSol_Base_P_MissileLarge.troy" then
				DrawCircle3D(v.x,v.y,v.z,50,1,ARGB(255,0,0,0),menu.draw.res)
		elseif v then
			DrawCircle3D(v.x,v.y,v.z,100,1,ARGB(255,0,0,0),menu.draw.res)
		end
	end
end

local function drawPassiveCircle()
	if not menu.draw.passive then return end
	local missles = GetMissles()
	if missles and missles[#missles] and myHero then
		DrawCircle3D(myHero.x, myHero.y, myHero.z, GetDistance(missles[#missles]), 2, ARGB(255,255,0,0), menu.draw.res)
	end
end

local function drawQAoe()
	if not menu.draw.qaoe then return end
	local q_obj = GetQObj()
	if q_obj then
		DrawCircle3D(q_obj.x,q_obj.y,q_obj.z,130+(clock()-lastq)*50, 1, ARGB(255,255,0,255),menu.draw.res)
	end
end

local function drawFOWHits()
	if not menu.draw.marker then return end
	for i = 1, #passive_hits do
		local v = passive_hits[i]
		if v and v.pos and v.t and v.t + 20 > clock() then
			if(IsGrass(v.pos)) then
				DrawCircle3D(v.pos.x,v.pos.y,v.pos.z, 150, 4, ARGB(255,255,0,200),menu.draw.res)
			end
		else
			passive_hits[i] = nil
		end
	end
end

local function drawDebugStuff()
	if min_log_level > 1 then return end
	DrawTextA(#GetMissles())
	
end
--END DRAWS

AddLoadCallback(function()
	if not GetOrbWalker() then return end
	Menu()
	Update()
end)

AddDrawCallback(function()
	if not LoadedWalker then return end
	drawMissleHitBox()
	drawPassiveCircle()
	drawQAoe()
	drawFOWHits()

	drawDebugStuff()

end)

AddTickCallback(function()
	if not LoadedWalker then return end


	Modes()

	SearchQObj()

	autoExplodeQ()

	autoscalePassive()
	
	autoQE()

	autoshrinkpassive()

	jm_instance:update()

	mm_instance:update()

	ts_instance:update()

end)

AddProcessSpellCallback(function(unit, spell)
	if not LoadedWalker then return end
	autoQonE(unit, spell)
	setlastq(unit,spell)
end)

AddCreateObjCallback(function(object)
	if not LoadedWalker then return end
	detectpassivehits(object)
end)