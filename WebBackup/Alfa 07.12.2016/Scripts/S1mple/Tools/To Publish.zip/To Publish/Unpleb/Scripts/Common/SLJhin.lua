--Author: S1mple
--[[
   _____ _        _____           _        _      _____               
  / ____| |      |  __ \         | |      | |    / ____|              
 | (___ | |      | |__) |_ _  ___| | _____| |_  | |     ___  _ __ ___ 
  \___ \| |      |  ___/ _` |/ __| |/ / _ \ __| | |    / _ \| '__/ _ \
  ____) | |____  | |  | (_| | (__|   <  __/ |_  | |___| (_) | | |  __/
 |_____/|______| |_|   \__,_|\___|_|\_\___|\__|  \_____\___/|_|  \___|
                                                                      
                                                                      
--]]
require("FHPrediction")
local ts_instance = TargetSelector(TARGET_PRIORITY, 4000)
local mm_instance = minionManager(MINION_ENEMY, 1500, player, MINION_SORT_HEALTH_ASC)
local jm_instance = minionManager(MINION_JUNGLE, 1500, player, MINION_SORT_HEALTH_ASC)

local enemy_heroes = GetEnemyHeroes()
local script_version = 0.2
local min_log_level = 2
local menu
local oldprint = print
local print = function(arg,loglevel)

	if(loglevel and loglevel < min_log_level) then
		return
	elseif not loglevel then
		loglevel = 2
	end
	
	local ll = {
		"/DEBUG",
		"/Information",
		"/Warning",
		"/Error",
	}
	oldprint('<font color=\"#808080\">S1mple_Loader </font><font color=\"#10FFFF\">['..myHero.charName..(ll[loglevel] and ll[loglevel] or "")..']</font><font color=\"#515151\"> - </font><font color=\"#FFFFFF\">'..tostring(arg)..'</font>')
end

local function TCPGetRequest(server, path, data, port)
	local start_t = os.clock()
	local port = port or 80
	local data = data or {}
	local lua_socket = require("socket")
	local connection_tcp = lua_socket.connect(server,port)
	local requeststring = "GET "..path
	local first = true
	for i,v in pairs(data)do
		requeststring = requeststring..(first and "?" or "&")..i.."="..v
		first = false
	end
	requeststring = requeststring.. " HTTP/1.0\r\nHost: "..server.."\r\n\r\n"
	connection_tcp:send(requeststring)
	local response = ""
	local status
	while true do
		s,status, partial = connection_tcp:receive('*a')
		response = response..(s or partial)
		if(status == "closed" or status == "timeout")then
			break
		end
	end
	local end_t = os.clock()
	local start_content = response:find("\r\n\r\n")+4
	response = response:sub(start_content)
	return response, status, end_t-start_t
end

local function GetWebFile(server, path, data, localfilename, port)
	local r,s,t = TCPGetRequest(server, path, data, port)
	local a,b = Base64Decode(r)
	if (a ~= "No_new_version" and a ~= "Invalid Request" and a ~= "MYSQL Error" and a ~= "") then
		file = io.open(localfilename,"w+b")
		file:write(a)
		file:close()
		return true
	else
		if a ~= "No_new_version" then
			print(a, 4)
		end
		return false
	end
end

local function Update()
	if(menu.autoupdate)then
		if(GetWebFile("s1mplescripts.de","/S1mple/Scripts/BolStudio/RandomBundle/index.php", {fn = myHero.charName, v = script_version}, LIB_PATH.."SL"..myHero.charName..".lua"))then
			print("Updated, please reload",2)
		else
			print("No update found",2)
		end
	else
		print("Updates disabled", 3)
	end
end

--[[
       _ _     _                 _______ _           __      ___      _                         
      | | |   (_)               |__   __| |          \ \    / (_)    | |                        
      | | |__  _ _ __      __      | |  | |__   ___   \ \  / / _ _ __| |_ _   _  ___  ___  ___  
  _   | | '_ \| | '_ \    |__|     | |  | '_ \ / _ \   \ \/ / | | '__| __| | | |/ _ \/ __|/ _ \ 
 | |__| | | | | | | | |            | |  | | | |  __/    \  /  | | |  | |_| |_| | (_) \__ \ (_) |
  \____/|_| |_|_|_| |_|            |_|  |_| |_|\___|     \/   |_|_|   \__|\__,_|\___/|___/\___/ 
                                                                                              
                                                                                              
--]]
local function Menu()
	menu = scriptConfig("Simple Loader ["..myHero.charName.."]", "SL"..myHero.charName)
		menu:addSubMenu("Advanced Settings", "adv") --DONE
		menu.adv:addParam("debuglvl", "Debug Level", SCRIPT_PARAM_LIST, 2, {"DEBUG", "Information", "Warning", "Error"}) --DONE
		menu.adv:setCallback("debuglvl", function(value) --DONE
			min_log_level = value
		end)
		min_log_level = menu.adv.debuglvl

	--Champ Specific
	
	
	--End Champ Specific
	
	menu:addParam("autoupdate","Autoupdate", SCRIPT_PARAM_ONOFF, true) --DONE
	menu:addParam("version", "Version: ", SCRIPT_PARAM_INFO, script_version) --DONE
end

--LOADED ORBWWALKER

function GetOrbMode()
	if LoadedWalker == "S1Orb" then
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "none" then return 0 end
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "harass" then return 1 end
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "laneclear" then return 2 end
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "lasthit" then return 3 end
		if _G.S1mpleOrbLoaded and _G.S1.aamode == "sbtw" then return 4 end
	elseif LoadedWalker == "SAC:R" then
		if not _G.AutoCarry or not _G.AutoCarry.Keys then return 0 end
		if _G.AutoCarry.Keys.MixedMode then return 1 end
		if _G.AutoCarry.Keys.LaneClear then return 2 end
		if _G.AutoCarry.Keys.LastHit then return 3 end
		if _G.AutoCarry.Keys.AutoCarry then return 4 end
	elseif LoadedWalker == "SAC:P" then
		if SAC:GetActiveMode() == "MixedMode" then return 1 end
		if SAC:GetActiveMode() == "Laneclear" then return 2 end
		if SAC:GetActiveMode() == "LastHit" then return 3 end
		if SAC:GetActiveMode() == "AutoCarry" then return 4 end		
	elseif LoadedWalker == "PEW" then
		if not _Pewalk then return 0 end
		if _Pewalk.GetActiveMode().Mixed then return 1 end
		if _Pewalk.GetActiveMode().LaneClear then return 2 end
		if _Pewalk.GetActiveMode().Farm then return 3 end
		if _Pewalk.GetActiveMode().Carry then return 4 end
	elseif LoadedWalker == "NOW" then
		if not _G.NebelwolfisOrbWalkerInit then return 0 end
		if _G.NebelwolfisOrbWalker.mode == "Mixed" then return 1 end
		if _G.NebelwolfisOrbWalker.mode == "LaneClear" then return 2 end		
		if _G.NebelwolfisOrbWalker.mode == "LastHit" then return 3 end	
		if _G.NebelwolfisOrbWalker.mode == "Combo" then return 4 end
	end

	return 0
end

function GetOrbTarget()
	if LoadedWalker == "S1Orb" then
		return (_G.S1mpleOrbLoaded and _G.S1:GetTarget() or nil)
	elseif LoadedWalker == "SAC:R" and _G.AutoCarry and _G.AutoCarry.SkillsCrosshair then
		return _G.AutoCarry.SkillsCrosshair.target
	elseif LoadedWalker == "SAC:P" then
		return SAC:GetTarget()
	elseif LoadedWalker == "PEW" then
		return _Pewalk.GetTarget()
	elseif LoadedWalker == "NOW" then
		return _G.NebelwolfisOrbWalker:GetTarget()
	end
end

local function GetCTarget(range)
	if not range then range = myHero.range end
	local target = GetOrbTarget()
	if not target or GetDistance(target) > range then
		local mode = GetOrbMode()
		if mode == 1 then -- Mixed Mode (Harras)
			ts_instance.range = range
			target = ts_instance.target
			ts_instance.range = 4000
			if not target then
				mm_instance.range = range
				target = mm_instance.objects[1]
				mm_instance.range = 1500
			end
			if not target then
				jm_instance.range = range
				target = jm_instance.objects[1]
				jm_instance.range = 1500
			end
		elseif mode == 2 then -- LaneClear
			mm_instance.range = range
			target = mm_instance.objects[1]
			mm_instance.range = 4000
			if not target then
				jm_instance.range = range
				target = jm_instance.objects[1]
				jm_instance.range = 1500
			end
		elseif mode == 3 then -- LastHit
			mm_instance.range = range
			target = mm_instance.objects[1]
			mm_instance.range = 1500		
			if not target then
				jm_instance.range = range
				target = jm_instance.objects[1]
				jm_instance.range = 1500
			end
		elseif mode == 4 then --SBTW
			ts_instance.range = range
			target = ts_instance.target
			ts_instance.range = 400
		end			
	end
	
	return target
end
--END LOADED ORBWWALKER

local function GetDmg(spell, unit)
	if unit and unit.visible and not unit.dead and unit.bTargetable then

		local ADDmg = 0
		local APDmg = 0

		local Level = myHero.level
		local TotalDmg = myHero.totalDamage
		local AddDmg = myHero.addDamage
		local AP = myHero.ap
		local ArmorPen = myHero.armorPen
		local ArmorPenPercent = myHero.armorPenPercent
		local MagicPen = myHero.magicPen
		local MagicPenPercent = myHero.magicPenPercent

		local Armor = math.max(0, unit.armor*ArmorPenPercent-ArmorPen)
		local ArmorPercent = Armor/(100+Armor)
		local MagicArmor = math.max(0, unit.magicArmor*MagicPenPercent-MagicPen)
		local MagicArmorPercent = MagicArmor/(100+MagicArmor)

		if spell == "AA" then
			local last_shot = false
			for i=1, objManager.maxObjects do
				local obj = objManager:getObject(i)
				if obj and obj.valid and obj.name == "Jhin_Base_BA_4th_shot_readyhand.troy" and GetDistance(obj) < 100 then
					last_shot = true
					break
				end
			end

			ADDmg = TotalDmg

			if last_shot then
				local multiplier = (myHero.level == 1 and 1.15) or (myHero.level == 6 and 1.20) or (myHero.level == 11 and 1.25)
				local missing_health = unit.maxHealth-unit.health
				local addDamage = missing_health*multiplier
				ADDmg = ADDmg*1.5+addDamage
			end

		elseif spell == "Q" then
			if myHero:CanUseSpell(_Q) == READY then
				ADDmg = 25*myHero:GetSpellData(_Q).level+25+0.60*AP+((5*myHero:GetSpellData(_Q).level+30)*0.01*myHero.addDamage)
			end
		elseif spell == "W" then
			if myHero:CanUseSpell(_W) == READY then
				ADDmg = 35*myHero:GetSpellData(_W).level+15+0.5*myHero.addDamage
			end
		elseif spell == "E" then
			if myHero:CanUseSpell(_E) == READY then
				APDmg = 60*myHero:GetSpellData(_W).level+20*AP*1.2*myHero.addDamage		
			end
		elseif spell == "R" then
			if myHero:CanUseSpell(_R) == READY then
				ADDmg = 60*myHero:GetSpellData(_R).level-20+0.2*myHero.addDamage
				local healthperc = 100-(unit.health/unit.maxHealth*100)
				local dmg_inc_perc = 2.5*healthperc
				ADDmg = ADDmg*(1+dmg_inc_perc/10)
			end
		end

		local TrueDmg = ADDmg*(1-ArmorPercent)+APDmg*(1-MagicArmorPercent)

		return TrueDmg
	end
	return 0
end


local function CastQ(target)
	if not target then
		target = GetCTarget(2500)
	end
	if not target then return end

	CastSpell(_Q, target)
end

local function CastW(target)
	if not target then
		target = GetCTarget(2500)
	end
	
	if target and target.valid and not target.dead and target.visible then
		local CastPos, HitChance, _ = FHPrediction.GetPrediction("W", target)
		if CastPos and HitChance > 1 then
			CastSpell(_E, CastPos.x, CastPos.z)
		end
	end
end

-- NORMAL MODES

local function Combo()
	
end

local function Harras()
	
end

local function Laneclear()
	
end

local function Modes()
	local mode = GetOrbMode()
	if mode == 4 then
		Combo()
	elseif mode == 1 then
		Harras()
	elseif mode == 2 then
		Laneclear()
	end
end

--END NORMAL MODES

--MATH
function CalcVector(source,target)
	local V = Vector(source.x, source.y, source.z)
	local V2 = Vector(target.x, target.y, target.z)
	local vec = V-V2
	local vec2 = vec:normalized()
	return vec2
end
--END MATH

--DRAWS
--END DRAWS

AddLoadCallback(function()
	if not GetOrbWalker() then return end
	Menu()
	Update()
end)

AddDrawCallback(function()
	if not LoadedWalker then return end

end)

AddTickCallback(function()
	if not LoadedWalker then return end
	Modes()
end)

AddProcessSpellCallback(function(unit, spell)
	if not LoadedWalker then return end
end)

AddCreateObjCallback(function(object)
	if not LoadedWalker then return end
end)