Welcome to my collection of tons of old lua files, that i developed over the laster 1+ Year.
You may or may not find anything in here usefull, but i just wanted to share nearly everything that i developed.

The most recent work is in the Unpleb Folder.
Older files are in the other 3.

I had to remove any
	.exe
	.dll
	.c
	.h
	.cpp
	.hpp
	.jar
Files since, there are unwritten bol rules, that prevent me to publish actually usefull stuff

Also for obvious reasons i removed some stuff from my latest Authentification Script
	The Script Key
		I replaced it with:
			SCRIPTKEY1337
	The AES Key
		I replaced it with:
			42AESKEY42
	The HMAC Checksum "key"
		I replaced it with:
			OMG_IT_A_HMAC
			
I also removed parts of the HWID generationg method.
Also i modified the GenerateSecretKey part for security
and 1 other function, i will not write here, sorry :(