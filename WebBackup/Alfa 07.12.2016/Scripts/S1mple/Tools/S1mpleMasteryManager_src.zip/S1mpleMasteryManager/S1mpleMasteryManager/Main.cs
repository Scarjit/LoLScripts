﻿namespace S1mpleMasteryManager
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.IO;
    using System.Net;
    using System.Runtime.InteropServices;
    using System.Threading;
    using System.Windows.Forms;

    using MetroFramework.Forms;

    public partial class Main : MetroForm
    {
        #region Constants

        public const int MOUSEEVENTF_LEFTDOWN = 0x02;

        public const int MOUSEEVENTF_LEFTUP = 0x04;

        #endregion

        #region Static Fields

        private static readonly Dictionary<string, string> allowed_roles = new Dictionary<string, string>();

        #endregion

        #region Constructors and Destructors

        public Main()
        {
            this.InitializeComponent();
        }

        #endregion

        #region Public Methods and Operators

        [DllImport("user32.dll")]
        public static extern void mouse_event(int dwFlags, int dx, int dy, int cButtons, int dwExtraInfo);

        #endregion

        #region Methods

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

        [DllImport("user32.dll")]
        private static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, int dwExtraInfo);

        [DllImport("user32.dll")]
        private static extern bool SetCursorPos(int X, int Y);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        private void AssignMasteries(RECT launcher_size, ArrayList masteryList)
        {
            var size = launcher_size.Right - launcher_size.Left;

            if (size == 1280)
                if (this.chkbox_is_champ_select.Checked)
                {
                    this.DoMouseClick(launcher_size.Left + 410, launcher_size.Bottom - 40);

                    this.DoMouseClick(launcher_size.Left + 175, launcher_size.Bottom - 600);
                    this.DoMouseClick(launcher_size.Left + 175, launcher_size.Bottom - 550);
                    var base_x = launcher_size.Left + 125;
                    var base_y = launcher_size.Bottom - 420;

                    foreach (ArrayList o in masteryList)
                    {
                        foreach (string mastery_point in o)
                            if (mastery_point.Length > 0)
                            {
                                var splits = mastery_point.Split('|');
                                var id = splits[0];
                                var points = int.Parse(splits[1]);
                                if (points > 0)
                                {
                                    var row = int.Parse(id.Substring(0, 1));
                                    var col = int.Parse(id.Substring(1));
                                    Console.WriteLine(row + "|" + col + " Points: " + points);
                                    for (var j = 0; j < points; j++)
                                    {
                                        this.DoMouseClick(base_x + col * 100 - 100, base_y + row * 70 - 70);
                                        Thread.Sleep(20);
                                    }
                                    Thread.Sleep(40);
                                }
                            }
                        base_x += 410;
                    }

                    this.DoMouseClick(launcher_size.Left + 1150, launcher_size.Bottom - 600);
                }
                else
                {
                    this.DoMouseClick(launcher_size.Left + 450, launcher_size.Bottom - 675);
                    Thread.Sleep(250);
                    this.DoMouseClick(launcher_size.Left + 250, launcher_size.Bottom - 620);
                    Thread.Sleep(1000);
                    this.DoMouseClick(launcher_size.Left + 175, launcher_size.Bottom - 570);
                    this.DoMouseClick(launcher_size.Left + 175, launcher_size.Bottom - 525);
                    var base_x = launcher_size.Left + 100;
                    var base_y = launcher_size.Bottom - 420;

                    foreach (ArrayList o in masteryList)
                    {
                        foreach (string mastery_point in o)
                            if (mastery_point.Length > 0)
                            {
                                var splits = mastery_point.Split('|');
                                var id = splits[0];
                                var points = int.Parse(splits[1]);
                                if (points > 0)
                                {
                                    var row = int.Parse(id.Substring(0, 1));
                                    var col = int.Parse(id.Substring(1));
                                    Console.WriteLine(row + "|" + col + " Points: " + points);
                                    for (var j = 0; j < points; j++)
                                    {
                                        this.DoMouseClick(base_x + col * 100 - 100, base_y + row * 70 - 70);
                                        Thread.Sleep(20);
                                    }
                                    Thread.Sleep(20);
                                }
                            }
                        base_x += 325;
                    }

                    this.DoMouseClick(launcher_size.Left + 950, launcher_size.Bottom - 570);
                }
            else if (size == 1024)
                if (this.chkbox_is_champ_select.Checked)
                {
                    this.DoMouseClick(launcher_size.Left + 330, launcher_size.Bottom - 30);
                    this.DoMouseClick(launcher_size.Left + 100, launcher_size.Bottom - 475);
                    this.DoMouseClick(launcher_size.Left + 100, launcher_size.Bottom - 450);
                    var base_x = launcher_size.Left + 100;
                    var base_y = launcher_size.Bottom - 340;

                    foreach (ArrayList o in masteryList)
                    {
                        foreach (string mastery_point in o)
                            if (mastery_point.Length > 0)
                            {
                                var splits = mastery_point.Split('|');
                                var id = splits[0];
                                var points = int.Parse(splits[1]);
                                if (points > 0)
                                {
                                    var row = int.Parse(id.Substring(0, 1));
                                    var col = int.Parse(id.Substring(1));
                                    Console.WriteLine(row + "|" + col + " Points: " + points);
                                    for (var j = 0; j < points; j++)
                                    {
                                        this.DoMouseClick(base_x + col * 75 - 75, base_y + row * 55 - 55);
                                        Thread.Sleep(20);
                                    }
                                    Thread.Sleep(20);
                                }
                            }
                        base_x += 325;
                    }

                    this.DoMouseClick(launcher_size.Left + 925, launcher_size.Bottom - 475);
                }
                else
                {
                    this.DoMouseClick(launcher_size.Left + 375, launcher_size.Bottom - 550);
                    Thread.Sleep(250);
                    this.DoMouseClick(launcher_size.Left + 200, launcher_size.Bottom - 500);
                    Thread.Sleep(1000);
                    this.DoMouseClick(launcher_size.Left + 100, launcher_size.Bottom - 450);
                    this.DoMouseClick(launcher_size.Left + 100, launcher_size.Bottom - 425);
                    var base_x = launcher_size.Left + 75;
                    var base_y = launcher_size.Bottom - 325;

                    foreach (ArrayList o in masteryList)
                    {
                        foreach (string mastery_point in o)
                            if (mastery_point.Length > 0)
                            {
                                var splits = mastery_point.Split('|');
                                var id = splits[0];
                                var points = int.Parse(splits[1]);
                                if (points > 0)
                                {
                                    var row = int.Parse(id.Substring(0, 1));
                                    var col = int.Parse(id.Substring(1));
                                    Console.WriteLine(row + "|" + col + " Points: " + points);
                                    for (var j = 0; j < points; j++)
                                    {
                                        this.DoMouseClick(base_x + col * 75 - 75, base_y + row * 55 - 55);
                                        Thread.Sleep(20);
                                    }
                                    Thread.Sleep(20);
                                }
                            }
                        base_x += 265;
                    }

                    this.DoMouseClick(launcher_size.Left + 775, launcher_size.Bottom - 450);
                }
            else if (size == 1600)
                if (this.chkbox_is_champ_select.Checked)
                {
                    this.DoMouseClick(launcher_size.Left + 515, launcher_size.Bottom - 50);

                    this.DoMouseClick(launcher_size.Left + 150, launcher_size.Bottom - 750);
                    this.DoMouseClick(launcher_size.Left + 150, launcher_size.Bottom - 700);

                    var base_x = launcher_size.Left + 150;
                    var base_y = launcher_size.Bottom - 525;

                    foreach (ArrayList o in masteryList)
                    {
                        foreach (string mastery_point in o)
                            if (mastery_point.Length > 0)
                            {
                                var splits = mastery_point.Split('|');
                                var id = splits[0];
                                var points = int.Parse(splits[1]);
                                if (points > 0)
                                {
                                    var row = int.Parse(id.Substring(0, 1));
                                    var col = int.Parse(id.Substring(1));
                                    Console.WriteLine(row + "|" + col + " Points: " + points);
                                    for (var j = 0; j < points; j++)
                                    {
                                        this.DoMouseClick(base_x + col * 120 - 120, base_y + row * 90 - 90);
                                        Thread.Sleep(20);
                                    }
                                    Thread.Sleep(20);
                                }
                            }
                        base_x += 525;
                    }
                    this.DoMouseClick(launcher_size.Left + 1450, launcher_size.Bottom - 750);
                }
                else
                {
                    this.DoMouseClick(launcher_size.Left + 600, launcher_size.Bottom - 850);
                    Thread.Sleep(250);
                    this.DoMouseClick(launcher_size.Left + 300, launcher_size.Bottom - 775);
                    Thread.Sleep(1000);

                    this.DoMouseClick(launcher_size.Left + 200, launcher_size.Bottom - 700);
                    this.DoMouseClick(launcher_size.Left + 200, launcher_size.Bottom - 650);

                    var base_x = launcher_size.Left + 125;
                    var base_y = launcher_size.Bottom - 525;

                    foreach (ArrayList o in masteryList)
                    {
                        foreach (string mastery_point in o)
                            if (mastery_point.Length > 0)
                            {
                                var splits = mastery_point.Split('|');
                                var id = splits[0];
                                var points = int.Parse(splits[1]);
                                if (points > 0)
                                {
                                    var row = int.Parse(id.Substring(0, 1));
                                    var col = int.Parse(id.Substring(1));
                                    Console.WriteLine(row + "|" + col + " Points: " + points);
                                    for (var j = 0; j < points; j++)
                                    {
                                        this.DoMouseClick(base_x + col * 120 - 120, base_y + row * 90 - 90);
                                        Thread.Sleep(20);
                                    }
                                    Thread.Sleep(20);
                                }
                            }
                        base_x += 420;
                    }

                    this.DoMouseClick(launcher_size.Left + 1200, launcher_size.Bottom - 700);
                }
        }

        private void btn_assignmasteries_Click(object sender, EventArgs e)
        {
            this.lbl_update.Visible = true;
            this.lbl_update.Text = "Getting Masteries";
            this.lbl_update.Update();
            var masteries = this.GetMasteries();
            this.lbl_update.Visible = false;
            this.lbl_update.Update();

            var launcher_size = this.GetLauncherSize();
            if (launcher_size.Left == null) return;

            this.AssignMasteries(launcher_size, masteries);
        }

        private void cbBox_champ_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selected_champ = this.cbBox_champ.SelectedItem;
            if (selected_champ == null) return;

            string allowed_positions;
            var valid = allowed_roles.TryGetValue(selected_champ.ToString(), out allowed_positions);
            if (valid)
            {
                this.cbBox_role.Items.Clear();
                foreach (var allowed_pos in allowed_positions.Split(',')) if (allowed_pos.Length > 0) this.cbBox_role.Items.Add(allowed_pos);
            }
        }

        private void CheckOnlineVersion()
        {
            var client = new WebClient();
            var s =
                client.DownloadString("http://s1mplescripts.de/S1mple/api.champion.gg_parser/get_championggpatch.php");
            if (!File.Exists("version.gg"))
            {
                this.CheckUpdate(true);
                var file = new StreamWriter("version.gg");
                file.Write(s);
                file.Close();
            }
            else
            {
                var file = new StreamReader("version.gg");
                var x = file.ReadLine();
                file.Close();
                if (!x.Equals(s))
                {
                    this.CheckUpdate(true);
                    var filex = new StreamWriter("version.gg");
                    filex.Write(s);
                    filex.Close();
                }
                else
                {
                    this.CheckUpdate(false);
                }
            }
        }

        private void CheckUpdate(bool force)
        {
            if (File.Exists("champion_data.gg") && !force)
            {
                this.ReadDataFromFile();
            }
            else
            {
                if (File.Exists("champion_data.gg")) File.Delete("champion_data.gg");
                this.lbl_update.Visible = true;
                this.lbl_update.Update();

                var champions = this.GetChampions();
                this.GetRoles();
            }
        }

        private void DoMouseClick(int x, int y)
        {
            SetCursorPos(x, y);
            Thread.Sleep(10);
            mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
            mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
            Thread.Sleep(50);
        }

        private ArrayList GetChampions()
        {
            var tosort = new ArrayList();
            using (var client = new WebClient())
            {
                var s =
                    client.DownloadString("http://s1mplescripts.de/S1mple/api.champion.gg_parser/get_all_champions.php");

                foreach (var champion in s.Split(',')) if (champion.Length > 0) tosort.Add(champion);
                tosort.Sort();
                foreach (var o in tosort) this.cbBox_champ.Items.Add(o.ToString());
            }
            return tosort;
        }

        private RECT GetLauncherSize()
        {
            var p = Process.GetProcessesByName("LeagueClientUx");
            var vhandle = IntPtr.Zero;
            foreach (var px in p)
            {
                var handle = px.MainWindowHandle;
                if (handle != IntPtr.Zero) vhandle = handle;
            }
            if (vhandle == IntPtr.Zero)
            {
                MessageBox.Show("Could not get the LoL Client Process Handle");
                return new RECT();
            }

            var lol_window_rect = new RECT();
            if (!GetWindowRect(vhandle, out lol_window_rect))
            {
                MessageBox.Show("Could not get the Client Window Size");
                return new RECT();
            }

            SetForegroundWindow(vhandle);
            return lol_window_rect;
        }

        private ArrayList GetMasteries()
        {
            var selected_champ = this.cbBox_champ.SelectedItem;
            var btype = this.cbBox_stats.SelectedItem.ToString().Contains("Highest Win % Masteries");
            var type = 0;
            if (btype) type = 0;
            else type = 1;

            var masteryselection = new ArrayList();
            using (var client = new WebClient())
            {
                var s =
                    client.DownloadString(
                        "http://s1mplescripts.de/S1mple/api.champion.gg_parser/get_mastery.php?champion="
                        + selected_champ + "&type=" + type);
                var tree_splits = s.Split(':');

                foreach (var treeSplit in tree_splits)
                {
                    var x = new ArrayList();
                    var mastery_splits = treeSplit.Split(',');
                    foreach (var masterySplit in mastery_splits) x.Add(masterySplit);
                    masteryselection.Add(x);
                }
            }

            return masteryselection;
        }

        private void GetRoles()
        {
            var client = new WebClient();
            var s =
                client.DownloadString(
                    "http://s1mplescripts.de/S1mple/api.champion.gg_parser/get_all_champ_positions.php");
            var file = new StreamWriter("champion_data.gg");
            file.Write(s);
            file.Close();
            this.lbl_update.Text = "Finished Update";
            this.lbl_update.Update();
        }

        private void Main_Shown(object sender, EventArgs e)
        {
            this.CheckOnlineVersion();
            this.cbBox_stats.SelectedIndex = 0;
            this.cbBox_champ.SelectedIndex = 0;
            this.cbBox_role.SelectedIndex = 0;
        }

        private void ReadDataFromFile()
        {
            var file = new StreamReader("champion_data.gg");
            string line;
            while ((line = file.ReadLine()) != null)
                if (line.Length > 0)
                {
                    var datasplits = line.Split(':');
                    var champion = datasplits[0];
                    var roles = datasplits[1];
                    allowed_roles.Add(champion, roles);
                    this.cbBox_champ.Items.Add(champion);
                }
        }

        #endregion

        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int Left;

            public int Top;

            public int Right;

            public int Bottom;
        }
    }
}