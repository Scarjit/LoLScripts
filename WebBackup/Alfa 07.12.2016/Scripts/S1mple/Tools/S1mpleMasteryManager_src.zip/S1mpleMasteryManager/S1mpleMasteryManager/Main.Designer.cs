﻿namespace S1mpleMasteryManager
{
    using System.Windows.Forms;

    using MetroFramework.Controls;

    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_champ = new MetroFramework.Controls.MetroLabel();
            this.lbl_role = new MetroFramework.Controls.MetroLabel();
            this.lbl_stats = new MetroFramework.Controls.MetroLabel();
            this.btn_assignmasteries = new MetroFramework.Controls.MetroButton();
            this.chkbox_is_champ_select = new MetroFramework.Controls.MetroCheckBox();
            this.cbBox_champ = new System.Windows.Forms.ComboBox();
            this.cbBox_role = new System.Windows.Forms.ComboBox();
            this.cbBox_stats = new System.Windows.Forms.ComboBox();
            this.lbl_update = new MetroFramework.Controls.MetroLabel();
            this.SuspendLayout();
            // 
            // lbl_champ
            // 
            this.lbl_champ.AutoSize = true;
            this.lbl_champ.Location = new System.Drawing.Point(25, 65);
            this.lbl_champ.Name = "lbl_champ";
            this.lbl_champ.Size = new System.Drawing.Size(70, 19);
            this.lbl_champ.TabIndex = 0;
            this.lbl_champ.Text = "Champion";
            // 
            // lbl_role
            // 
            this.lbl_role.AutoSize = true;
            this.lbl_role.Location = new System.Drawing.Point(25, 90);
            this.lbl_role.Name = "lbl_role";
            this.lbl_role.Size = new System.Drawing.Size(35, 19);
            this.lbl_role.TabIndex = 1;
            this.lbl_role.Text = "Role";
            // 
            // lbl_stats
            // 
            this.lbl_stats.AutoSize = true;
            this.lbl_stats.Location = new System.Drawing.Point(24, 115);
            this.lbl_stats.Name = "lbl_stats";
            this.lbl_stats.Size = new System.Drawing.Size(36, 19);
            this.lbl_stats.TabIndex = 2;
            this.lbl_stats.Text = "Stats";
            // 
            // btn_assignmasteries
            // 
            this.btn_assignmasteries.Location = new System.Drawing.Point(200, 150);
            this.btn_assignmasteries.Name = "btn_assignmasteries";
            this.btn_assignmasteries.Size = new System.Drawing.Size(165, 23);
            this.btn_assignmasteries.TabIndex = 3;
            this.btn_assignmasteries.Text = "Assign Masteries";
            this.btn_assignmasteries.Click += new System.EventHandler(this.btn_assignmasteries_Click);
            // 
            // chkbox_is_champ_select
            // 
            this.chkbox_is_champ_select.AutoSize = true;
            this.chkbox_is_champ_select.Location = new System.Drawing.Point(24, 150);
            this.chkbox_is_champ_select.Name = "chkbox_is_champ_select";
            this.chkbox_is_champ_select.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.chkbox_is_champ_select.Size = new System.Drawing.Size(126, 15);
            this.chkbox_is_champ_select.TabIndex = 4;
            this.chkbox_is_champ_select.Text = "In Champion Select";
            this.chkbox_is_champ_select.UseVisualStyleBackColor = true;
            // 
            // cbBox_champ
            // 
            this.cbBox_champ.FormattingEnabled = true;
            this.cbBox_champ.Location = new System.Drawing.Point(100, 65);
            this.cbBox_champ.Name = "cbBox_champ";
            this.cbBox_champ.Size = new System.Drawing.Size(220, 21);
            this.cbBox_champ.TabIndex = 5;
            this.cbBox_champ.SelectedIndexChanged += new System.EventHandler(this.cbBox_champ_SelectedIndexChanged);
            // 
            // cbBox_role
            // 
            this.cbBox_role.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBox_role.FormattingEnabled = true;
            this.cbBox_role.Items.AddRange(new object[] {
            "Jungle",
            "Top",
            "Mid",
            "Bot",
            "Support"});
            this.cbBox_role.Location = new System.Drawing.Point(100, 90);
            this.cbBox_role.Name = "cbBox_role";
            this.cbBox_role.Size = new System.Drawing.Size(220, 21);
            this.cbBox_role.TabIndex = 6;
            // 
            // cbBox_stats
            // 
            this.cbBox_stats.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBox_stats.FormattingEnabled = true;
            this.cbBox_stats.Items.AddRange(new object[] {
            "Most Frequent Masteries",
            "Highest Win % Masteries"});
            this.cbBox_stats.Location = new System.Drawing.Point(100, 115);
            this.cbBox_stats.Name = "cbBox_stats";
            this.cbBox_stats.Size = new System.Drawing.Size(220, 21);
            this.cbBox_stats.TabIndex = 7;
            // 
            // lbl_update
            // 
            this.lbl_update.AutoSize = true;
            this.lbl_update.Location = new System.Drawing.Point(23, 190);
            this.lbl_update.Name = "lbl_update";
            this.lbl_update.Size = new System.Drawing.Size(159, 19);
            this.lbl_update.TabIndex = 8;
            this.lbl_update.Text = "Updating Champion Data";
            this.lbl_update.Visible = false;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(377, 229);
            this.Controls.Add(this.lbl_update);
            this.Controls.Add(this.cbBox_stats);
            this.Controls.Add(this.cbBox_role);
            this.Controls.Add(this.cbBox_champ);
            this.Controls.Add(this.chkbox_is_champ_select);
            this.Controls.Add(this.btn_assignmasteries);
            this.Controls.Add(this.lbl_stats);
            this.Controls.Add(this.lbl_role);
            this.Controls.Add(this.lbl_champ);
            this.MaximizeBox = false;
            this.Name = "Main";
            this.Resizable = false;
            this.Text = "S1mple Mastery Manager";
            this.Shown += new System.EventHandler(this.Main_Shown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroLabel lbl_champ;
        private MetroLabel lbl_role;
        private MetroLabel lbl_stats;
        private MetroButton btn_assignmasteries;
        private MetroCheckBox chkbox_is_champ_select;
        private System.Windows.Forms.ComboBox cbBox_champ;
        private System.Windows.Forms.ComboBox cbBox_role;
        private System.Windows.Forms.ComboBox cbBox_stats;
        private MetroLabel lbl_update;
    }
}

